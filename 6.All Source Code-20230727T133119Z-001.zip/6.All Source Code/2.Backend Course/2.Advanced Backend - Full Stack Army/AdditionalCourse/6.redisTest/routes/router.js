const Router = require("express").Router();
const { homeControllers } = require("../controllers/home_controllers");
const { redisController } = require("../controllers/redis_controler");

Router.get("/", homeControllers);
Router.get("/redis", redisController);

module.exports = Router;
