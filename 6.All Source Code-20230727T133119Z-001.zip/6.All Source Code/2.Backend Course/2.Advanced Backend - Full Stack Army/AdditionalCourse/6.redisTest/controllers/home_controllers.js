const fs = require("fs");
const path = require("path");
const Redis = require("ioredis");

//create redis client
const redisClient = new Redis();

const homeControllers = (_req, res) => {
  // Read file
  const rawData = fs.readFileSync(path.join(__dirname, "../database/data.db"));
  const data = JSON.parse(rawData);

  // Data set in Redis
  for (let key in data) {
    if (key) {
      redisClient.set(`${key}`, JSON.stringify(data[key]));
    }
  }

  res.status(200).json({
    msg: "Data Upload in Redis",
  });
};

module.exports = { homeControllers, redisClient };
