const axios = require("axios");
const { redisClient } = require("./home_controllers");
const path = require("path");
const fs = require("fs");

const redisController = async (req, res) => {
  const albumId = req.query.albumId;

  redisClient.get(`photos${albumId}`, async (error, cacheData) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "Internal Server Error" });
    }

    // Get data from Redis cache
    if (cacheData != null) {
      console.log("Cache Hit");
      return res.status(200).json(JSON.parse(cacheData));
    } else {
      console.log("Cache Miss");
      //data from server
      const { data } = await axios.get(
        "https://jsonplaceholder.typicode.com/photos",
        { params: { albumId } }
      );

      if (Object.keys(data).length > 0) {
        // Set data in Redis cache
        redisClient.set(`photos${albumId}`, JSON.stringify(data));

        //Data Read from DataBase
        const rawdbData = fs.readFileSync(
          path.join(__dirname, "../database/data.db")
        );
        const dbData = JSON.parse(rawdbData);

        //newData Write on dataBase
        dbData[`photos${albumId}`] = data;
        fs.writeFileSync(
          path.join(__dirname, "../database/data.db"),
          JSON.stringify(dbData)
        );

        return res.status(200).json(data);
      }
      res.status(400).json({
        msg: "Bad Request",
      });
    }
  });
};

module.exports = { redisController };
