const http = require("http");
const app = require("./app/app");

//Create Server
const server = http.createServer(app);

//server listen
server.listen(4000, () => {
  console.log(`Server is listening on PORT 4000`);
});
