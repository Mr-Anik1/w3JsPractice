const express = require("express");
const Redis = require("ioredis");
const axios = require("axios");

//Create app
const app = express();

//Create redisClient
const redisClient = new Redis();

//Middleware
app.use(express.json());

app.get("/redispicture/:id", async (req, res) => {
  const photos = await getOrsetCache(`photo:${req.params.id}`, async () => {
    const { data } = await axios.get(
      `https://jsonplaceholder.typicode.com/photos?albumId=${req.params.id}`
    );
    return data;
  });

  res.json(photos);
});

function getOrsetCache(key, cb) {
  return new Promise((resolve, reject) => {
    redisClient.get(key, async (error, cacheData) => {
      if (error) return reject(error);
      if (cacheData != null) return resolve(JSON.parse(cacheData));
      const freshData = await cb();
      redisClient.set(key, JSON.stringify(freshData));
      resolve(freshData);
    });
  });
}

app.listen(4000, () => {
  console.log(`Server is listening on PORT 4000`);
});

