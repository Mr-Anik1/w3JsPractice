// const express = require("express");
// const axios = require("axios");
// const Redis = require("ioredis");

// //Create app
// const app = express();

// //Create Redis Client
// const redisClient = new Redis();

// app.get("/photos", async (req, res) => {
//   const albumId = req.query.albumId;

//   redisClient.get(`photos${albumId}`, async (error, cacheData) => {
//     if (error) {
//       console.error(error);
//       return res.status(500).json({ error: "Internal Server Error" });
//     }

//     // Get data from Redis cache
//     if (cacheData != null) {
//       console.log("Cache Hit");
//       return res.status(200).json(JSON.parse(cacheData));
//     } else {
//       console.log("Cache Miss");
//       //data from server
//       const { data } = await axios.get(
//         "https://jsonplaceholder.typicode.com/photos",
//         { params: { albumId } }
//       );
//       // Set data in Redis cache
//       redisClient.set(`photos${albumId}`, JSON.stringify(data));

//       res.status(200).json(data);
//     }
//   });
// });

// //app listen
// app.listen(4000, () => {
//   console.log(`Server is listening on port 4000`);
// });

//   http://localhost:4000/photos?albumId=6

// let arr = [1, 2];
// console.log(Object.keys(arr).length);
