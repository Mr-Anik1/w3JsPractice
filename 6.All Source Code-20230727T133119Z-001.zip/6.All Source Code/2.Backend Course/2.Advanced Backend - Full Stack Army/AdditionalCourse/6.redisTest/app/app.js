const express = require("express");
const Router = require("../routes/router");

//Create app
const app = express();

//Middleware
app.use(express.json());
app.use(Router);

//app export
module.exports = app;
