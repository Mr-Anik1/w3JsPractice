const countString = (str) => {
  const nStr = str.split("");
  const obj = nStr.reduce((acc, cur) => {
    acc[cur] = acc[cur] ? acc[cur] + 1 : 1;
    return acc;
  }, {});

  //Object sort with value
  const value = Object.fromEntries(
    Object.entries(obj).sort((a, b) => a[1] - b[1])
  );
  delete value[" "];

  return value;
};

module.exports = countString;
//Theaeyntyisanadeshanditsindeendentin
/*

{
  "stringObj": {
    "T": 1,
    "h": 2,
    "y": 2,
    "t": 3,
    "s": 3,
    "a": 4,
    "i": 4,
    "d": 4,
    "e": 6,
    "n": 7
  }
}

*/
