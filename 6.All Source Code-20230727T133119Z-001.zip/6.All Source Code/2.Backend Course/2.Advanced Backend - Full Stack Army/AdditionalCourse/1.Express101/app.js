const express = require("express");
//router import
const router = require("./routes");

//Create Express app
const app = express();

//BiiltIn Middleware
app.use(express.json());

//router use
app.use(router);

//Static File
app.use(express.static("./public"));

//Error Handler
app.use((req, res, next) => {
  const error = new Error("404 Not Found");
  error.status = 404;
  next(error);
});

//Global Error Middlewar
app.use((error, req, res, next) => {
  console.log(error);
  if (error.status) {
    return res.status(error.status).send(error.message);
  }

  res.status(500).send("Something Went Wrong");
});

app.listen(4000, () => {
  console.log(`Server is listening on port 4000`);
});

// //Middlewar
// app.use(globalMiddlewar);

// //Test: http://localhost:4000/test?str=Theaeyntyisanadeshanditsindeendentin
// app.get("/test", (req, res) => {
//   try {
//     const str = req.query.str;
//     res.json({ stringObj: countString(str) });
//   } catch {
//     res.status(404).json({ msg: "Error! Something is wrong." });
//   }
// });

// app.get("/about", (_req, res) => {
//   fs.readFile("./index.html", (err, data) => {
//     if (err) {
//       res.send(`<h1>something is wrong</h1>`);
//     } else {
//       res.write(data);
//       res.end();
//     }
//   });
// });

// //Dynamic params /user/:id
// //In here /user/:id route I use local middlewar
// app.get("/user/:id", localMiddlewar, (req, res) => {
//   res.send(`UserId: ${req.params.id}`);
// });

// //Global Middlewar
// function globalMiddlewar(req, res, next) {
//   console.log(`Hello I am global middlewar`);
//   if (req.query.bad) {
//     return res.status(404).send("This is bad request!");
//   }
//   next();
// }

// //Local Middlewar
// function localMiddlewar(req, res, next) {
//   console.log(`I am local middlewar`);
//   next();
// }
