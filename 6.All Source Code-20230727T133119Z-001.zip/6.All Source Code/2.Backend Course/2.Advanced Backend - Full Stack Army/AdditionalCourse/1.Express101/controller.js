const fs = require("fs");
const countString = require("./stringFile");

//Our All Controller

// /test controller
exports.testController = (req, res) => {
  try {
    const str = req.query.str;
    res.json({ stringObj: countString(str) });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

//  /about controller
exports.aboutController = (_req, res) => {
  fs.readFile("./index.html", (err, data) => {
    if (err) {
      throw error;
    } else {
      res.write(data);
      res.end();
    }
  });
};

//  /user/:id controller
exports.userController = (req, res) => {
  try {
    res.send(`UserId: ${req.params.id}`);
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

//Global Middlewar
exports.globalMiddlewar = (req, res, next) => {
  console.log(`Hello I am global middlewar`);
  if (req.query.bad) {
    return res.status(404).send("This is bad request!");
  }
  next();
};

//Local Middlewar
exports.localMiddlewar = (_req, _res, next) => {
  console.log(`I am local middlewar`);
  next();
};

//  /books POST Method
exports.booksController = (req, res) => {
  //Book
  const book = req.body;

  //Read File
  const rawData = fs.readFileSync("./data.db");
  const data = JSON.parse(rawData);

  //Write File
  data.push(book);
  fs.writeFileSync("./data.db", JSON.stringify(data));

  res.json(data);
};

// /books?price GET
exports.getBooks = (req, res) => {
  try {
    //Read Books
    const rawBooks = fs.readFileSync("./data.db");
    const books = JSON.parse(rawBooks);

    let price = req.query.price;

    //Check If Price is not a number then throw an Error
    if (+price) {
      let finalResult = books.filter((book) => book.price <= price);

      res.json(finalResult);
    } else {
      throw error;
    }
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};
