// const express=require('express');
// const router=express.Router()
//We  use router.get() insted of app.get() this is power of router.

//One Line
const router = require("express").Router();

//Import all controller
const {
  testController,
  aboutController,
  userController,
  booksController,
  getBooks,
  globalMiddlewar,
  localMiddlewar,
} = require("./controller.js");

//Middlewar
router.use(globalMiddlewar);

//Test: http://localhost:4000/test?str=Theaeyntyisanadeshanditsindeendentin
router.get("/test", testController);

//Test: http://localhost:4000/about
router.get("/about", aboutController);

//Dynamic params /user/:id
//In here /user/:id route I use local middlewar
router.get("/user/:id", localMiddlewar, userController);

//Post Request
router.post("/books", booksController);

router.get("/books", getBooks);

//Export Router
module.exports = router;
