const router = require("express").Router();
const {
  testControllrs,
  createPerson,
  getPerson,
  getPersonId,
} = require("../controllers/app_controller");

//Routes
router.get("/test", testControllrs);
router.post("/person", createPerson);
router.get("/person", getPerson);
router.get("/person/:id", getPersonId);

module.exports = router;
