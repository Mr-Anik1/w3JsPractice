const adminRouter = require("express").Router();
const {
  adminHomeControllers,
  adminDashboardControllers,
  adminAboutControllers,
} = require("../controllers/app_controller");
const { loggerMiddleware } = require("../middlewares/app_middleware");

//When only hit admin routes then loggerMiddleware will be execute.
adminRouter.use(loggerMiddleware);

// http://localhost:4000/admin/
adminRouter.get("/", adminHomeControllers);

// http://localhost:4000/admin/dashboard
adminRouter.get("/dashboard", adminDashboardControllers);

// http://localhost:4000/admin/about
adminRouter.get("/about", adminAboutControllers);

module.exports = adminRouter;
