const fileUploadRouter = require("express").Router();
const { fileUploadControllers } = require("../controllers/app_controller");
//File Upload Logic
const { upload } = require("../business_logics/app_business_logic");

// const multer = require("multer");
// const path = require("path");

// const uploadPath = path.join(__dirname, "../uploads");

// const fileStorage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     cb(null, uploadPath);
//   },
//   filename: (req, file, cb) => {
//     const fileExt = path.extname(file.originalname);
//     const fileName =
//       file.originalname
//         .replace(fileExt, "")
//         .toLocaleLowerCase()
//         .split(" ")
//         .join("-") +
//       "-" +
//       Date.now();

//     cb(null, fileName + fileExt);
//   },
// });

// const upload = multer({
//   storage: fileStorage,
//   limits: {
//     fileSize: 1000000, //1MB -> 1000byte * 1000kiloByte
//   },
//   fileFilter: (req, file, cb) => {
//     if (
//       file.mimetype === "image/png" ||
//       file.mimetype === "image/jpg" ||
//       file.mimetype === "image/jpeg"
//     ) {
//       cb(null, true);
//     } else {
//       cb(new Error("Only .jpg, .png, .jpeg format allowed"));
//     }
//   },
// });

/**
 * @Upload_Single_File
 */
// fileUploadRouter.post(
//   "/fileupload",
//   upload.single("avatar"),
//   fileUploadControllers
// );

/**
 * @Upload_Multiple_file
 */
// fileUploadRouter.post(
//   "/fileupload",
//   upload.array("avatar", 3),
//   fileUploadControllers
// );

/**
 * @Upload_file_in_multiple_input
 */
// fileUploadRouter.post(
//   "/fileupload",
//   upload.fields([
//     { name: "avatar", maxCount: 3 },
//     { name: "galary", maxCount: 5 },
//   ]),
//   fileUploadControllers
// );

/**
 * @Upload_only_form_data
 */
// fileUploadRouter.post("/fileupload", upload.none(), fileUploadControllers);

fileUploadRouter.post(
  "/fileupload",
  upload.array("galary", 10),
  fileUploadControllers
);

module.exports = fileUploadRouter;
