const express = require("express");
const router = require("../routes/app_routes");
const { notFoundHandler, globalErrorHandler } = require("../error/error_msg");
const adminRouter = require("../routes/admin_routes");
const fileUploadRouter = require("../routes/file_routes");

//Create app
const app = express();

//Middleware
app.use(express.json());
app.use(router);
app.use("/admin", adminRouter); //When hit /admin route then enabled adminRouter.
app.use(fileUploadRouter);
app.use(notFoundHandler);
app.use(globalErrorHandler);

module.exports = app;
