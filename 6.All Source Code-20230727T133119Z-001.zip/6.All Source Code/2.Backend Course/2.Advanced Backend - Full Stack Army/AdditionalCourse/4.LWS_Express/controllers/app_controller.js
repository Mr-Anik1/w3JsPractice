/**
 * @All_controllers_have_been_imported
 */

//Test Controllers
const { testControllrs } = require("./all_controllers/test");

//Person Controllers
const {
  createPerson,
  getPerson,
  getPersonId,
} = require("./all_controllers/person");

//Admin Controllers
const {
  adminHomeControllers,
  adminDashboardControllers,
  adminAboutControllers,
} = require("./all_controllers/admin_controllers");

//File Upload Controllers
const { fileUploadControllers } = require("./all_controllers/fileUpload");

/*







---------------/////----------------///////------------------







*/

//All controllers have been exported.
module.exports = {
  testControllrs,
  createPerson,
  getPerson,
  getPersonId,
  adminHomeControllers,
  adminDashboardControllers,
  adminAboutControllers,
  fileUploadControllers,
};
