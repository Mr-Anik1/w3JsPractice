const testControllrs = (_req, res) => {
  try {
    res.status(200).json({ msg: "Hello I am Test Route" });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

module.exports = { testControllrs };
