const fileUploadControllers = (req, res) => {
  try {
    console.log(req.files);
    res.status(200).json({
      msg: "File Uploaded successfully",
    });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

module.exports = { fileUploadControllers };
