const adminHomeControllers = (req, res) => {
  try {
    res.status(200).json({
      msg: "This is Admin HOME",
    });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

const adminDashboardControllers = (req, res) => {
  try {
    res.status(200).json({
      msg: "This is Admin DashBoard",
    });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

const adminAboutControllers = (req, res) => {
  try {
    res.status(200).json({
      msg: "Hello I am Admin",
    });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

module.exports = {
  adminHomeControllers,
  adminDashboardControllers,
  adminAboutControllers,
};
