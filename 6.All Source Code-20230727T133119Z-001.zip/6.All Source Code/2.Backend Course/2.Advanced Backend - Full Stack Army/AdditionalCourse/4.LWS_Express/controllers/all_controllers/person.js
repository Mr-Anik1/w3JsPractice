const { error } = require("console");
const fs = require("fs");
const path = require("path");

const createPerson = (req, res) => {
  try {
    const newData = req.body;

    //Read Data
    const rawData = fs.readFileSync(
      path.join(__dirname, "../../database/data.db")
    );
    const data = JSON.parse(rawData);

    //Write Data
    data.push(newData);
    fs.writeFileSync(
      path.join(__dirname, "../../database/data.db"),
      JSON.stringify(data)
    );

    res.status(201).json({
      msg: "New Person Created",
      person: newData,
    });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

const getPerson = (_req, res) => {
  try {
    //Read Data
    const rawData = fs.readFileSync(
      path.join(__dirname, "../../database/data.db")
    );
    const data = JSON.parse(rawData);

    res.status(200).json({
      persons: data,
    });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

const getPersonId = (req, res) => {
  try {
    //Read Data
    const rawData = fs.readFileSync(
      path.join(__dirname, "../../database/data.db")
    );
    const data = JSON.parse(rawData);

    //Find individual person objects with ID
    const id = +req.params.id;
    //If the id is valid, the response will be sent; otherwise, an error will be thrown.
    if (id) {
      const personId = data.filter((person) => person.id === id);

      if (personId.length === 0) {
        return res.status(200).json({
          msg: "There is no person on this ID.",
        });
      }

      res.status(200).json({
        person: personId,
      });
    } else {
      throw error;
    }
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

module.exports = { createPerson, getPerson, getPersonId };
