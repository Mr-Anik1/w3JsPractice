//All business logic files have been imported
const { upload } = require("./all_logics/fileUploadLogics");

/*





-----------///////---------//////-----------//////------------






*/

//All business logic files have been exported
module.exports = { upload };
