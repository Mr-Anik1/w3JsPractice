const multer = require("multer");
const path = require("path");

const fileUploadPath = path.join(__dirname, "../../uploads");

const fileStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, fileUploadPath);
  },
  filename: (_req, file, cb) => {
    const fileExt = path.extname(file.originalname);
    const fileName =
      file.originalname
        .replace(fileExt, "")
        .toLocaleLowerCase()
        .split(" ")
        .join("-") +
      "-" +
      Date.now();

    cb(null, fileName + fileExt);
  },
});

const upload = multer({
  storage: fileStorage,
  fileSize: 100000, //1 MB
  fileFilter: (_req, file, cb) => {
    if (
      file.mimetype === "image/png" ||
      file.mimetype === "image/jpg" ||
      file.mimetype === "image/jpeg"
    ) {
      cb(null, true);
    } else {
      cb(new Error("Only .jpg, .png, .jpeg format allowed"));
    }
  },
});

module.exports = { upload };
