const http = require("http");
const app = require("./app/app");

//Create Server
const server = http.createServer(app);

//Server Listen
server.listen(4000, () => {
  console.log(`Server is listening on PORT 4000`);
});
