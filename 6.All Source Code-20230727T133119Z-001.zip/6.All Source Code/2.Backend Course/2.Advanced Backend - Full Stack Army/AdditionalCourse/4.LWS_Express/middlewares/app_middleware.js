//All middleware has been imported.
const loggerMiddleware = require("./all_middlewares/logger");

//All middleware has been exported.
module.exports = { loggerMiddleware };
