const loggerMiddleware = (req, res, next) => {
  try {
    console.log(`${req.path} - ${req.method} - ${new Date().toISOString()}`);
    next();
  } catch {
    const error = new Error("Bad Request Middleware");
    error.status = 400;
    throw error;
  }
};

module.exports = loggerMiddleware;
