const mongoose = require("mongoose");

// const personSchema = new mongoose.Schema({
//   firstName: String,
//   lastName: String,
//   email: String,
//   age: Number,
//   bio: String,
//   single: Boolean,
// });

// Schema with validation
// If I didn't pass firstName then throw error like: Person validation failed: firstName: Path `firstName` is required.
const personSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: true,
    minlength: [3, "minimum 3 chars"],
    maxlength: [20, "maximum 20 chars"],
  },
  lastName: {
    type: String,
    required: true,
    minlength: [3, "minimum 3 chars"],
    maxlength: [15, "maximum 15 chars"],
  },
  email: {
    type: String,
    required: true,
    minlength: [11, "minimum 1 chars"],
    maxlength: [20, "maximum 20 chars"],
    validate: {
      validator: (v) => {
        return v.endsWith(".com");
      },
      message: "Invalid Email Format",
    },
  },
  age: Number,
  bio: String,
  single: Boolean,
});

const Person = mongoose.model("Person", personSchema);

mongoose
  .connect("mongodb://localhost:27017/test-mongodb")
  .then(async () => {
    console.log("DataBase Connected");

    // const user1 = new Person({
    //   firstName: "Veronica",
    //   lastName: "Stephen",
    //   email: "merica@gmail.com",
    //   age: 22,
    // });
    // await user1.save(); //save in database

    // console.log("User Created");
    // console.log(user1);

    // Data retrive from database
    const allUser = await Person.find({ firstName: "Veronica" });
    console.log(allUser);
  })
  .catch((e) => {
    console.log("Error:", e.message);
  })
  .finally(() => {
    mongoose.connection.close();
  });
