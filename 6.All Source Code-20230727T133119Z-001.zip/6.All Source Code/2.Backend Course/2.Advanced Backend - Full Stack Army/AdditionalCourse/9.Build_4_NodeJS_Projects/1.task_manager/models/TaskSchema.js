const { Schema, model } = require("mongoose");

const taskSchema = new Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    minLength: [5, "task name is too short, minimun 5 characters is required"],
    maxLength: [30, "task name can not be more than 30 characters"],
  },
  completed: {
    type: Boolean,
    default: false,
  },
});

const Task = model("Task", taskSchema);

module.exports = { Task };
