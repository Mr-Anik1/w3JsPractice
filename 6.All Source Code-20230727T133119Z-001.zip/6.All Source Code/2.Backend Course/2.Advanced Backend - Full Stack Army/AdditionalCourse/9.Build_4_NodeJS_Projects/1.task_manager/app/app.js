const express = require("express");
const path = require("path");
const { router } = require("../routes/tasks");
const {
  notFoundHandler,
  globalErrorHandler,
} = require("../middleware/error_handler");

// Create app
const app = express();

/**
 * @Middleware
 */
app.use(express.json());
app.use("/api/v1/tasks", router);
//Static File
app.use(express.static(path.join(__dirname, "../public")));
//Error
app.use(notFoundHandler);
app.use(globalErrorHandler);

// Export app
module.exports = { app };
