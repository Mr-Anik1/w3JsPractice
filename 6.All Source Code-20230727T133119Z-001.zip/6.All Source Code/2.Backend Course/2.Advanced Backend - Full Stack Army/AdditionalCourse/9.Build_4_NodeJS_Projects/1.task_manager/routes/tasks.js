const router = require("express").Router();
const {
  getAllTasks,
  createTask,
  getTask,
  updateTask,
  deleteTask,
} = require("../controllers/tasks");

// Routes
router.route("/").get(getAllTasks).post(createTask);
router.route("/:id").get(getTask).patch(updateTask).delete(deleteTask);

// /**
//  * @DataBase_Testing
//  */
// router.get("/db", getAllDB);
// router.post("/db", createDB);
// router.get("/db/:id", getSingleDB);
// router.delete("/db/:id", deleteDB);

// router.get("/"); // - get all the tasks
// router.post("/"); // - create a new tasks
// router.get("/:id"); // - get single tasks
// router.patch("/:id"); // - update single tasks
// router.delete("/:id"); // - delete single tasks

// Export router
module.exports = { router };
