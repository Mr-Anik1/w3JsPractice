require("dotenv").config();
const http = require("http");
const { app } = require("./app/app");
const { dbConnect } = require("./db/connect");

// Server Create
const server = http.createServer(app);

// Listening PORT
const PORT = process.env.PORT;

const start = async () => {
  try {
    // Database Connection
    await dbConnect();

    // Server Listen
    server.listen(PORT, () => {
      console.log(`Server is listen on PORT ${PORT}`);
    });
  } catch (e) {
    console.log(e.message);
  }
};
start();
