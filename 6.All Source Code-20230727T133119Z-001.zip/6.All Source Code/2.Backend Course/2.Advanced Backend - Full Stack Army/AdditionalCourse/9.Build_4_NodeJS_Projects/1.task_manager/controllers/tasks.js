// const { Product } = require("../db/product");
const { Task } = require("../models/TaskSchema");

const getAllTasks = async (_req, res) => {
  try {
    // Retrive all tasks
    const tasks = await Task.find({});

    if (!tasks) {
      console.log(`tasks not found`);
      return res.status(404).json({ msg: `tasks not found` });
    }

    console.log("tasks retrive successfully");
    res.status(200).json({
      // msg: "task retrive successfully",
      status: "success",
      tasks,
    });
  } catch (e) {
    console.log(e.message);
    res.status(500).json({
      msg: "internal server error",
    });
  }
};
// data: { tasks },

const createTask = async (req, res) => {
  try {
    // Create Task
    const task = new Task(req.body);
    await task.save();
    console.log("new task is created");

    res.status(201).json({
      status: "success",
      task,
    });
  } catch (e) {
    console.log(e.message);
    res.status(400).json({
      msg: e.message,
    });
  }
};

const getTask = async (req, res) => {
  try {
    // Retrive Single Task
    const id = req.params.id;
    const task = await Task.findById(id);

    if (!task) {
      console.log(`no task with id: ${id}`);
      return res.status(404).json({ msg: `no task with id: ${id}` });
    }

    console.log("task retrive successfully");
    res.status(200).json({
      status: "success",
      task,
    });
  } catch (e) {
    console.log(e.message);
    res.status(500).json({
      msg: "internal server error",
    });
  }
};

const updateTask = async (req, res) => {
  try {
    // Update Task
    const id = req.params.id;

    const task = await Task.findByIdAndUpdate({ _id: id }, req.body, {
      new: true,
      runValidators: true,
    });

    if (!task) {
      console.log(`no task with id: ${id}`);
      return res.status(404).json({ msg: `no task with id: ${id}` });
    }

    console.log("task update successfully");
    res.status(200).json({
      status: "success",
      task,
    });
  } catch (e) {
    console.log(e.message);
    res.status(400).json({
      msg: e.message,
    });
  }
};

const deleteTask = async (req, res) => {
  try {
    //  Delete Task
    const id = req.params.id;
    const task = await Task.findByIdAndDelete(id);

    if (!task) {
      console.log(`no task with id: ${id}`);
      return res.status(404).json({ msg: `no task with id: ${id}` });
    }

    console.log("task delete successfully");
    res.status(200).json({
      msg: "task delete successfully",
    });
  } catch (e) {
    console.log(e.message);
    res.status(500).json({
      msg: "internal server error",
    });
  }
};

/**
 * @DataBase_Testing
 */
// const getAllDB = async (_req, res) => {
//   try {
//     // Retrive Products
//     const products = await Product.find({});
//     console.log(products);

//     res.status(200).json({
//       msg: "Retrive Products Successfully",
//       items: products,
//     });
//   } catch (e) {
//     res.status(404).json({
//       error: e.message,
//     });
//   }
// };

// const getSingleDB = async (req, res) => {
//   try {
//     // Retrive Single Product
//     const id = req.params.id;
//     const product = await Product.findById(id);
//     if (product) {
//       res.status(200).json({
//         msg: "Retrive Product Successfully",
//         item: product,
//       });
//     } else {
//       throw new Error("Product Not Found");
//     }
//   } catch (e) {
//     res.status(404).json({
//       error: e.message,
//     });
//   }
// };

// const createDB = async (req, res) => {
//   try {
//     //Create Product
//     const item = req.body;
//     const product = new Product({
//       ...item,
//     });
//     await product.save();
//     console.log("New Product is Created");
//     console.log(product);

//     res.status(200).json({
//       msg: "Successfully Created Product and Store in DataBase",
//       newItem: product,
//     });
//   } catch (e) {
//     res.status(404).json({
//       error: e.message,
//     });
//   }
// };

// const deleteDB = async (req, res) => {
//   try {
//     //  Delete Product
//     const id = req.params.id;
//     const product = await Product.findById(id);
//     if (product) {
//       await Product.deleteOne({ name: product.name });
//       res.status(200).json({
//         msg: "Product Delete Successfully",
//       });
//     } else {
//       throw new Error("Product Not Found");
//     }
//   } catch (e) {
//     res.status(404).json({
//       error: e.message,
//     });
//   }
// };

module.exports = {
  getAllTasks,
  createTask,
  getTask,
  updateTask,
  deleteTask,
  // getAllDB,
  // getSingleDB,
  // createDB,
  // deleteDB,
};
