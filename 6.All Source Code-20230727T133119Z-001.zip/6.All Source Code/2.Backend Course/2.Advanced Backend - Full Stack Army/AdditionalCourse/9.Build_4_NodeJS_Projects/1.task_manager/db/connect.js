const mongoose = require("mongoose");

const generateConnectionString = () => {
  let connectionUrl = process.env.DB_CONNECTION_URL;
  connectionUrl = `${connectionUrl}/${process.env.DB_NAME}`;

  return connectionUrl;
};

const dbConnect = async () => {
  try {
    const url = generateConnectionString();

    await mongoose.connect(url);
    console.log("Database Connected");
  } catch (e) {
    console.log(e.message);
    throw new Error("DataBase Connection Failed");
  }
};

module.exports = { dbConnect };
