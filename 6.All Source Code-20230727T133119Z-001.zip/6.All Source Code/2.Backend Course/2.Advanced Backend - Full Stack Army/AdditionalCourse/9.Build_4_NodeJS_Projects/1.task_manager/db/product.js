const { Schema, model } = require("mongoose");

const productSchema = new Schema({
  name: {
    type: String,
    required: true,
    maxLength: [20, "name is too long:~:maximum 20 chars"],
  },
  price: {
    type: Number,
    required: true,
    validate: {
      validator: (v) => {
        return v > 0;
      },
      message: "price must be greater than zero(0)",
    },
  },
});

const Product = model("Product", productSchema);

module.exports = { Product };
