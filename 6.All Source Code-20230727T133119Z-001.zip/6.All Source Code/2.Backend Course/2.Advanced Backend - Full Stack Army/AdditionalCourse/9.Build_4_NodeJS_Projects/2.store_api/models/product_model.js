const { Schema, model } = require("mongoose");

const productSchema = new Schema({
  name: {
    type: String,
    required: [true, "product name must be provided"],
    maxLength: [30, "product name upto 30 characters"],
    minLength: [5, "product name must be 5 characters"],
  },
  price: {
    type: Number,
    required: [true, "product price must be provided"],
    validate: {
      validator: (v) => {
        return v > 0;
      },
      message: "price must be greater than zero(0)",
    },
  },
  featured: {
    type: Boolean,
    default: false,
  },
  rating: {
    type: Number,
    default: 4.5,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  company: {
    type: String,
    enum: {
      values: ["ikea", "liddy", "caressa", "marcos"],
      message: "{VALUE} is not supported",
    },
  },
});

const Product = model("Product", productSchema);

module.exports = { Product };
