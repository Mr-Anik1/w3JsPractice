const mongoose = require("mongoose");

const getConnectionUrl = () => {
  let connectionUrl = process.env.DB_CONNECTION_URL;
  connectionUrl = `${connectionUrl}/${process.env.DB_NAME}`;

  return connectionUrl;
};

const dbConnect = async () => {
  try {
    const url = getConnectionUrl();

    await mongoose.connect(url);
    console.log("DataBase Connected");
  } catch (error) {
    console.log(error.message);
    throw new Error("DataBase Connection Failed");
  }
};

module.exports = { dbConnect };
