const express = require("express");
require("express-async-errors");
const { router } = require("../routes/products_routes");
const {
  notFoundHandler,
  globalErrorHandler,
} = require("../middleware/error_handler");

// Create App
const app = express();

/**
 * @Middleware
 */
app.use(express.json());
app.use("/api/v1/products", router);
app.use(notFoundHandler);
app.use(globalErrorHandler);

// Export App
module.exports = { app };
