const { Product } = require("../models/product_model");

const getAllProducts = async (req, res) => {
  try {
    const { name, company, featured, price } = req.query;
    const queryObject = {};

    if (name) {
      queryObject.name = name;
    }
    if (company) {
      queryObject.company = company;
    }
    if (price) {
      queryObject.price = +price;
    }
    if (featured) {
      queryObject.featured = featured === "true" ? true : false;
    }

    const products = await Product.find(queryObject);

    if (!products || products.length < 1) {
      console.log("Products Not Found");
      return res.status(404).json({ msg: "products not found" });
    }

    console.log("Successfully Retrive All Products");
    res
      .status(200)
      .json({ status: "success", nbHits: products.length, products });
  } catch (error) {
    console.log(error.message);
    res.status(500).json({
      msg: "internal server error",
    });
  }
};

/**
 * @Sort
 * http://localhost:4000/api/v1/products/static?sort=name
 * http://localhost:4000/api/v1/products/static?sort=price
 *
 * @fields
 * when we use .select(args) then only args keys will be showed
 * http://localhost:4000/api/v1/products/static?sort=name&fields=name,price,rating
 *
 * @limit
 * I set limit=3 for these reason only 3 products will be showed
 * http://localhost:4000/api/v1/products/static?sort=name&fields=name,price&limit=3
 *
 *
 * @numericFilters
 * filter those products which  price is greater than(>) 100 and rating greater than or equal(>=) 4.5
 * http://localhost:4000/api/v1/products/static?numericFilters=price>100,rating>=4.5
 *
 *
 * @All_In_One
 * http://localhost:4000/api/v1/products/static?numericFilters=price>=80&sort=-price&fields=name,price&limit=3
 *
 *
 */
const getAllProductsStatic = async (req, res) => {
  try {
    const { sort, fields, limit, numericFilters } = req.query;
    const queryObject = {};

    /**
     * @numericFilters
     * Very Important
     */
    if (numericFilters) {
      const operatorMap = {
        ">": "$gt",
        ">=": "$gte",
        "=": "$e",
        "<": "$lt",
        "<=": "$lte",
      };

      const regExp = /\b(>|>=|=|<|<= )\b/g;
      let filters = numericFilters.replace(
        regExp,
        (match) => `-${operatorMap[match]}-`
      );
      const options = ["price", "rating"];
      filters = filters.split(",").forEach((item) => {
        const [field, operator, value] = item.split("-");
        if (options.includes(field)) {
          queryObject[field] = { [operator]: Number(value) };
        }
      });
    }

    // find products with queryObject
    let results = Product.find(queryObject);

    if (sort) {
      results = results.sort(sort);
    } else {
      results = results.sort("createdAt");
    }

    if (fields) {
      const fieldsList = fields.split(",").join(" ");
      results = results.select(fieldsList);
    }

    if (limit) {
      results = results.limit(limit);
    }

    const products = await results;
    res
      .status(200)
      .json({ msg: "Static Products", nbHits: products.length, products });
  } catch (error) {
    res.status(400).json({ msg: error.message });
  }
};

module.exports = { getAllProducts, getAllProductsStatic };
