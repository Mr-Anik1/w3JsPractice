/**
 * This JS file use only for upload json data in the database and it's not have any relation with the express server
 */
require("dotenv").config();
const { dbConnect } = require("./db/connect");
const { Product } = require("./models/product_model");
const jsonProducts = require("./products.json");

const start = async () => {
  try {
    // DB Connection
    await dbConnect();
    // All Existing Products will be deleted
    await Product.deleteMany();
    // Upload JSON Products
    await Product.create(jsonProducts);
    console.log("JSON Data Successfully Uploded");

    // When we Successfull then must be exist to the process
    process.exit(0);
  } catch (error) {
    console.log(error.message);
    process.exit(1);
  }
};

start();
