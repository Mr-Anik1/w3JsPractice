//All controllers have been imported
const { postController } = require("./all_controllers/post");
const {
  allPlayersControllers,
  foundByIDController,
} = require("./all_controllers/get");
const { updateByID } = require("./all_controllers/patch");
const { fullUpdateById } = require("./all_controllers/put");
const { deleteController } = require("./all_controllers/delete");
/*




/--------///////--------------//////-------------////////-----/





*/

//All controllers have been exported
module.exports = {
  postController,
  allPlayersControllers,
  foundByIDController,
  updateByID,
  fullUpdateById,
  deleteController,
};
