const { readData, writeData } = require("./dataReadWrite");

const deleteController = (req, res) => {
  try {
    //Read File
    const data = readData();

    //delete item id
    const id = req.params?.id;
    if (!id) {
      throw error;
    }

    //find delete item index
    const deleteIndex = data.findIndex((item) => item.id === id);

    if (deleteIndex < 0) {
      return res.status(404).json({
        msg: `Player doesn't exist`,
      });
    }

    //Delete & Write File
    data.splice(deleteIndex, 1);
    writeData(data);

    res.status(204).json({
      msg: "Delete Successfully",
    });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

module.exports = { deleteController };
