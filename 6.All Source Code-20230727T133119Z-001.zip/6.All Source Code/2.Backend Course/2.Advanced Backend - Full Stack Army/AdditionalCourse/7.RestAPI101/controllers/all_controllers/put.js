const { readData, writeData } = require("./dataReadWrite");

const fullUpdateById = (req, res) => {
  //Read File
  const data = readData();

  //Target id
  const id = req.params?.id;
  if (!id) {
    throw error;
  }

  //index of player
  const playerIndex = data.findIndex((item) => item.id === id);

  //If the player doesn't exist
  if (playerIndex < 0) {
    const createPlayer = {
      id: id, //Set ID as the first key.
      ...req.body,
      id: id,
    };

    //Write file
    data.push(createPlayer);
    writeData(data);

    //success
    return res.status(201).json({
      msg: `Created New Player`,
      player: createPlayer,
    });
  }

  //You couldn't modify id, and id must be the first key of an object.
  const updatedPlayer = {
    id: id,
    ...req.body,
    id: id,
  };

  //Write File
  data[playerIndex] = updatedPlayer;
  writeData(data);

  res.status(200).json({
    msg: `Full Update Successfully`,
    player: updatedPlayer,
  });
};

module.exports = { fullUpdateById };
