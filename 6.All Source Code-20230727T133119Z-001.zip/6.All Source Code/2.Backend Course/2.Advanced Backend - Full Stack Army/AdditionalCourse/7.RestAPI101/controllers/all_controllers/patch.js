const { readData, writeData } = require("./dataReadWrite");

const updateByID = (req, res) => {
  try {
    //Read File
    const data = readData();

    //player id
    const id = req.params?.id;
    if (!id) {
      throw error;
    }

    //index of player
    const playerIndex = data.findIndex((item) => item.id === id);

    if (playerIndex < 0) {
      return res.status(404).json({
        msg: `Player doesn't exist`,
      });
    }

    //You couldn't modify id, and id must be the first key of an object.
    const updatedPlayer = {
      id: id, //Set ID as the first key.
      ...data[playerIndex],
      ...req.body,
      id: id,
    };

    //Write Data
    data[playerIndex] = updatedPlayer;
    writeData(data);

    res.status(200).json({
      msg: "Update Successfully",
      player: updatedPlayer,
    });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

module.exports = { updateByID };
