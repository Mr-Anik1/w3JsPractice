const fs = require("fs");
const path = require("path");

const dblocation = path.join(__dirname, "../../database/data.db");

//Read File
const readData = () => {
  const rawData = fs.readFileSync(dblocation);
  const data = JSON.parse(rawData);
  return data;
};

//Write File
const writeData = (data) => {
  return fs.writeFileSync(dblocation, JSON.stringify(data));
};

module.exports = { readData, writeData };
