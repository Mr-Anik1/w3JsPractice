const { readData } = require("./dataReadWrite");

const allPlayersControllers = (_req, res) => {
  try {
    //Read File
    const data = readData();

    res.status(200).json(data);
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

const foundByIDController = (req, res) => {
  try {
    //Read File
    const data = readData();

    //Targated ID
    const id = req.params?.id;
    if (!id) {
      throw error;
    }

    //find data
    const resData = data.find((value) => value.id === id);

    if (!resData) {
      return res.status(404).json({
        msg: `Player doesn't exist`,
      });
    }

    //success
    return res.status(200).json(resData);
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

module.exports = { allPlayersControllers, foundByIDController };
