//Not Found
const notFoundHandler = (_req, _res, next) => {
  const error = new Error("404 Not Found");
  error.status = 404;
  next(error);
};

const globalErrorHandler = (error, _req, res, _next) => {
  console.log(error);
  if (error.status) {
    return res.status(error.status).json({
      msg: `${error.message}`,
    });
  }
  res.status(500).json({
    msg: "Internal Server Error",
  });
};

module.exports = { notFoundHandler, globalErrorHandler };
