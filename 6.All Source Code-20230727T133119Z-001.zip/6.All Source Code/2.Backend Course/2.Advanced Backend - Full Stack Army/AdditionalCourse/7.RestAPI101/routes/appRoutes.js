const Router = require("express").Router();
const {
  postController,
  allPlayersControllers,
  foundByIDController,
  updateByID,
  fullUpdateById,
  deleteController,
} = require("../controllers/appControllers");

//Routes
Router.post("/", postController);
Router.get("/", allPlayersControllers);
Router.get("/:id", foundByIDController);
Router.patch("/:id", updateByID);
Router.put("/:id", fullUpdateById);
Router.delete("/:id", deleteController);

module.exports = { Router };
