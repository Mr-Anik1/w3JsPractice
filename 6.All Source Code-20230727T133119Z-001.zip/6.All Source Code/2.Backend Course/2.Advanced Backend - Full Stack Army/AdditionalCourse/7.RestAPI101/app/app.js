const express = require("express");
const { Router } = require("../routes/appRoutes");
const {
  notFoundHandler,
  globalErrorHandler,
} = require("../error/errorHandler");

//Create app
const app = express();

//Middleware
app.use(express.json());
app.use(Router);
app.use(notFoundHandler);
app.use(globalErrorHandler);

//Export app
module.exports = { app };
