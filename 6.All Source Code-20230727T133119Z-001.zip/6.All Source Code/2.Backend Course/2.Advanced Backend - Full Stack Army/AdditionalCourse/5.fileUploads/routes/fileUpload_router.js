const fileUploadRouter = require("express").Router();
const { upload } = require("../business_logics/fileUpload_logics");
const { uploadControllers } = require("../controllers/fileUploadControllers");

fileUploadRouter.post(
  "/uploadfile",
  upload.array("avatar", 10),
  uploadControllers
);

module.exports = { fileUploadRouter };
