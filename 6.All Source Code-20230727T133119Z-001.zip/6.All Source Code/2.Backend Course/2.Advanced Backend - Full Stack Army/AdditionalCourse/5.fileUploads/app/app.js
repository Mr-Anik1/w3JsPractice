const express = require("express");
const { notFoundHandler, globalErrorHandler } = require("../error/error_msg");
const { fileUploadRouter } = require("../routes/fileUpload_router");

//Create App
const app = express();

//Middleware
app.use(express.json());
app.use(fileUploadRouter);
app.use(notFoundHandler);
app.use(globalErrorHandler);

module.exports = app;
