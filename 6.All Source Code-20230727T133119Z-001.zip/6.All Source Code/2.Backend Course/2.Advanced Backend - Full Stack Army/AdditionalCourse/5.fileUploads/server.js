const http = require("http");
const app = require("./app/app");

//Server Creat
const server = http.createServer(app);

//Server Listening
server.listen(4000, () => {
  console.log(`Server is listening on PORT 4000`);
});
