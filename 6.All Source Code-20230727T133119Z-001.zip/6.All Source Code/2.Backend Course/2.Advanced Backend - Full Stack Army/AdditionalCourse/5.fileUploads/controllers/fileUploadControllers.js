const uploadControllers = (_req, res) => {
  try {
    res.status(200).json({
      msg: "File Uploaded Successfully",
    });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

module.exports = { uploadControllers };
