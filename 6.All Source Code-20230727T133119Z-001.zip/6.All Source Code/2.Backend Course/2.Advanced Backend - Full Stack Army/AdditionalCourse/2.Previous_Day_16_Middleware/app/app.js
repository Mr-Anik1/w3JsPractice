const express = require("express");
const router = require("./routes");
const { notFoundHandler, errorHandler } = require("./error");

//Express App
const app = express();

//Middleware
app.use(express.json());
app.use(router);
//Error Handling Middleware
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
//We have to export the app and import it into another file for testing purposes.
