const notFoundHandler = (req, res, next) => {
  const error = new Error("404 Not Found");
  error.status = 404;
  next(error);
};

const errorHandler = (error, req, res, next) => {
  console.log(error);
  if (error.status) {
    return res.status(error.status).send(`${error.message}`);
  }
  res.status(500).send(`Something Went Wrong`);
};

module.exports = { notFoundHandler, errorHandler };
