const path = require("path");
const fs = require("fs");

const testController = (req, res) => {
  try {
    res.status(200).json({ msg: "Hello this is test route" });
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

const personPOSTController = (req, res) => {
  try {
    const newData = req.body;

    //Read File
    const rawData = fs.readFileSync(path.join(__dirname, "../db/data.db"));
    const data = JSON.parse(rawData);

    //Write File
    data.push(newData);
    fs.writeFileSync(
      path.join(__dirname, "../db/data.db"),
      JSON.stringify(data)
    );

    res.json(data);
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

const personGETController = (req, res) => {
  try {
    const rawData = fs.readFileSync(path.join(__dirname, "../db/data.db"));
    const data = JSON.parse(rawData);

    res.status(200).json(data);
  } catch {
    const error = new Error("Bad Request");
    error.status = 400;
    throw error;
  }
};

const loggerMiddleware = (req, res, next) => {
  console.log(`${req.path} - ${req.method} - ${new Date().toISOString()}`);
  next();
};

module.exports = {
  testController,
  loggerMiddleware,
  personPOSTController,
  personGETController,
};
