const router = require("express").Router();
const {
  testController,
  loggerMiddleware,
  personPOSTController,
  personGETController,
} = require("./controllers");

//This middleware works like Morgan.
router.use(loggerMiddleware);

router.get("/test", testController);
router.post("/person", personPOSTController);
router.get("/person", personGETController);

module.exports = router;
