const http = require("http");
const app = require("./app/app");

//server has been created with app functionalities.
const server = http.createServer(app);

//Dynamic PORT
const PORT = process.env.PORT || 4000;

server.listen(PORT, () => {
  console.log(`Server is listening on PORT ${PORT}`);
});
