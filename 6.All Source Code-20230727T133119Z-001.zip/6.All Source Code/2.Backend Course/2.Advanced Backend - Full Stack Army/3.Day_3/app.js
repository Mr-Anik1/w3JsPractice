const express = require("express");
const fibonacci = require("./fibo");

const app = express();

/**
 * Test: http://localhost:4000/test?number=15
 * 
 *  {
     "targetValue": 610
    }
 * 
 */
app.get("/test", (req, res) => {
  try {
    const num = parseInt(req.query.number);
    res.json({ targetValue: fibonacci(num) });
  } catch {
    res.status(404).json({ msg: "Error! Something is wrong." });
  }
});

app.listen(4000, () => {
  console.log(`Server is listening on port 4000`);
});
