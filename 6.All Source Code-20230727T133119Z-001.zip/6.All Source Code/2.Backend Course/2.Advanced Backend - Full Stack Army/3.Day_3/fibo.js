const fibonacci = (num) => {
  if (num < 2) {
    return num;
  } else {
    return fibonacci(num - 1) + fibonacci(num - 2);
  }
};

module.exports = fibonacci;

/* 
    Fibonacci Seris: 0 1 1 2 3 5 8 13 21

                   3
         1.   ----fibo(4)---                               
            /               \
          /2                 \1
  2.  fibo(4-1=3)--    +    6.fibo(4-2=2) 
        /1          \1                  \1
  3. fibo(3-1=2) + 5.fibo(3-2=1)    7.fibo(2-1=1) 
      /1                 \                   \
  4. fibo(2-1=1)          1                   1
       |
       1

*/

/*

// generate random user with provided data data must be valid
const generateRandomUser = (userarray) => {
    const items = ['firstName' , 'lastName' , 'email' , 'avatar' , 'age' , 'address']
    return items.reduce((acc,cur,index) => {
         if(userarray[index]){
             acc[cur] = userarray[index]
         }
         return acc
     },{})
 }

*/
