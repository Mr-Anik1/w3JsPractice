const fs = require("fs");
const path = require("path");

const dblocation = path.join(__dirname, "../db/data.json");

const readData = () => {
  const rawData = fs.readFileSync(dblocation);
  const data = JSON.parse(rawData);
  return data;
};

const writeData = (data) => {
  return fs.writeFileSync(dblocation, JSON.stringify(data));
};

module.exports = { readData, writeData };
