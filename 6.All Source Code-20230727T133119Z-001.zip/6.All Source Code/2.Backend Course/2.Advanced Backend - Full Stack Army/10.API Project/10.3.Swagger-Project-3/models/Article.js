class Article {
  constructor(articles) {
    this.articles = articles;
  }

  async find() {
    return this.articles;
  }

  async findById(id) {
    return this.articles.find((article) => article.id === id);
  }

  async findByProp(prop) {
    return this.articles.find((article) => article[prop] === prop);
  }

  async search(searchTerm) {
    return this.articles.filter((article) =>
      article.title.toLowerCase().includes(searchTerm)
    );
  }

  async create(article, databaseConnection) {
    //article.id = this.articles[this.articles.length - 1].id + 1;
    article.id = this.articles.length + 1;
    article.createdAt = new Date().toISOString();
    article.updatedAt = new Date().toISOString();
    this.articles.push(article);
    databaseConnection.db.articles = this.articles; //Good One
    await databaseConnection.writeDB();

    return article;
  }

  async #sortASC(articles, sortBy) {
    return articles.sort((a, b) => {
      if (a[sortBy] > b[sortBy]) return 1;
      if (a[sortBy] < b[sortBy]) return -1;
      return 0;
    });
  }

  async #sortDSC(articles, sortBy) {
    return articles.sort((a, b) => {
      if (a[sortBy] > b[sortBy]) return -1;
      if (a[sortBy] < b[sortBy]) return 1;
      return 0;
    });
  }

  async sort(articles, sortBy = "updatedAt", sortType = "asc") {
    if (sortType === "asc") {
      return await this.#sortASC(articles, sortBy);
    }
    if (sortType === "dsc") {
      return await this.#sortDSC(articles, sortBy);
    }
  }

  async pagination(articles, page, limit) {
    const skip = page * limit - limit;
    const totalItems = articles.length;
    const totalPage = Math.ceil(totalItems / limit);
    const result = articles.slice(skip, skip + limit);

    return {
      result,
      totalItems,
      totalPage,
      hasNext: page < totalPage,
      hasPrev: page > 1,
    };
  }
}

module.exports = { Article };
