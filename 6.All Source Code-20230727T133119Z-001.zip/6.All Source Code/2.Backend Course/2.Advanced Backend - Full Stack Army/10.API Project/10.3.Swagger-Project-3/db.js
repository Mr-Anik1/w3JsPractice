const fs = require("fs/promises");
const path = require("path");

class DatabaseConnection {
  constructor(dbURL) {
    this.db = null;
    this.dbURL = dbURL;
  }

  async connect() {
    const rawDB = await fs.readFile(this.dbURL, { encoding: "utf-8" });
    this.db = JSON.parse(rawDB);
  }

  async writeDB() {
    if (this.db) {
      await fs.writeFile(this.dbURL, JSON.stringify(this.db));
    }
  }

  async getDB() {
    if (this.db) {
      return this.db;
    }

    await this.connect();
    return this.db;
  }
}

const databaseConnection = new DatabaseConnection(
  path.resolve(process.env.DB_URL)
);

module.exports = {
  databaseConnection,
};

// const test = async () => {
//   const db = await connection.getDB();
//   db.users.push("Test");
//   connection.writeDB();
//   console.log(db);
// };
// test();

// const testFunc = async () => {
//   const dbConnection = new DatabaseConnection();
//   const db = await dbConnection.getDB();

//   //db.users.push("Mr.Alex");

//   console.log(db);

//   dbConnection.writeDB();
// };

// testFunc();

// module.exports = {
//     db: connection.getDB,
//     write: connection.writeDB,
//   };

// Database path with process.env:
// const pathItems = process.env.DB_URL.split("/");
// console.log(path.resolve(...pathItems)); //windows or linux doesn't matter, it will work perfectly any operating system .

//console.log(path.resolve(process.env.DB_URL));

//Remove Individual Items
// const removeItem = db.users.lastIndexOf("Hello");
// db.users.splice(removeItem, 1);
// console.log(removeItem);
