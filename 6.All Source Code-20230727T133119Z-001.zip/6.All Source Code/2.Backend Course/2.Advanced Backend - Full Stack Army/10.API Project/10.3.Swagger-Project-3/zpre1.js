require("dotenv").config();
const express = require("express");
const swaggerUI = require("swagger-ui-express");
const Yaml = require("yamljs");
const swaggerDoc = Yaml.load("./openapi.yaml");

const { connection } = require("./db");

//Create app
const app = express();

//Middleware
app.use(express.json());
app.use("/docs", swaggerUI.serve, swaggerUI.setup(swaggerDoc));

//Routes
app.get("/health", (_req, res) => {
  res.status(200).json({
    health: "OK",
  });
});

/**
 *
 * @Testing_all_routes
 *
 */

//All Articles
app.get("/api/v1/articles", async (req, res) => {
  //1. Extract Query Params
  const page = +req.query.page || 1;
  const limit = +req.query.limit || 10;
  const sortType = req.query.sort_type || "asc";
  const sortBy = req.query.sort_by || "updatedAt";
  const searchTerm = req.query.search || "";

  //2. Call article service to fetch all article
  const db = await connection.getDB();
  let articles = db.articles;

  //Filter based on search term
  if (searchTerm) {
    articles = articles.filter((article) =>
      article.title.toLowerCase().includes(searchTerm)
    );
  }

  //Sorting
  articles.sort((a, b) => {
    if (sortType === "asc") {
      if (a[sortBy] > b[sortBy]) return 1;
      if (a[sortBy] < b[sortBy]) return -1;
      return 0;
    }
    if (sortType === "dsc") {
      if (a[sortBy] > b[sortBy]) return -1;
      if (a[sortBy] < b[sortBy]) return 1;
      return 0;
    }
  });

  // Pagination ~ How it is working I don't understand
  const skip = page * limit - limit;
  let resultedArticles = articles.slice(skip, skip + limit);
  let totalItems = articles.length;
  let totalPage = Math.ceil(articles.length / limit);

  const transformedArticles = resultedArticles.map((article) => {
    const transformed = { ...article };
    transformed.author = {
      id: transformed.authorId,
      // TODO: find author name
    };
    transformed.link = `/articles/${transformed.id}`;
    delete transformed.body;
    delete transformed.authorId;

    return transformed;
  });

  const response = {
    data: transformedArticles,
    pagination: {
      page,
      limit,
      totalPage,
      totalItems,
    },
    links: {
      self: `/articles?page=${page}&limit=${limit}`,
    },
  };

  // prev page
  if (page > 1) {
    response.pagination.prev = page - 1;
    response.links.prev = `/articles?page=${page - 1}&limit=${limit}`;
  }
  // next page
  if (page < totalPage) {
    response.pagination.next = page + 1;
    response.links.next = `/articles?page=${page + 1}&limit=${limit}`;
  }

  //3. Generate Message Response
  res.status(200).json(response);
});

// Pagination:
// next: page + 1,
// prev: page - 1 > 0 ? page - 1 : 1,

// Links:
// next: `/articles?page=${page + 1}&limit=${limit}`,
// prev: `/articles?page=${page - 1 > 0 ? page - 1 : 1}&limit=${limit}`,

//Simple Sort localeCompare():

// articles.sort((a, b) => {
//   if (sortType === "asc") return a[sortBy].toString().localeCompare(b[sortBy].toString())
//   if (sortType === "dsc") return b[sortBy].toString().localeCompare(a[sortBy].toString())
// });

// app.post("/api/v1/articles", (req, res) => {
//   res.status(201).json({
//     path: "/articles",
//     method: "post",
//   });
// });

// //Authentication
// app.post("/api/v1/auth/signup", (req, res) => {
//   res.status(201).json({
//     path: "/auth/signup",
//     method: "post",
//   });
// });

// app.post("/api/v1/auth/signin", (req, res) => {
//   res.status(200).json({
//     path: "/auth/signin",
//     method: "post",
//   });
// });

// //Individual Articles
// app.get("/api/v1/articles/:id", (req, res) => {
//   res.status(200).json({
//     path: `/articles/${req.params.id}`,
//     method: "get",
//   });
// });

// app.put("/api/v1/articles/:id", (req, res) => {
//   res.status(201).json({
//     path: `/articles/${req.params.id}`,
//     method: "put",
//   });
// });

// app.patch("/api/v1/articles/:id", (req, res) => {
//   res.status(200).json({
//     path: `/articles/${req.params.id}`,
//     method: "patch",
//   });
// });

// app.delete("/api/v1/articles/:id", (req, res) => {
//   res.status(204).json({
//     path: `/articles/${req.params.id}`,
//     method: "delete",
//   });
// });

app.listen(4000, () => {
  console.log(`Server is listening on port 4000`);
});
