require("dotenv").config();
const express = require("express");
const swaggerUI = require("swagger-ui-express");
const Yaml = require("yamljs");
const swaggerDoc = Yaml.load("./openapi.yaml");
const OpenApiValidator = require("express-openapi-validator");

const { databaseConnection } = require("./db");
const articleServices = require("./services/article");

//Create app
const app = express();

//Middleware
app.use(express.json());
app.use("/docs", swaggerUI.serve, swaggerUI.setup(swaggerDoc));
app.use(
  OpenApiValidator.middleware({
    apiSpec: "./openapi.yaml",
  })
);
app.use((req, _res, next) => {
  req.user = {
    id: 99,
    name: "Tesla",
  };
  next();
});

//Routes
app.get("/health", (_req, res) => {
  res.status(200).json({
    health: "OK",
  });
});

/**
 *
 * @Testing_all_routes
 *
 */

//Get All Articles
app.get("/api/v1/articles", async (req, res) => {
  //1. Extract Query Params
  const page = +req.query.page || 1;
  const limit = +req.query.limit || 10;
  const sortType = req.query.sort_type || "asc";
  const sortBy = req.query.sort_by || "updatedAt";
  const searchTerm = req.query.search || "";

  let { articles, totalItems, totalPage, hasNext, hasPrev } =
    await articleServices.findArticles({
      ...req.query,
      page,
      limit,
      sortType,
      sortBy,
      searchTerm,
    });

  articles = articleServices.transformedArticles({ articles });

  const response = {
    data: articles,
    pagination: {
      page,
      limit,
      totalPage,
      totalItems,
    },
    links: {
      self: `/articles?page=${page}&limit=${limit}`,
    },
  };

  // prev page
  if (hasPrev) {
    response.pagination.prev = page - 1;
    response.links.prev = `/articles?page=${page - 1}&limit=${limit}`;
  }
  // next page
  if (hasNext) {
    response.pagination.next = page + 1;
    response.links.next = `/articles?page=${page + 1}&limit=${limit}`;
  }

  //3. Generate Message Response
  res.status(200).json(response);
});

// Create Articles
app.post("/api/v1/articles", async (req, res) => {
  // Step-1: Destructure the request body
  const { title, body, cover, status } = req.body;

  // Step-2: Invoke the service function
  let article = await articleServices.createArticle({
    title,
    body,
    cover,
    status,
    authorId: req.user.id,
  });

  // Generate Response
  const response = {
    code: 201,
    message: "Article Created Successfully",
    data: article,
    links: {
      self: `articles/${article.id}`,
      author: `articles/${article.id}/author`,
      comments: `articles/${article.id}/comments`,
    },
  };

  res.status(201).json(response);
});

// Error Handling
app.use((err, req, res, next) => {
  // format error
  res.status(err.status || 500).json({
    message: err.message,
    errors: err.errors,
  });
});

(async () => {
  //First Connect to DataBase
  await databaseConnection.connect();
  console.log("DataBase Connected");

  // Then Server Listen
  app.listen(4000, () => {
    console.log(`Server is listening on port 4000`);
  });
})();
