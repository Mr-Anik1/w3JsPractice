require("dotenv").config();
const express = require("express");
const swaggerUI = require("swagger-ui-express");
const Yaml = require("yamljs");
const swaggerDoc = Yaml.load("./openapi.yaml");
const OpenApiValidator = require("express-openapi-validator");

// const { connection } = require("./db");
const { Article } = require("./models/Article");
const articleServices = require("./services/article");

//Create app
const app = express();

//Middleware
app.use(express.json());
app.use("/docs", swaggerUI.serve, swaggerUI.setup(swaggerDoc));
app.use(
  OpenApiValidator.middleware({
    apiSpec: "./openapi.yaml",
  })
);

//Routes
app.get("/health", (_req, res) => {
  res.status(200).json({
    health: "OK",
  });
});

/**
 *
 * @Testing_all_routes
 *
 */

//All Articles
app.get("/api/v1/articles", async (req, res) => {
  //1. Extract Query Params
  const page = +req.query.page || 1;
  const limit = +req.query.limit || 10;
  const sortType = req.query.sort_type || "asc";
  const sortBy = req.query.sort_by || "updatedAt";
  const searchTerm = req.query.search || "";

  let { articles, totalItems, totalPage, hasNext, hasPrev } =
    await articleServices.findArticles({
      ...req.query,
      page,
      limit,
      sortType,
      sortBy,
      searchTerm,
    });

  articles = articleServices.transformedArticles({ articles });

  const response = {
    data: articles,
    pagination: {
      page,
      limit,
      totalPage,
      totalItems,
    },
    links: {
      self: `/articles?page=${page}&limit=${limit}`,
    },
  };

  // prev page
  if (hasPrev) {
    response.pagination.prev = page - 1;
    response.links.prev = `/articles?page=${page - 1}&limit=${limit}`;
  }
  // next page
  if (hasNext) {
    response.pagination.next = page + 1;
    response.links.next = `/articles?page=${page + 1}&limit=${limit}`;
  }

  //3. Generate Message Response
  res.status(200).json(response);
});

// Pagination:
// next: page + 1,
// prev: page - 1 > 0 ? page - 1 : 1,

// Links:
// next: `/articles?page=${page + 1}&limit=${limit}`,
// prev: `/articles?page=${page - 1 > 0 ? page - 1 : 1}&limit=${limit}`,

//Simple Sort localeCompare():

// articles.sort((a, b) => {
//   if (sortType === "asc") return a[sortBy].toString().localeCompare(b[sortBy].toString())
//   if (sortType === "dsc") return b[sortBy].toString().localeCompare(a[sortBy].toString())
// });

// app.post("/api/v1/articles", (req, res) => {
//   res.status(201).json({
//     path: "/articles",
//     method: "post",
//   });
// });

// //Authentication
// app.post("/api/v1/auth/signup", (req, res) => {
//   res.status(201).json({
//     path: "/auth/signup",
//     method: "post",
//   });
// });

// app.post("/api/v1/auth/signin", (req, res) => {
//   res.status(200).json({
//     path: "/auth/signin",
//     method: "post",
//   });
// });

// //Individual Articles
// app.get("/api/v1/articles/:id", (req, res) => {
//   res.status(200).json({
//     path: `/articles/${req.params.id}`,
//     method: "get",
//   });
// });

// app.put("/api/v1/articles/:id", (req, res) => {
//   res.status(201).json({
//     path: `/articles/${req.params.id}`,
//     method: "put",
//   });
// });

// app.patch("/api/v1/articles/:id", (req, res) => {
//   res.status(200).json({
//     path: `/articles/${req.params.id}`,
//     method: "patch",
//   });
// });

// app.delete("/api/v1/articles/:id", (req, res) => {
//   res.status(204).json({
//     path: `/articles/${req.params.id}`,
//     method: "delete",
//   });
// });

// Error Handling
app.use((err, req, res, next) => {
  // format error
  res.status(err.status || 500).json({
    message: err.message,
    errors: err.errors,
  });
});

app.listen(4000, () => {
  console.log(`Server is listening on port 4000`);
});
