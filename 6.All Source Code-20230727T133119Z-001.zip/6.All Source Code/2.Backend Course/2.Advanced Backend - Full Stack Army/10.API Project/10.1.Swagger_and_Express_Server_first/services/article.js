const { Article } = require("../models/Article");

const findArticles = async ({
  page = 1,
  limit = 5,
  sortType = "asc",
  sortBy = "updatedAt",
  searchTerm = "",
}) => {
  //2. Call article service to fetch all article
  const articleInstance = new Article();
  await articleInstance.init();
  let articles;

  //Filter based on search term
  if (searchTerm) {
    articles = await articleInstance.search(searchTerm);
  } else {
    articles = await articleInstance.find();
  }

  //Sorting
  articles = await articleInstance.sort(articles, sortBy, sortType);

  // Pagination ~ How it is working I don't understand
  const { result, totalItems, totalPage, hasNext, hasPrev } =
    await articleInstance.pagination(articles, page, limit);

  return {
    articles: result,
    totalItems,
    totalPage,
    hasNext,
    hasPrev,
  };
};

const transformedArticles = ({ articles = [] }) => {
  return articles.map((article) => {
    const transformed = { ...article };
    transformed.author = {
      id: transformed.authorId,
      // TODO: find author name -> authorService
    };
    transformed.link = `/articles/${transformed.id}`;
    delete transformed.body;
    delete transformed.authorId;

    return transformed;
  });
};

module.exports = {
  findArticles,
  transformedArticles,
};
