const { connection } = require("../db");

class Article {
  constructor() {
    this.articles = [];
    // this.init();
  }

  async init() {
    const db = await connection.getDB();
    this.articles = db.articles;
  }

  async find() {
    return this.articles;
  }

  async findById(id) {
    return this.articles.find((article) => article.id === id);
  }

  async findByProp(prop) {
    return this.articles.find((article) => article[prop] === prop);
  }

  async search(searchTerm) {
    return this.articles.filter((article) =>
      article.title.toLowerCase().includes(searchTerm)
    );
  }

  async #sortASC(articles, sortBy) {
    return articles.sort((a, b) => {
      if (a[sortBy] > b[sortBy]) return 1;
      if (a[sortBy] < b[sortBy]) return -1;
      return 0;
    });
  }

  async #sortDSC(articles, sortBy) {
    return articles.sort((a, b) => {
      if (a[sortBy] > b[sortBy]) return -1;
      if (a[sortBy] < b[sortBy]) return 1;
      return 0;
    });
  }

  async sort(articles, sortBy = "updatedAt", sortType = "asc") {
    if (sortType === "asc") {
      return await this.#sortASC(articles, sortBy);
    }
    if (sortType === "dsc") {
      return await this.#sortDSC(articles, sortBy);
    }
  }

  async pagination(articles, page, limit) {
    const skip = page * limit - limit;
    const totalItems = articles.length;
    const totalPage = Math.ceil(totalItems / limit);
    const result = articles.slice(skip, skip + limit);

    return {
      result,
      totalItems,
      totalPage,
      hasNext: page < totalPage,
      hasPrev: page > 1,
    };
  }
}

module.exports = { Article };
