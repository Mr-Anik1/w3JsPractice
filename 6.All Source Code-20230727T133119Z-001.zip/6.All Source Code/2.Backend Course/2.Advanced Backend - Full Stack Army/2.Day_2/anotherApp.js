const http = require("http");
const fs = require("fs");

//Students Array
// let students = [
//   { id: 1, firstName: "Mr.", lastName: "Anik", age: 20 },
//   { id: 2, firstName: "Issac", lastName: "Newton", age: 35 },
// ];

//Reusable Function
function sendResponse(
  res,
  { contentType = "application/json", status = 200, body = {} }
) {
  res.writeHead(status, { "content-type": contentType });
  res.write(JSON.stringify(body));
  res.end();
}

//Smart Way Solution With hash map
let routes = {
  "/": {
    GET: (_req, res) => {
      sendResponse(res, {
        body: {
          msg: "Welcome The Advance Backend Community",
        },
      });
    },
  },
  "/students": {
    GET: (_req, res) => {
      //Read File
      const rawStudents = fs.readFileSync("./data/db.json");
      const students = JSON.parse(rawStudents);

      sendResponse(res, {
        body: students,
      });
    },
    POST: (req, res) => {
      let body = "";

      req.on("data", (chunk) => {
        body += chunk.toString();
      });

      req.on("end", () => {
        let peylod = JSON.parse(body);

        //Read File
        const rawStudents = fs.readFileSync("./data/db.json");
        const students = JSON.parse(rawStudents);

        //Write File
        students.push(peylod);
        fs.writeFileSync("./data/db.json", JSON.stringify(students));

        sendResponse(res, {
          body: { msg: "Student Created", students },
          status: 201,
        });
      });
    },
  },
  "/creator": {
    GET: (_req, res) => {
      sendResponse(res, {
        body: {
          msg: "Mr.Anik",
        },
      });
    },
  },
  default: (_req, res) => {
    sendResponse(res, {
      status: 404,
      body: { msg: "Resource Not Found" },
    });
  },
};

const server = http.createServer((req, res) => {
  const { url, method } = req;
  const currentRout = routes[url] || routes.default;
  const handler = currentRout[method] || routes.default;
  handler(req, res);
});

server.listen(4000, () => {
  console.log("Server is listening on port 4000");
});
