const http = require("http");
const fs = require("fs");

// Students Array
let students = [
  { id: 1, firstName: "Mr.", lastName: "Anik", age: 20 },
  { id: 2, firstName: "Issac", lastName: "Newton", age: 35 },
];

//Reusable Function
function sendResponse(
  res,
  { contentType = "application/json", status = 200, body = {} }
) {
  res.writeHead(status, { "content-type": contentType });
  res.write(JSON.stringify(body));
  res.end();
}

//Create Server
const server = http.createServer((req, res) => {
  console.log(`Request is comming...`);

  if (req.url === "/") {
    sendResponse(res, {
      body: { msg: "Welcome to the Advance Backend Course" },
    });
  } else if (req.url === "/creator" && req.method === "GET") {
    sendResponse(res, {
      body: {
        msg: "Mr.Anik",
      },
    });
  } else if (req.url === "/students" && req.method === "POST") {
    //I want this will be post request & it will run on postman or browser terminal ~ Testing Perpose
    let body = "";

    //This one collect data
    req.on("data", (chunk) => {
      body += chunk.toString();
    });

    //This one indicate all data has been received & ending the session.
    req.on("end", () => {
      //Create Students ~ Push data students array.
      let peylod = JSON.parse(body);
      students.push(peylod);

      sendResponse(res, {
        body: { msg: "Student Created", students },
        status: 201,
      });
    });
  } else if (req.url === "/students" && req.method === "GET") {
    sendResponse(res, {
      body: students,
    });
  } else {
    sendResponse(res, {
      status: 404,
      body: { msg: "Resource not found" },
    });
  }
});

//Server Listen
server.listen(4000, () => {
  console.log(`Server is listening on port 4000`);
});

/**
 *@POST_Method_run_in_browser_console
 * In here I send data JSON.stringify() format
 * 
   fetch("http://localhost:4000/students", {
     method: "POST",
     body: JSON.stringify({
       id: 3,
       firstName: "Bill",
       lastName: "Gates",
       age: 65,
     }),
   })
    .then((res) => res.json())
    .then((data) => console.log(data))
    .catch((e) => console.log(e));
 * 
 *
 */
