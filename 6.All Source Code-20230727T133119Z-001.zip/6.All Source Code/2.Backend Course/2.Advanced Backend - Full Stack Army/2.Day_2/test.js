// (async () => {
//   try {
//     let res = await fetch("http://localhost:4000/students");
//     let fetchData = await res.json();
//     console.log(fetchData);
//   } catch (err) {
//     console.log(err);
//   }
// })();

fetch("http://localhost:4000/students", {
  method: "POST",
  body: JSON.stringify({
    id: 5,
    firstName: "Sukanto",
    lastName: "Vattacharje",
    age: 18,
  }),
})
  .then((res) => res.json())
  .then((data) => console.log(data))
  .catch((e) => console.log(e));
