const { Schema, model } = require("mongoose");

const productSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      minLength: [5, "Name is too short ~ minimum 5 chars needed"],
      maxLength: [30, "Name is too long ~ upto 30 chars"],
      validate: {
        validator: (v) => {
          return true;
        },
        message: "Custom Validation Failed",
      },
    },
    price: {
      type: Number,
      required: true,
      validate: {
        validator: (v) => {
          return v > 0;
        },
        message: "Price can not be zero or negative",
      },
    },
    tags: {
      type: [String],
    },
  },
  {}
);

/**
 * count tag length with virtual
 */
productSchema.virtual("tagCount").get(function () {
  return this.tags.length;
});

/**
 * find same products
 */
productSchema.methods.findAllWithSameName = function (cb) {
  return model("Product").find({ name: this.name }, cb);
};

const Product = model("Product", productSchema);

module.exports = {
  Product,
};
