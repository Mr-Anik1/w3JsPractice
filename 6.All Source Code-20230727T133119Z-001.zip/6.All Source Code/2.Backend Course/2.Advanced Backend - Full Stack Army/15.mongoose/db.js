const mongoose = require("mongoose");

/**
 * This function will generate and return a database connection string from environment variable.
 * @returns String
 */
const generateConnectionString = () => {
  let connectionURL = process.env.DB_CONNECTION_URL;
  connectionURL = connectionURL.replace("<username>", process.env.DB_USERNAME);
  connectionURL = connectionURL.replace("<password>", process.env.DB_PASSWORD);
  connectionURL = `${connectionURL}/${process.env.DB_NAME}?${process.env.DB_URL_QUERY}`;

  return connectionURL;
};

/**
 * connect to the mongodb database using mongoose
 */
const connect = async () => {
  const url = generateConnectionString();
  const options = { autoIndex: false };

  await mongoose.connect(url, options);
  console.log("DataBase Connected");
};

module.exports = {
  connect,
};
