require("dotenv").config();
const mongoose = require("mongoose");
const { connect } = require("./db");
const { Product } = require("./Product");

const main = async () => {
  try {
    // Database connection
    await connect();

    // const product1 = new Product({
    //   name: "F-16 fighter jet",
    //   price: 1234,
    //   tags: ["fighter jet", "america", "war", 2023],
    // });
    // await product1.save();
    // console.log("Product Created");
    // console.log(product1);

    // Retrive Product
    const products = await Product.find({});
    console.log(products);
  } catch (e) {
    console.log("Error:", e.message);
  }
};
main();

/*
const product = await Product.findById("64b9d23cf10c4649c65d928f");
console.log("TagLength: ", product.tagCount);
const sameProducts = await product.findAllWithSameName();
console.log(sameProducts);
*/
