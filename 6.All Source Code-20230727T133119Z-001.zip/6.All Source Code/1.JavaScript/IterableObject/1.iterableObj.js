let user = {
  id: 1,
  name: "Victor",
  surname: "Alight",
  age: 16,
  isStudent: true,
};

user[Symbol.iterator] = function* () {
  for (let k of Object.keys(this)) {
    yield [k, this[k]];
  }
};

for (let [k, v] of user) {
  console.log(k);
}

/* 
//Result for => console.log(k);
id
name
surname
age
isStudent

// Result for => console.log(k, v);
id 1
name Victor
surname Alight
age 16
isStudent true

*/
