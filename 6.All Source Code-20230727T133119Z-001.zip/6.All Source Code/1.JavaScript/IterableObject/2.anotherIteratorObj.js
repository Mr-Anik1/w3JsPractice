let personObj = {
  nam: "Anik",
  age: 20,
  year: 2023,
  status: "Web Devoloper",
  location: "Gazipur",
  targetYear: 2027,
  binaryPosition: 1,
};

personObj[Symbol.iterator] = function () {
  let propertiesArray = Object.keys(this);
  return {
    count: 0,
    motherObj: this,
    next() {
      if (this.count < propertiesArray.length) {
        return {
          done: false,
          value: this.motherObj[propertiesArray[this.count++]],
        };
      } else {
        return {
          done: true,
        };
      }
    },
  };
};

for (let k of personObj) {
  console.log(k);
}
/*
//Result:

Anik
20
2023
Web Devoloper
Gazipur
2027
1
 
*/

/**
 * @Iterable_Object
 *
 * @key_value
 */

// let personObj = {
//   nam: "Anik",
//   age: 20,
//   year: 2023,
//   status: "Web Devoloper",
//   location: "Gazipur",
//   targetYear: 2027,
//   binaryPosition: 1,
// };

// personObj[Symbol.iterator] = function () {
//   let propertiesArray = Object.keys(this);
//   return {
//     count: 0,
//     next() {
//       if (this.count < propertiesArray.length) {
//         return {
//           done: false,
//           value:propertiesArray[this.count++],
//         };
//       } else {
//         return {
//           done: true,
//         };
//       }
//     },
//   };
// };

// for (let k of personObj) {
//   console.log(k, personObj[k]);
// }

/*
//Result for => console.log(k, personObj[k]);

nam Anik
age 20
year 2023
status Web Devoloper
location Gazipur
targetYear 2027
binaryPosition 1

*/

/**
 * @chatGpt_Answer
 */

// let user = {
//   id: 1,
//   name: "Victor",
//   surname: "Alight",
//   age: 16,
//   isStudent: true,
//   [Symbol.iterator]: function () {
//     let properties = Object.keys(this);
//     let count = 0;
//     let isDone = false;
//     let next = () => {
//       if (count >= properties.length) {
//         isDone = true;
//       }
//       let value = this[properties[count++]];
//       return { done: isDone, value: value };
//     };
//     return { next: next };
//   },
// };

// for (let property of user) {
//   console.log(property);
// }
