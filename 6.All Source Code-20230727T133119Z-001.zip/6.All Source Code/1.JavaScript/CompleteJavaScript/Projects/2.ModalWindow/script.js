let modal = document.querySelector(".modal");
let overlay = document.querySelector(".overlay");
let btnCloseModal = document.querySelector(".close-modal");
let btnShowModel = document.querySelectorAll(".show-modal");

let close = () => {
  modal.classList.add("hidden");
  overlay.classList.add("hidden");
};

let show = () => {
  modal.classList.remove("hidden");
  overlay.classList.remove("hidden");
};

for (let v of btnShowModel) {
  v.addEventListener("click", show);
}

btnCloseModal.addEventListener("click", close);
overlay.addEventListener("click", close);

// For ESC
document.addEventListener("keydown", (e) => {
  if (e.key == "Escape" && !modal.classList.contains("hidden")) {
    close();
  }
});
