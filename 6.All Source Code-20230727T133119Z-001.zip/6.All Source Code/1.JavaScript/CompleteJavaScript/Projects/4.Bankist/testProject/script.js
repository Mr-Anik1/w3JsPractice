const account1 = {
  owner: "Manik Chandra",
  movements: [200, 450, -400, 3000, -650, -130, 70, 1300],
  interestRate: 1.2, // %
  pin: 1111,
};

const account2 = {
  owner: "Tonik Vai",
  movements: [5000, 3400, -150, -790, -3210, -1000, 8500, -30],
  interestRate: 1.5,
  pin: 2222,
};

const account3 = {
  owner: "Sir Issac Newton",
  movements: [200, -200, 340, -300, -20, 50, 400, -460],
  interestRate: 0.7,
  pin: 3333,
};

const account4 = {
  owner: "Mr. Anik",
  movements: [430, 1000, 700, 50, 90],
  interestRate: 1,
  pin: 4444,
};

const accounts = [account1, account2, account3, account4];

// Elements
let labelWelcome = document.querySelector(".welcome");
let labelDate = document.querySelector(".date");
let labelBalance = document.querySelector(".balance__value");
let labelSumIn = document.querySelector(".summary__value--in");
let labelSumOut = document.querySelector(".summary__value--out");
let labelSumInterest = document.querySelector(".summary__value--interest");
let labelTimer = document.querySelector(".timer");

let containerApp = document.querySelector(".app");
let containerMovements = document.querySelector(".movements");

//BTN
let btnLogin = document.querySelector(".login__btn");
let btnTransfer = document.querySelector(".form__btn--transfer");
let btnLoan = document.querySelector(".form__btn--loan");
let btnClose = document.querySelector(".form__btn--close");
let btnSort = document.querySelector(".btn--sort");

let inputLoginUsername = document.querySelector(".login__input--user");
let inputLoginPin = document.querySelector(".login__input--pin");
let inputTransferTo = document.querySelector(".form__input--to");
let inputTransferAmount = document.querySelector(".form__input--amount");
let inputLoanAmount = document.querySelector(".form__input--loan-amount");
let inputCloseUsername = document.querySelector(".form__input--user");
let inputClosePin = document.querySelector(".form__input--pin");

// const currencies = new Map([
//   ["USD", "United States dollar"],
//   ["EUR", "Euro"],
//   ["GBP", "Pound sterling"],
// ]);

const movements = [200, 450, -400, 3000, -650, -130, 70, 1300];

//Create User Name
let createUserName = (userAccount) => {
  return userAccount.forEach((acc) => {
    acc.user = acc.owner
      .split(" ")
      .map((nam) => nam[0])
      .join("")
      .toLowerCase();
  });
};
createUserName(accounts);

/**
 * @Very_Important_Section
 * In this section create currentAccount.
 */
//FOR EVENT
let currentAccount;

//Account Login
btnLogin.addEventListener("click", (e) => {
  //for html form
  e.preventDefault();

  //find target object
  currentAccount = accounts.find(
    (acc) => acc.user === inputLoginUsername.value
  );
  let pin = +inputLoginPin.value;

  //If user or pin doesn't correct
  if (!currentAccount || currentAccount?.pin !== pin) {
    containerApp.style.opacity = 0;
    labelWelcome.textContent = `Log in to get started`;
    //clear user & pin value
    inputLoginUsername.value = "";
    inputLoginPin.value = "";
  }

  //If user & pin is correct
  if (currentAccount?.pin === pin) {
    containerApp.style.opacity = 100;

    //Welcome Message
    labelWelcome.textContent = `Welcome Back ${
      currentAccount.owner.split(" ")[0]
    }`;

    //updateUI() function argument recive current account object.
    updateUI(currentAccount);

    //clear user & pin value
    inputLoginUsername.value = "";
    inputLoginPin.value = "";
  }
});

//Accounts Movements
function displayMovements(movements, sorted = false) {
  //clear previous manually stored movements
  containerMovements.textContent = "";

  //Sort Movement
  let movs = sorted ? movements.slice().sort((a, b) => a - b) : movements;

  movs.forEach((amount, i) => {
    let type = amount > 0 ? "deposit" : "withdrawal";

    let html = `<div class="movements__row">
    <div class="movements__type movements__type--${type}">${i + 1} ${type}</div>
    <div class="movements__date">3 days ago</div>
    <div class="movements__value">${amount}€</div>
  </div>`;

    //Dynamically Create all type of movements
    containerMovements.insertAdjacentHTML("afterbegin", html);
  });
}

/**
 * updateUI() function argument recive current account object for this reason I used currentAccount.movements or acc.movements. If I want to use current account object in any function argument then call them inside updateUI() function.
 */
function updateUI(acc) {
  //movements
  displayMovements(acc.movements);

  //summary
  calculateSummary(acc);
}

//sort movements
let sorted = false;
btnSort.addEventListener("click", (e) => {
  e.preventDefault();
  displayMovements(currentAccount.movements, !sorted);
  sorted = !sorted;
});

//Summary
function calculateSummary(currentAccount) {
  //amount input
  let input = currentAccount.movements
    .filter((amount) => amount > 0)
    .reduce((acc, cur) => acc + cur, 0);
  labelSumIn.textContent = `${input}€`;

  //amount out
  let out = currentAccount.movements
    .filter((amount) => amount < 0)
    .reduce((acc, cur) => acc + cur, 0);
  labelSumOut.textContent = `${Math.abs(out)}€`;

  //amount interest
  let interest = currentAccount.movements
    .filter((amount) => amount > 0)
    .map((diposit) => (diposit * currentAccount.interestRate) / 100)
    .filter((interest) => interest >= 1)
    .reduce((acc, cur) => acc + cur, 0);
  labelSumInterest.textContent = `${interest}€`;

  //total balance
  let balance = currentAccount.movements.reduce((acc, cur) => acc + cur, 0);
  labelBalance.textContent = `${balance}€`;
}

//Transfer Money
btnTransfer.addEventListener("click", (e) => {
  e.preventDefault();
  let reciverAccount = accounts.find(
    (acc) => acc.user === `${inputTransferTo.value}`
  );
  let transferAmount = +inputTransferAmount.value;
  let totalBalance = +labelBalance.textContent.replace(/[^\d]/g, "");

  //If reciverAccount is exist & transferAmount is greater than 0 & totalBalance is greater than or equal to transferAmount & reciverAccount doesn't match currenAccount.
  if (
    reciverAccount &&
    transferAmount > 0 &&
    totalBalance >= transferAmount &&
    reciverAccount.owner !== currentAccount.owner
  ) {
    //Update reciverAccount Movements
    reciverAccount.movements.push(transferAmount);
    //Update CurrentUser Movements
    currentAccount.movements.push(-transferAmount);
  }

  //Update all calculation
  updateUI(currentAccount);

  //clear transferUser & transferAmount
  inputTransferTo.value = "";
  inputTransferAmount.value = "";
});

//Request Loan
btnLoan.addEventListener("click", (e) => {
  e.preventDefault();
  let loanAmount = +inputLoanAmount.value;
  //Update CurrentUser Movements
  if (loanAmount > 0) {
    currentAccount.movements.push(loanAmount);
  }

  //Update all calculation
  updateUI(currentAccount);

  //clear inputLoanAmount
  inputLoanAmount.value = "";
});

//Close Account
btnClose.addEventListener("click", (e) => {
  e.preventDefault();
  let deleteUser = inputCloseUsername.value;
  let deleteUserPin = +inputClosePin.value;
  if (
    currentAccount.user === deleteUser &&
    currentAccount.pin === deleteUserPin
  ) {
    // let clsIndex = accounts.indexOf(currentAccount);
    // console.log(clsIndex);
    let closeIndex = accounts.findIndex((acc) => acc.user === deleteUser);
    accounts.splice(closeIndex, 1);

    //When deleted currentAccount then currentAccount will be disapperad -> it means opacity is 0
    containerApp.style.opacity = 0;

    //Home
    labelWelcome.textContent = `Log in to get started`;
  }

  //Clear CloseUserName & ClosePin
  inputCloseUsername.value = "";
  inputClosePin.value = "";
});
