const account1 = {
  owner: "Anik Vai",
  movements: [200, 455.23, -306.5, 25000, -642.21, -133.9, 79.97, 1300],
  interestRate: 1.2, // %
  pin: 1111,

  movementsDates: [
    "2019-11-18T21:31:17.178Z",
    "2019-12-23T07:42:02.383Z",
    "2020-01-28T09:15:04.904Z",
    "2020-04-01T10:17:24.185Z",
    "2020-05-08T14:11:59.604Z",
    "2020-07-26T17:01:17.194Z",
    "2020-07-28T23:36:17.929Z",
    "2020-08-01T10:51:36.790Z",
  ],
  currency: "EUR",
  locale: "pt-PT",
};

const account2 = {
  owner: "Alina Rose",
  movements: [5000, 3400, -150, -790, -3210, -1000, 8500, -30],
  interestRate: 1.5,
  pin: 2222,

  movementsDates: [
    "2019-11-01T13:15:33.035Z",
    "2019-11-30T09:48:16.867Z",
    "2019-12-25T06:04:23.907Z",
    "2020-01-25T14:18:46.235Z",
    "2020-02-05T16:33:06.386Z",
    "2020-04-10T14:43:26.374Z",
    "2020-06-25T18:49:59.371Z",
    "2020-07-26T12:01:20.894Z",
  ],
  currency: "USD",
  locale: "en-US",
};

const accounts = [account1, account2];

// Elements
let labelWelcome = document.querySelector(".welcome");
let labelDate = document.querySelector(".date");
let labelBalance = document.querySelector(".balance__value");
let labelSumIn = document.querySelector(".summary__value--in");
let labelSumOut = document.querySelector(".summary__value--out");
let labelSumInterest = document.querySelector(".summary__value--interest");
let labelTimer = document.querySelector(".timer");

let containerApp = document.querySelector(".app");
let containerMovements = document.querySelector(".movements");

//BTN
let btnLogin = document.querySelector(".login__btn");
let btnTransfer = document.querySelector(".form__btn--transfer");
let btnLoan = document.querySelector(".form__btn--loan");
let btnClose = document.querySelector(".form__btn--close");
let btnSort = document.querySelector(".btn--sort");

let inputLoginUsername = document.querySelector(".login__input--user");
let inputLoginPin = document.querySelector(".login__input--pin");
let inputTransferTo = document.querySelector(".form__input--to");
let inputTransferAmount = document.querySelector(".form__input--amount");
let inputLoanAmount = document.querySelector(".form__input--loan-amount");
let inputCloseUsername = document.querySelector(".form__input--user");
let inputClosePin = document.querySelector(".form__input--pin");

//Create User Name
let createUserName = (userAccount) => {
  return userAccount.forEach((acc) => {
    acc.user = acc.owner
      .split(" ")
      .map((nam) => nam[0])
      .join("")
      .toLowerCase();
  });
};
createUserName(accounts);

/**
 * @Very_Important_Section
 * In this section create currentAccount.
 */
//Global Variable -> FOR EVENT
let currentAccount, timer;

//Account Login
btnLogin.addEventListener("click", (e) => {
  //for html form
  e.preventDefault();

  //find target object
  currentAccount = accounts.find(
    (acc) => acc.user === inputLoginUsername.value
  );
  let pin = +inputLoginPin.value;

  //If user or pin doesn't correct
  if (!currentAccount || currentAccount?.pin !== pin) {
    containerApp.style.opacity = 0;
    labelWelcome.textContent = `Log in to get started`;
  }

  //If user & pin is correct
  if (currentAccount?.pin === pin) {
    containerApp.style.opacity = 100;

    //Welcome Message
    labelWelcome.textContent = `Welcome Back ${
      currentAccount.owner.split(" ")[0]
    }`;

    //updateUI() function argument recive current account object.
    updateUI(currentAccount);

    //If previous timer is exist then clear it first.
    if (timer) {
      clearInterval(timer);
    }
    //Then LogoutTimer is called and stored it global timer variable.
    timer = logoutTimer();

    //Update Date UI
    labelDate.textContent = callDate(currentAccount);
  }

  //clear user & pin value
  inputLoginUsername.value = "";
  inputLoginPin.value = "";
});

//Accounts Movements
function displayMovements(acc, sorted = false) {
  //clear previous manually stored movements
  containerMovements.textContent = "";

  //Sort Movement
  let movs = sorted
    ? acc.movements.slice().sort((a, b) => a - b)
    : acc.movements;

  movs.forEach((amount, i) => {
    let type = amount > 0 ? "deposit" : "withdrawal";

    let html = `<div class="movements__row">
    <div class="movements__type movements__type--${type}">${i + 1} ${type}</div>
    <div class="movements__date">${dateDifference(acc.movementsDates[i])}</div>
    <div class="movements__value">${currencyFunk(acc, amount)}</div>
  </div>`;

    //Dynamically Create all type of movements
    containerMovements.insertAdjacentHTML("afterbegin", html);
  });
}

/**
 * updateUI() function argument recive current account object for this reason I used currentAccount.movements or acc.movements. If I want to use current account object in any function argument then call them inside updateUI() function.
 */
function updateUI(acc) {
  //movements
  displayMovements(acc);

  //summary
  calculateSummary(acc);
}

//sort movements
let sorted = false;
btnSort.addEventListener("click", (e) => {
  e.preventDefault();
  displayMovements(currentAccount, !sorted);
  sorted = !sorted;
});

//Summary
function calculateSummary(currentAccount) {
  //amount input
  let input = currentAccount.movements
    .filter((amount) => amount > 0)
    .reduce((acc, cur) => acc + cur, 0);
  labelSumIn.textContent = currencyFunk(currentAccount, input);

  //amount out
  let out = currentAccount.movements
    .filter((amount) => amount < 0)
    .reduce((acc, cur) => acc + cur, 0);
  labelSumOut.textContent = currencyFunk(currentAccount, Math.abs(out));

  //amount interest
  let interest = currentAccount.movements
    .filter((amount) => amount > 0)
    .map((diposit) => (diposit * currentAccount.interestRate) / 100)
    .filter((interest) => interest >= 1)
    .reduce((acc, cur) => acc + cur, 0);
  labelSumInterest.textContent = currencyFunk(currentAccount, interest);

  //create balance key in currentAccount object and calculate total movements and store it in balance key.
  currentAccount.balance = currentAccount.movements.reduce(
    (acc, cur) => acc + cur,
    0
  );
  labelBalance.textContent = currencyFunk(
    currentAccount,
    currentAccount.balance
  );
}

//Transfer Money
btnTransfer.addEventListener("click", (e) => {
  e.preventDefault();
  let reciverAccount = accounts.find(
    (acc) => acc.user === `${inputTransferTo.value}`
  );
  let transferAmount = +inputTransferAmount.value;
  let totalBalance = currentAccount.balance;

  //If reciverAccount is exist & transferAmount is greater than 0 & totalBalance is greater than or equal to transferAmount & reciverAccount doesn't match currenAccount.
  if (
    reciverAccount &&
    transferAmount > 0 &&
    totalBalance >= transferAmount &&
    reciverAccount?.owner !== currentAccount.owner
  ) {
    //Update reciverAccount Movements & movementsDates
    reciverAccount.movements.push(transferAmount);
    reciverAccount.movementsDates.push(new Date().toISOString());
    //Update CurrentUser Movements & movementsDates
    currentAccount.movements.push(-transferAmount);
    currentAccount.movementsDates.push(new Date().toISOString());

    //Update all calculation
    updateUI(currentAccount);

    //Reset Timer ~ When does transfer money then previous timer is cleared and started new timer and stored it global timer variable.
    clearInterval(timer);
    timer = logoutTimer();
  }

  //clear transferUser & transferAmount
  inputTransferTo.value = "";
  inputTransferAmount.value = "";
});

//Request Loan
btnLoan.addEventListener("click", (e) => {
  e.preventDefault();
  let loanAmount = +inputLoanAmount.value;

  if (loanAmount > 0) {
    //Update CurrentUser Movements & movementsDates
    currentAccount.movements.push(loanAmount);
    currentAccount.movementsDates.push(new Date().toISOString());

    //Update all calculation
    updateUI(currentAccount);

    //Reset Timer
    clearInterval(timer);
    timer = logoutTimer();
  }

  //clear inputLoanAmount
  inputLoanAmount.value = "";
});

//Close Account
btnClose.addEventListener("click", (e) => {
  e.preventDefault();
  let deleteUser = inputCloseUsername.value;
  let deleteUserPin = +inputClosePin.value;
  if (
    currentAccount.user === deleteUser &&
    currentAccount.pin === deleteUserPin
  ) {
    // let clsIndex = accounts.indexOf(currentAccount);
    // console.log(clsIndex);
    let closeIndex = accounts.findIndex((acc) => acc.user === deleteUser);
    accounts.splice(closeIndex, 1);

    //When deleted currentAccount then currentAccount will be disapperad -> it means opacity is 0
    containerApp.style.opacity = 0;

    //Home
    labelWelcome.textContent = `Log in to get started`;
  }

  //Clear CloseUserName & ClosePin
  inputCloseUsername.value = "";
  inputClosePin.value = "";
});

/**
 * @silly_hard_to_understand_but_easy
 */
function logoutTimer() {
  function tick() {
    let min = `${Math.trunc(time / 60)}`.padStart(2, 0);
    let sec = `${time % 60}`.padStart(2, 0);

    //Update Minute & Second in the UI
    labelTimer.textContent = `${min}:${sec}`;

    //when time will less than 0 or equal to 0 then timer will be stopped.
    if (time <= 0) {
      clearInterval(timer);
      //Back to Home
      containerApp.style.opacity = 0;
      labelWelcome.textContent = `Log in to get started`;
    }
    //Decresed time
    time--;
  }

  //Set time to 5 min
  let time = 60 * 5; //5min

  //Firstly the timer funk tick() called immediately
  tick();
  //Then Call the timer every second
  let timer = setInterval(tick, 1000);
  return timer;
}

//For Date
function callDate(acc) {
  let now = new Date();

  let dateOptions = {
    hour: "numeric",
    minute: "numeric",
    day: "numeric",
    month: "numeric",
    year: "numeric",
  };

  let currentDate = Intl.DateTimeFormat(acc.locale, dateOptions).format(now);

  return currentDate;
}

//Currency Sign
function currencyFunk(acc, value) {
  let currencyOptions = {
    style: "currency",
    currency: acc.currency,
  };

  let currentCurrency = new Intl.NumberFormat(
    acc.locale,
    currencyOptions
  ).format(value);

  return currentCurrency;
}

//Date difference
function dateDifference(dat) {
  let todayDate = new Date();
  let holyDate = new Date(dat);

  let res = Math.trunc(
    Math.abs((todayDate - holyDate) / (1000 * 60 * 60 * 24))
  );

  return res === 0 ? `Today` : `${res} days ago.`;
}
