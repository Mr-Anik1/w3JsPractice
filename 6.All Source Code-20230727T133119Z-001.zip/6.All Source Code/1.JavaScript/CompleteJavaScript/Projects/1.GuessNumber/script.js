/**
 * @Anik__Guess_Number_Game__April_7__2023
 * @Time ~ 3:45 AM
 */

//When I click the Check Button for guessing the number
let checkBTN = document.querySelector(".check");
checkBTN.addEventListener("click", () => {
  let inputValue = document.querySelector(".guess").value;
  let randomNumber = Math.floor(Math.random() * 5) + 1;
  let scoreValue = +document.querySelector(".score").textContent;

  if (inputValue == "" || +inputValue <= 0) {
    document.querySelector(".message").textContent = "Invalid Number!";

    //Change Color
    document.querySelector(".message").classList.remove("white");
    document.querySelector(".message").classList.add("red");
    document.querySelector(".guess").classList.add("red");

    //If Number is Invalid, then disable Input and Check Button.
    document.querySelector(".guess").disabled = true;
    document.querySelector(".check").disabled = true;
  } else if (+inputValue === randomNumber) {
    //change background color
    document.querySelector("body").style.backgroundColor = "green";

    //For Number and Message
    document.querySelector(".number").textContent = inputValue;
    document.querySelector(".message").textContent = "Correct Number!";

    //For Score
    document.querySelector(".score").textContent = scoreValue;

    // For Highscore
    let highScore = +document.querySelector(".highscore").textContent;
    if (scoreValue > highScore) {
      document.querySelector(".highscore").textContent = scoreValue;
    } else {
      document.querySelector(".highscore").textContent = highScore;
    }

    //When the number is correct, the input field and check button will be disabled.
    document.querySelector(".guess").disabled = true;
    document.querySelector(".check").disabled = true;

    /**
     * @Extra_Code_For_PopUp_Message
     * When a player wins, a congratulations popup message appears after 500 milliseconds.
     */
    setTimeout(() => {
      let winModal = document.querySelector(".win-modal");
      let winCloseBTN = document.querySelector(".winclose-modal");
      let winOverlay = document.querySelector(".win-overlay");

      let close = () => {
        winModal.classList.add("win-hidden");
        winOverlay.classList.add("win-hidden");
      };

      let show = () => {
        winModal.classList.remove("win-hidden");
        winOverlay.classList.remove("win-hidden");
      };

      winCloseBTN.addEventListener("click", close);
      winOverlay.addEventListener("click", close);

      //Congrats PopUp Message
      if (document.querySelector(".message").textContent == "Correct Number!") {
        show();
      }
    }, 500);
  } else {
    if (scoreValue <= 1) {
      document.querySelector(".message").textContent = "Game Over!";
      document.querySelector(".score").textContent = scoreValue - 1;

      /**
       * @Change_Color
       */

      //For Body
      document.querySelector("body").style.backgroundColor = "#860808";

      //For Message & Score
      document.querySelector(".message").classList.remove("white");
      document.querySelector(".message").classList.add("yellow");
      document.querySelector(".score").classList.remove("white");
      document.querySelector(".score").classList.add("yellow");

      //When Game is Over the input field and check button will be disabled.
      document.querySelector(".guess").disabled = true;
      document.querySelector(".check").disabled = true;

      /**
       * @Extra_Code_For_PopUp_Message
       * When game is over a Game Over popup message appears after 500 milliseconds.
       */

      setTimeout(() => {
        let modal = document.querySelector(".modal");
        let closeBTN = document.querySelector(".close-modal");
        let overlay = document.querySelector(".overlay");

        let close = () => {
          modal.classList.add("hidden");
          overlay.classList.add("hidden");
        };

        let show = () => {
          modal.classList.remove("hidden");
          overlay.classList.remove("hidden");
        };

        closeBTN.addEventListener("click", close);
        overlay.addEventListener("click", close);

        //Game Over popup message
        if (document.querySelector(".message").textContent == "Game Over!") {
          show();
        }
      }, 500);
    } else {
      document.querySelector(".score").textContent = scoreValue - 1;
      document.querySelector(".message").textContent =
        +inputValue > randomNumber ? "Too High!" : "Too Low!";
    }
  }
});

/**
 * @RESET
 * Reset Input Field, Message, Number and Score
 */
let againBTN = document.querySelector(".again");
againBTN.addEventListener("click", () => {
  document.querySelector(".guess").value = "";
  document.querySelector(".number").textContent = "?";
  document.querySelector(".message").textContent = "Start Guessing...";
  document.querySelector(".score").textContent = "5";

  /**
   * @Change_Color
   */

  //For body
  document.querySelector("body").style.backgroundColor = "#222";

  //For Input Field
  document.querySelector(".guess").classList.remove("red");
  document.querySelector(".guess").classList.add("white");

  //For Message
  document.querySelector(".message").classList.remove("yellow");
  document.querySelector(".message").classList.remove("red");
  document.querySelector(".message").classList.add("white");

  //For Score
  document.querySelector(".score").classList.remove("yellow");
  document.querySelector(".score").classList.add("white");

  //so when againBTN button is triggered again, the input field and check button will be non-disabled or active again.
  document.querySelector(".guess").disabled = false;
  document.querySelector(".check").disabled = false;
});
