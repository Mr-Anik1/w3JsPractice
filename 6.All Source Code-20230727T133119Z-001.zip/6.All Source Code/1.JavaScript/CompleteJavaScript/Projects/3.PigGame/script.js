/**
 * @ANIK__PIG_GAME__April_8_2023
 */

let imgEl = document.querySelector("img");

let againBTN = document.querySelector(".btn--new");
let rollBTN = document.querySelector(".btn--roll");
let holdBTN = document.querySelector(".btn--hold");

let player1 = document.querySelector(".player--0");
let player2 = document.querySelector(".player--1");

let final1 = +document.getElementById("score--0").textContent;
let current1 = +document.getElementById("current--0").textContent;
let final2 = +document.getElementById("score--1").textContent;
let current2 = +document.getElementById("current--1").textContent;

//Hide Dice with add hidden class
imgEl.classList.add("hidden");

/**
 * @Hold_Dice_Logic
 */
function holdDice() {
  if (player1.classList.contains("player--active")) {
    //Change Color
    player1.classList.remove("player--active");
    player2.classList.add("player--active");

    //store score
    final1 += current1;
    current1 = 0;
    document.getElementById("score--0").textContent = final1;
    document.getElementById("current--0").textContent = 0;
  } else {
    //Change Color
    player2.classList.remove("player--active");
    player1.classList.add("player--active");

    //Store Score
    final2 += current2;
    current2 = 0;
    document.getElementById("score--1").textContent = final2;
    document.getElementById("current--1").textContent = 0;
  }

  //Check continiously Who is Winner
  win();
}

/**
 * @When_You_Click_Hold_Dice_Button
 */
holdBTN.addEventListener("click", () => {
  //Hide Dice with add hidden class
  imgEl.classList.add("hidden");

  //Call Hold Dice Function
  holdDice();
});

/**
 * @When_You_Click_Roll_Dice_Button
 */
rollBTN.addEventListener("click", () => {
  //Show Dice with remove hidden class
  imgEl.classList.remove("hidden");

  let rand = Math.floor(Math.random() * 6) + 1;

  if (rand === 1) {
    imgEl.src = "./img/dice-1.png";

    //Hide Dice after 500 ms
    setTimeout(() => {
      imgEl.classList.add("hidden");
    }, 500);

    //reset operation
    if (player1.classList.contains("player--active")) {
      document.getElementById("current--0").textContent = 0;
      current1 = 0;
      holdDice();
    } else {
      document.getElementById("current--1").textContent = 0;
      current2 = 0;
      holdDice();
    }
  } else {
    //Update Current Score
    if (player1.classList.contains("player--active")) {
      current1 += rand;
      document.getElementById("current--0").textContent = current1;
    } else {
      current2 += rand;
      document.getElementById("current--1").textContent = current2;
    }

    //Show Dice
    if (rand === 2) {
      imgEl.src = "./img/dice-2.png";
    } else if (rand === 3) {
      imgEl.src = "./img/dice-3.png";
    } else if (rand === 4) {
      imgEl.src = "./img/dice-4.png";
    } else if (rand === 5) {
      imgEl.src = "./img/dice-5.png";
    } else {
      imgEl.src = "./img/dice-6.png";
    }
  }
});

/**
 * @If_You_Want_to_Restart_Game
 */
againBTN.addEventListener("click", () => {
  //Player-1 Reset
  document.getElementById("score--0").textContent = 0;
  final1 = 0;
  document.getElementById("current--0").textContent = 0;
  current1 = 0;

  //Player-2 Reset
  document.getElementById("score--1").textContent = 0;
  final2 = 0;
  document.getElementById("current--1").textContent = 0;
  current2 = 0;

  //Dice Hide
  imgEl.classList.add("hidden");

  //Player Active move to Player-1
  player2.classList.remove("player--active");
  player1.classList.add("player--active");

  //Activate Roll Dice and Hold Dice Button
  rollBTN.disabled = false;
  holdBTN.disabled = false;
});

/**
 * @Which_Player_is_winner
 */

function win() {
  if (final1 >= 100 || final2 >= 100) {
    setTimeout(() => {
      let winModal = document.querySelector(".win-modal");
      let winCloseBTN = document.querySelector(".winclose-modal");
      let winOverlay = document.querySelector(".win-overlay");

      let show = () => {
        winModal.classList.remove("win-hidden");
        winOverlay.classList.remove("win-hidden");
      };

      let close = () => {
        winModal.classList.add("win-hidden");
        winOverlay.classList.add("win-hidden");
      };

      //Show Congratulation PopUp Message
      if (final1 >= 100) {
        document.querySelector(".winner").textContent =
          "Player 1 is Winner! Congrats";
        show();
      } else if (final2 >= 100) {
        document.querySelector(".winner").textContent =
          "Player 2 is Winner! Congrats";
        show();
      }

      //Close PopUp Message
      winCloseBTN.addEventListener("click", close);
      winOverlay.addEventListener("click", close);

      //DE-Activate Roll Dice and Hold Dice Button
      rollBTN.disabled = true;
      holdBTN.disabled = true;
    }, 400);
  }
}
