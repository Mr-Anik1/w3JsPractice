/**
 * @Default_Parameter
 * In this case I set default value for every parameter.
 */
let defaultParameter = (
  flightName = "FlyAnik",
  passengerNum = 1,
  price = 300 * passengerNum
) => {
  let booking = {
    flightName,
    passengerNum,
    price,
  };
  console.log(booking);
};

defaultParameter("Bonig-777");
//{ flightName: 'Bonig-777', passengerNum: 1, price: 300 }
//In this case I didn't pass passengerNum and price value for this reason default value has used.

defaultParameter("AirBus69", 5);
//{ flightName: 'AirBus69', passengerNum: 5, price: 1500 }
//In this case I didn't pass price value, for this reason price automatically use as default value. When passengerNum is 5 then price will 300*5=1500.

/**
 * @If_I_want_to_skip_any_argument_then_use_undefined
 * undefined
 */
defaultParameter(undefined, 10, 2500);
//{ flightName: 'FlyAnik', passengerNum: 10, price: 2500 }
// In argument I use undefined as flightName then default value has used as flightName. This way we can skip any argument.
