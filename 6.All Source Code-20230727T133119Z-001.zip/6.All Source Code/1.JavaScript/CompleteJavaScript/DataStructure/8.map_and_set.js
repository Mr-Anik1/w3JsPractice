/**
 * @Set
 * unique value
 */
let mySet = new Set([1, 2, 3, 4, 2, 3, 2, 1, 2, 2, 2]);
console.log(mySet);
//Set(4) { 1, 2, 3, 4 }

/**
 * @Set_to_Array
 */
console.log(Array.from(mySet));
//[ 1, 2, 3, 4 ]

console.log([...mySet]);
//[ 1, 2, 3, 4 ]

mySet.add(5);
mySet.add(6);
console.log(mySet);
//Set(6) { 1, 2, 3, 4, 5, 6 }

console.log(mySet.has(5)); //true
console.log(mySet.has(34)); //false
mySet.delete(5);
mySet.delete(6);
console.log(mySet.size); //4

mySet.clear(); //Its remove all value in this set.

console.log(mySet.size); //0
console.log(mySet); //Set(0) {}

/**
 * @Map
 * we can set any data type as a key in map and it is a big different between object and  Map()
 */
let myMap = new Map();

myMap.set("nam", "Anik");
myMap.set(true, "Yes");
myMap.set(1, "No");

// console.log(myMap.get(1));//No
// console.log(myMap.has("tre"));//false
//console.log(myMap.size);//3
// myMap.delete(1);//Delete 1 property
//myMap.clear(); //All Clear

console.log(myMap);
//Map(3) { 'nam' => 'Anik', true => 'Yes', 1 => 'No' }

console.log(Object.fromEntries(myMap));
//{ '1': 'No', nam: 'Anik', true: 'Yes' }

//I can use array as a property
myMap.set([1, 2], "Array as a property");

console.log(myMap);
/*
    Map(4) {
       'nam' => 'Anik',
       true => 'Yes',
       1 => 'No',
       [ 1, 2 ] => 'Array as a property'
    }
*/

myMap.set([3, 4], "New Arr");
console.log(myMap.get([3, 4])); //undefined
//undefined because array is a referance type this [3,4] is not same as above [3,4]

let arr = [5, 6];
myMap.set(arr, "Oh My Array");
console.log(myMap.get(arr)); //Oh My Array => because arr is indicate same memory point

//We can use map this way like array key value
let anotherMap = new Map([
  ["key", "vlaue"],
  [{ oh: 1, b: 2 }, "Object Key"],
  [true, "Bolean Key"],
]);

console.log(anotherMap);
/*
   Map(3) {
      'key' => 'vlaue',
      { oh: 1, b: 2 } => 'Object Key',
      true => 'Bolean Key'
   }
*/

//Map to Object
let likeObj = Object.fromEntries(anotherMap);
console.log(likeObj);
//{ key: 'vlaue', '[object Object]': 'Object Key', true: 'Bolean Key' }

//Map to array
console.log([...anotherMap]);
/*
    [
      [ 'key', 'vlaue' ],
      [ { oh: 1, b: 2 }, 'Object Key' ],
      [ true, 'Bolean Key' ]
    ]
*/

//Map to keys
console.log([...anotherMap.keys()]);
//[ 'key', { oh: 1, b: 2 }, true ]

//Map to values
console.log([...anotherMap.values()]);
//[ 'vlaue', 'Object Key', 'Bolean Key' ]

/**
 * @Memorize_using_Map
 */

let fatherMemorize = () => {
  let caches = new Map();
  //inner function
  return (p) => {
    if (caches.has(p)) {
      return caches.get(p); //caches from clouser
    } else {
      console.log("Run");
      caches.set(p, p + 100);
      return caches.get(p);
    }
  };
};

let memorize = fatherMemorize();
console.log("1.", memorize(7));
console.log("2.", memorize(5));
console.log("3.", memorize(5));
console.log("4.", memorize(5));
console.log("5.", memorize(5));
console.log("6.", memorize(8));
/*
 
     Run
     1. 107
     Run
     2. 105
     3. 105
     4. 105
     5. 105
     Run
     6. 108
 
 */
