/**
 * @Coding_Challenge #2
 */

const game = {
  team1: "Bayern Munich",
  team2: "Borrussia Dortmund",
  players: [
    [
      "Neuer",
      "Pavard",
      "Martinez",
      "Alaba",
      "Davies",
      "Kimmich",
      "Goretzka",
      "Coman",
      "Muller",
      "Gnarby",
      "Lewandowski",
    ],
    [
      "Burki",
      "Schulz",
      "Hummels",
      "Akanji",
      "Hakimi",
      "Weigl",
      "Witsel",
      "Hazard",
      "Brandt",
      "Sancho",
      "Gotze",
    ],
  ],
  score: "4:0",
  scored: ["Lewandowski", "Gnarby", "Lewandowski", "Hummels"],
  date: "Nov 9th, 2037",
  odds: {
    team1: 1.33,
    x: 3.25,
    team2: 6.5,
  },
};

/**
 * @Challenge - 1 
 * 
   1. Loop over the game.scored array and print each player name to the console, along with the goal number (Example: "Goal 1: Lewandowski")
 * 
 */

for (let [i, v] of game.scored.entries()) {
  console.log(`Goal ${i + 1}: ${v}`);
}
/*
   Goal 1: Lewandowski
   Goal 2: Gnarby
   Goal 3: Lewandowski
   Goal 4: Hummels
*/

/**
 * @Challenge - 2
 * 
   2. Use a loop to calculate the average odd and log it to the console (We already studied how to calculate averages, you can go check if you don't remember)
 * 
 */

let oddsVal = Object.values(game.odds);
let sum = 0;
for (let v of oddsVal) {
  sum += v;
}
console.log(+(sum / oddsVal.length).toFixed(2)); //3.69

/**
 * @Challenge - 3
 * 
   3. Print the 3 odds to the console, but in a nice formatted way, exactly like this:

   Odd of victory Bayern Munich: 1.33
   Odd of draw: 3.25
   Odd of victory Borrussia Dortmund: 6.5

   Get the team names directly from the game object, don't hardcode them (except for "draw"). 
   Hint: Note how the odds and the game objects have the same property names 😉
 * 
 */

// let { team1, x: draw, team2 } = game.odds;

// console.log(`Odd of victory ${game.team1}: ${team1}`);
// //Odd of victory Bayern Munich: 1.33
// console.log(`Odd of draw: ${draw}`);
// //Odd of draw: 3.25
// console.log(`Odd of victory ${game.team2}: ${team2}`);
// //Odd of victory Borrussia Dortmund: 6.5

for (let [team, value] of Object.entries(game.odds)) {
  let dynamicTeamName = team === "x" ? "draw" : `victory ${game[team]}`;
  console.log(`Odd of ${dynamicTeamName}: ${value}`);
}
/*
   Odd of victory Bayern Munich: 1.33
   Odd of draw: 3.25
   Odd of victory Borrussia Dortmund: 6.5
*/

/**
 * @Challenge - 4
 * 
   4. Bonus: Create an object called 'scorers' which contains the names of the players who scored as properties, and the number of goals as the value. In this game, it will look like this:
        {
          Gnarby: 1,
          Hummels: 1,
          Lewandowski: 2
        }
 * 
 */

let scorers = game.scored.reduce((acc, cur) => {
  acc[cur] = acc[cur] ? acc[cur] + 1 : 1;
  return acc;
}, {});

console.log(scorers);
//{ Lewandowski: 2, Gnarby: 1, Hummels: 1 }
