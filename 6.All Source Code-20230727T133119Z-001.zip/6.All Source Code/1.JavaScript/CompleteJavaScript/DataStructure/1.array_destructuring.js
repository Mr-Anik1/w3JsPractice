let arr = [1, 2, 3, 4, 5];

//Destructuring
let [a, b, c] = arr;

console.log(a); //1
console.log(b); //2
console.log(c); //3

//But if I use ...c insted of c
let [aa, bb, ...cc] = arr;
console.log(aa); //1
console.log(bb); //2
console.log(cc); //[ 3, 4, 5 ]

//If I want to skip one element then use ,
let [first, , second] = arr;
console.log(first); //1
console.log(second); //3
//In this case I skip second element of this arr that was 2

//Swap
[second, first] = [first, second];
console.log(first); //3
console.log(second); //1

//If I don't use desturcturing then swap manually
// temp = first;
// first = second;
// second = temp;

// console.log(first); //3
// console.log(second); //1

console.log(`

------------------------------------------------

`);

//Destructuring in Nested Array
let nestedArr = [2, 3, [4, [5, 6], 7]]; //3D Array

let [i, j, [k, [l, m], n]] = nestedArr;

console.log(i); //2
console.log(j); //3
console.log(k); //4
console.log(l); //5
console.log(m); //6
console.log(n); //7

console.log(`



------------------------------------------------



`);

let anotherNested = [6, 7, [8, 9]];

//I want to skip second element of this array so I use space and comma ( ,)
let [_first, , [_third, _fourth]] = anotherNested;

console.log(_first); //6
console.log(_third); //8
console.log(_fourth); //9

console.log(`



------------------------------------------------



`);
/**
 * @Default_Values
 * If I don't know the length of the array then use it, mostly when we working with API its very useful
 */

let myLastArr = [10, 20];

let [one, two, three] = myLastArr;
console.log(one, two, three); //10 20 undefined
//In this case we don't have third element, so it returns undefined.

//Solve this problem using default value
let [on = 1, tw = 1, thr = 1] = myLastArr;
console.log(on, tw, thr); //10 20 1
//When element is exist then default value doesn't use. But if element doesn't exist then return default value insted of undefined. In this case `on` and `tw` is exist for this reason they return excual value but `thr` doesn't exist so it return default value 1.
