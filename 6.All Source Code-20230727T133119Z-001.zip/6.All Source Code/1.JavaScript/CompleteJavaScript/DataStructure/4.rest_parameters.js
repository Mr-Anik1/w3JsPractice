/**
 * @Destructuring
 */

//Rest, because on left side of =
//Rest placed on last of the array, in this case ...other placed on last of the left side array.
let [a, b, ...others] = [1, 2, 3, 4, 5];
console.log(a); //1
console.log(b); //2
console.log(others); //[ 3, 4, 5 ]
// a and b variable store first and second element of the array and `others` store all other existance element.

/**
 * @How_Can_I_Know_Which_One_is_Rest_and_Which_one_Spread
 */
let arr1 = [10, 20];
let arr2 = [30, 40, 50];

//In this case right side of = ...arr1 and ...arr2 is spread operator.
//In this case left side of = ...allOther is rest parameter.
let [first, second, ...allOther] = [...arr1, ...arr2];

console.log(first); //10
console.log(second); //20
console.log(allOther); //[ 30, 40, 50 ]

/**
 * @Rest_Pattern_in_Object
 */
let obj = {
  nam: "Anik",
  age: 20,
  year: 2023,
  type: {
    specise: "Homo Sapiens",
    vission: "Programmer",
  },
};

const { nam, ...otherProp } = obj;

console.log(nam); //Anik
console.log(otherProp);
/**
 * @In_This_Case_OtherProp_Store_All_Other_Property
 * @Result :
 
  {
     age: 20,
     year: 2023,
     type: { specise: 'Homo Sapiens', vission: 'Programmer' }
  }
 * 
 */

/**
 * @Rest_Pattern_in_Function_Parameter
 * Rest parameter is taking multiple value and packs them all into one array.
 */

function helloRestParameter(...restArr) {
  return restArr.reduce((acc, cur) => acc + cur);
}

console.log(helloRestParameter(5, 10, 15)); //30
console.log(helloRestParameter(1, 2, 3, 4, 5)); //15
console.log(helloRestParameter(4, 6)); //10
//In this case Now I can input multiple value in the function argument as I wish, ...restArr in function parameter will store all the value in an array.
