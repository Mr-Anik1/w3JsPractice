//Spread, because on right side of =
let testArr = [1, 2, ...[30, 40], 50];
console.log(testArr); //[ 1, 2, 30, 40, 50 ]

let arr = [3, 4, 5];
let newArr = [1, 2, ...arr];
console.log(newArr); //[ 1, 2, 3, 4, 5 ]

//When we need individual element form an array then we should use spread operator.
console.log(...newArr); //1 2 3 4 5

//Spread String
let str = "anik";
let letters = ["h", "i", "", ...str, "!"];
console.log(letters);
//[ 'h', 'i', '','a', 'n', 'i','k', '!' ]

/**
 *
 * @Spread_operator uses to create shallow copy and mearge array/obj together.
 *
 */

//Shallow Copy of Array
let shallowArr = [...arr];
console.log(shallowArr); //[ 3, 4, 5 ]

//Shallow Copy of Object
let obj = { nam: "Anik", age: 20, year: 2023 };
let shallowObj = { ...obj };
console.log(shallowObj); //{ nam: 'Anik', age: 20, year: 2023 }

//Merge Array
let arr1 = [10, 20, 30];
let arr2 = [40, 50];
let mergeArr = [...arr1, ...arr2];
console.log(mergeArr); //[ 10, 20, 30, 40, 50 ]

//Merge Object
let obj2 = { from: "Bangladesh", vision: "Programmer" };
let mergeObj = { ...shallowObj, ...obj2 };
console.log(mergeObj);
/*

{
  nam: 'Anik',
  age: 20,
  year: 2023,
  from: 'Bangladesh',
  vision: 'Programmer'
}

*/

/**
 *
 * @Spread_Array_in_an_Object
 *
 */
let merge = (...objects) => ({ ...objects });
console.log(merge(obj, obj2));
/*

  {
    '0': { nam: 'Anik', age: 20, year: 2023 },
    '1': { from: 'Bangladesh', vision: 'Programmer' }
  }

  How its works:
    ...objects means `objects` collects obj,obj2 and store in an array like: [obj,obj2]
    When we spread this array in an object literal {...[obj,obj2]} then return this result.


  similler:
    let myArr=[3,4,5]
    console.log({ ...myArr });//{ '0': 3, '1': 4, '2': 5 }


  Final Result: We can spread an array in an Object literal, but we can't spread an Object in an Array.
*/

/**
 * @Spread_Operator_in_Function_Argument
 */
let arrEl = [1, 2, 3, 4, 5];

function helloSpreadArg(a, b, c, d, e) {
  return `Result is: ${a + b + c + d + e}`;
}

console.log(helloSpreadArg(...arrEl)); //Result is: 15
//In this case I spread `arrEl` elements in `helloSpreadArg` argument.
