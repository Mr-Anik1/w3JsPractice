/**
 * @padStart_and_padEnd
 */
let myStr = "Anik";
console.log(myStr.padStart(10, "$")); //$$$$$$Anik
console.log(myStr.padEnd(10, "#")); //Anik######

/**
 * @Masking_like_CreditCard_Using_padStart
 * It shows last four number and first other number hide
 */
let muskFunk = (num) => {
  let str = String(num);
  let lastNum = str.slice(-4);
  return lastNum.padStart(str.length, "*");
};
console.log(muskFunk(1234567890)); //******7890
console.log(muskFunk(12345678905385)); //**********5385

/**
 * @Excellent_Example
 */
let str =
  "Delayed_Departure;fao32878433459;txl995863455677;11:25+_Arrival;bur56987754378;fao436588437905;12:32+_Delayed_Arrival;hel864673459;bank995863455677;12:05+_Departure;fao32878433459;lis995863455677;11:49";

//First divide individual item using split and store them in an array
let nStr = str.split("+");

/**
 * @getCode_Function_for_from_and_to
 * /[\d]{3,}/g; => when number repeat three or more time
 *
 */
let getCode = (str) => str.replace(/\d{1,}/g, "").toUpperCase();

for (let v of nStr) {
  let nText = v.split(";");
  let [type, from, to, time] = nText;

  console.log(
    `${`${type.replaceAll("_", " ")}`.trim()} from ${getCode(
      from
    )} to ${getCode(to)} (${time.replace(":", "h")})`
  );
}
/*
   Delayed Departure from FAO  to TXL (11h25)
   Arrival from BUR  to FAO (12h32)
   Delayed Arrival from HEL  to BANK (12h05)
   Departure from FAO  to LIS (11h49)
*/
