let obj = {
  airline: "CTG Port",
  flyCode: "BD",
  book(flightNum, nam) {
    console.log(
      `${nam} is booked a seat on ${this.airline} flight ${this.flyCode}-${flightNum}.`
    );
  },
};

// obj.book(877, "Mr.Anik");
// obj.book(133, "Thomson");

let outBook = obj.book;
outBook(311, "Alexa");
//Alexa is booked a seat on undefined flight undefined-311.
//outBook is another function and it placed outside of the `obj` Object, for this reason inside of the function `this` doesn't refer to `obj` Object, it refers the window object. This cause its show undefined.

//Solve this problem manually set `this` with call method .
outBook.call(obj, 133, "Anna");
//Anna is booked a seat on CTG Port flight BD-133.

/**
 * @Another_Object
 */

let boing = {
  airline: "Merica",
  flyCode: "US",
};

/**
 * @Call_Method
 * In call method first argument exactly what we want the this keyword to point to.
 *
 */

//Now I want to use boing object as this keyword
outBook.call(boing, 777, "Jessica");
//Jessica is booked a seat on Merica flight US-777.
//Everything is worked perfectly.

/**
 * @Apply_Method
 * Apply method doesn't recive a list of Argument after the this keyword. But insted it is going to take an array of Argument( argArray ).
 *
 */

outBook.apply(boing, [979, "Fiona"]);
//Fiona is booked a seat on Merica flight US-979.

/**
 * @bind_method
 * Bind method doesn't immediately call the function, it returns a new function where the this keyword is bound.
 */

let airbus = {
  airline: "France Airlines",
  flyCode: "FR",
};

//We bind this and store in boundAirbus variable, now boundAirbus is a function, so when we need this one we can simply call boundAirbus()
let boundAirbus = obj.book.bind(airbus);
boundAirbus(611, "Alica");
//Alica is booked a seat on France Airlines flight FR-611.
boundAirbus(611, "Alica");
//Alica is booked a seat on France Airlines flight FR-611.

//Now I bind boing as this keyword
let boundBoing = obj.book.bind(boing);
boundBoing(911, "Fedrick");
//Fedrick is booked a seat on Merica flight US-911.
boundBoing(69, "Mr.John Smith");
//Mr.John Smith is booked a seat on Merica flight US-69.

//This one is also correct || it looks like call method.
let airbus19 = outBook.bind(airbus, 19, "Mr.Nineteen");
airbus19();
//Mr.Nineteen is booked a seat on France Airlines flight FR-19.

//Another One
let bdAir71 = outBook.bind(obj, 71);
bdAir71("Army");
//Army is booked a seat on CTG Port flight BD-71.
