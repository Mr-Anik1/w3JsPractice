/**
 * @Higher_Order_Function
 * Higher Order function is that function that recives another function as an argument or return a function or both.
 *
 */

//First Letter will be upper case.
let upper = function (str) {
  let [first, ...others] = str.split("");
  return [first.toUpperCase(), ...others].join("");
};

//It will remove spaces in the sentence and makes it one word.
let oneWord = function (str) {
  return str.replace(/ /g, "").toLowerCase();
};

//transformer is a Higher Order Function beacuse it recives a function as an argument.
let transformer = (str, fn) => {
  console.log(`Transformed By: ${fn.name}`);
  return `Transformer: ${fn(str)}`;
};

//In this case transformer is a higher order function and upper is a callback function.
console.log(transformer("hello this is JavaScript", upper));
//Transformed By: upper
//Transformer: Hello this is JavaScript

//In this case transformer is a higher order function and oneWord is a callback function.
console.log(transformer("Urrraaa This is Russia", oneWord));
//Transformed By: oneWord
//Transformer: urrraaathisisrussia

/**
 * @Create_a_function_that_returns_another_function
 */
let greet = (greeting) => {
  return function (nam) {
    //greeting from closure box
    console.log(`${greeting} ${nam}`);
  };
};

let greetHey = greet("Hey"); //=> when greet() is called then Hey/greeting should be vanished, but it is still alive in closure box.
greetHey("Anik"); //Hey Anik
greetHey("Mr.Thomas"); //Hey Mr.Thomas

//Immidiately Call
greet("Good Morning")("Alexa"); //Good Morning Alexa

/**
 * @Another_Example_with_Arrow_function
 */
let anotherGreet = (greeting) => (nam) => `${greeting} ${nam}`;

let myCuteGreet = anotherGreet("Hello");
console.log(myCuteGreet("Mr.Anik")); //Hello Mr.Anik
console.log(myCuteGreet("Jessica")); //Hello Jessica
