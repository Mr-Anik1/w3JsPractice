// let arr = [67, 69, 78, 56];

// console.log([...arr.entries()]);
// //[ [ 0, 67 ], [ 1, 69 ], [ 2, 78 ], [ 3, 56 ] ]

// console.log(Object.fromEntries(arr.entries()));
// //{ '0': 67, '1': 69, '2': 78, '3': 56 }

// for (let [i, v] of arr.entries()) {
//   console.log(i, v);
// }

/**
 * @Optional_Chaining
 */

let obj = {
  nam: "aa",
  age: "rt",
  mon: {
    hi: "Hello",
    time: {
      sat: 10,
      mon: 5,
    },
  },
  fri: {
    gi: 0,
  },
  order(val) {
    return `Thank You ${val} For Your Order!`;
  },
};

console.log(obj.fri?.gi ?? "close"); //0
console.log(obj.sat?.gi ?? "close"); //close
//Optional Chaining?. and Nullish Collesion??

/**
 * @Does_Method_is_Exist
 * method?.()
 */
console.log(obj.order?.("Mr.Anik") ?? `Method Doesn't Exist`);
//Thank You Mr.Anik For Your Order!

console.log(obj.marder?.("Mr.Anik") ?? `Method Doesn't Exist`);
//Method Doesn't Exist

/**
 * @Does_Array_is_Exist
 */
let arr = [
  {
    nam: "Mr.Anik",
    age: 20,
  },
];
console.log(arr[0]?.age ?? `Value Doesn't Exist`); //20
console.log(arr[3]?.age ?? `Value Doesn't Exist`);
//Value Doesn't Exist

let myArr = [];
console.log(myArr[0] ?? `Value Doesn't Exist`);
//Value Doesn't Exist
