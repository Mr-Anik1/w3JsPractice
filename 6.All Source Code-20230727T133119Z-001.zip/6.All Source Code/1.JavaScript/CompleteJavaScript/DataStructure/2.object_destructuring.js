const resturentObj = {
  nam: "The Casper",
  origin: "Ghost",
  openingHours: {
    fri: {
      open: "12 AM",
      close: "4 AM",
    },
    sat: {
      open: "1 AM",
      close: "3 AM",
    },
    sun: {
      open: "2 AM",
      close: "5 AM",
    },
  },
  categoris: ["Italian", "Pizzaria", "Vegetarian"],
};

/**
 *
 * @Object_Destructuring
 *
 */
const { nam, categoris, origin } = resturentObj;

console.log(nam); //The Casper
console.log(categoris); //[ 'Italian', 'Pizzaria', 'Vegetarian' ]
console.log(origin); //Ghost

/**
 *
 * @If_I_want to use my property insted of orginal property then orginal:myProp
 *
 */
const { nam: resturentName, categoris: foodItem, origin: type } = resturentObj;

console.log(resturentName); //The Casper
console.log(foodItem); //[ 'Italian', 'Pizzaria', 'Vegetarian' ]
console.log(type); //Ghost
//Results are same in this case nam:resturentName => nam is orginal property and resurentName is my own property.

/**
 *
 * @Default_Values
 * property=dafaultValue
 * When property doesn't exist then use default value, if property is exist then default value doesn't use.
 *
 */
const { menu = [], categoris: item = [] } = resturentObj;

console.log(menu); //[]
console.log(item); //[ 'Italian', 'Pizzaria', 'Vegetarian' ]
//In this case menu doesn't exist so if I didn't use default value then it returns undefined. Here I use default value empty array[], so menu return empty array [] insted of undefined.

/**
 * @Nested_Object
 */
const {
  sat: { open: o, close: c },
} = resturentObj.openingHours;

console.log(o); //1 AM
console.log(c); //3 AM

/**
 *
 *
 * @Destructuring_in_function_parameter
 *
 * @parameter order doesn't matter
 *
 * In this case we pass an object in the argument and in parameter we immediately destructuring these object.
 *
 *
 */
function orderDelivery({ price, time, nam, deliveryItem }) {
  return `Hello Mr.${nam} your order item is ${deliveryItem} its price ${price} BDT and your delivery time is ${time}.`;
}

console.log(
  orderDelivery({
    nam: "Anik",
    deliveryItem: "Chicken",
    price: 200,
    time: "1 PM",
  })
);
//Hello Mr.Anik your order item is Chicken its price 200 BDT and your delivery time is 1 PM.

/**
 *
 *
 * @Test_Case
 *
 *
 */

//It is not working properly beacuse order doesn't correct
function go2(nam, item, live, age) {
  return `Hi ${nam}, your age is ${age}, your favourite food is ${item} you live in ${live}`;
}
console.log(go2("Anika", 20, "fruit", "Bangladesh"));
//Hi Anika, your age is Bangladesh, your favourite food is 20 you live in fruit

/**
 *
 * @Order doesn't matter it works properly
 *
 */
function go({ nam, item, live, age }) {
  return `Hi ${nam}, your age is ${age}, your favourite food is ${item} you live in ${live}`;
}

console.log(go({ nam: "Anika", age: 20, item: "fruit", live: "Bangladesh" }));
//Hi Anika, your age is 20, your favourite food is fruit you live in Bangladesh
