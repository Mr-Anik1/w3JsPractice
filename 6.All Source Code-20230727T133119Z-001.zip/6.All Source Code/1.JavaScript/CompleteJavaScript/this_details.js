//"use strict";
/**
 * @THIS_useCase
 */

//This Test
//console.log("console=>", this);
//Result: Window{} Object

function normalFunk() {
  console.log("NormalFunk=>", this);
}
//normalFunk();
//Result: In strict mode `this` inside regular function it returns `undefined` Otherwie its returns `Window{} Object`

let arrowFunk = () => {
  console.log("ArrowFunk=>", this);
};
//arrowFunk();
//Result: Window{} Object

/**
 * @this_inside_an_object
 */
let testObj = {
  firstName: "Anik",
  lastName: "Manik",

  //Method ~ Function Expression
  normalFunk: function () {
    console.log("NormalFunk~this:", this); //In here `this` refer `testObj` Object
    return `Hey ${this.firstName} How are you?`;
  },

  //Method ~ Arrow Function
  arrowFunk: () => {
    console.log("ArrowFunk~this:", this); //In here `this` refer `Window` Object
    return `Hey ${this.lastName} is your last name?`;
  },
};

//console.log(testObj.normalFunk());
/**
   * @Result_of_Normal_Function
   * 
      NormalFunk~this: {
      firstName: 'Anik',
      lastName: 'Manik',
      normalFunk: [Function: normalFunk],
      arrowFunk: [Function: arrowFunk]
     }
  
     Hey Anik How are you?
   * 
   */

//console.log(testObj.arrowFunk());
/**
   * @Result_of_Arrow_Function
   * 
      ArrowFunk~this: Window{}
  
     Hey undefined is your last name?
        => this.lastName => window.lastName => undefined
   * 
   */

/**
 * @Another_Example
 */
let testObj1 = {
  nam: "Anik",
  lastName: "Manik",

  //Method ~ Function Expression
  normalFunk: function () {
    console.log("1.NormalFunk~", this); //In here `this` refer `testObj1` Object

    /**
       * @Functon_in_Inside_Method
         Function in inside method `this` refer `window Object` for this reason when I call `insideFunk()` function `this` return `window` and `this.nam` return `undefined`
       * 
       */
    let insideFunk = function () {
      console.log("2.insideFunk~", this); //In here `this` refer `Window` Object
      console.log(`Hey ${this.nam}`);
    };
    insideFunk();
    /**
       * @Solve_this_problem_using_call_or_arrow_function
       * 
         insideFunk.call(testObj1);
              or
         let insideFunk=()=>{}
       * 
       */
  },

  //Method ~ Arrow Function
  greet: () => {
    return `greet~ArrowFunk=>${this}`; //In here `this` refer `Window` Object
    // console.log("greet~ArrowFunk=>", this);
  },
};

//testObj1.normalFunk();
//console.log(testObj1.greet());
