let parentsHtml = document.querySelector(".footer");

let payments = [-700, 900, -500, 200, 1000, -400, -200, 6000];

payments.forEach((value, i) => {
  (function (value, i) {
    setTimeout(() => {
      let paymentType = value > 0 ? "diposit" : "withdraw";
      let newHtml = `<p class="item ${paymentType}">${paymentType} ${Math.abs(
        value
      )}</p>`;
      //Add New HTML in every iteration
      parentsHtml.insertAdjacentHTML("afterbegin", newHtml);
    }, (i + 1) * 800);
  })(value, i);
});
