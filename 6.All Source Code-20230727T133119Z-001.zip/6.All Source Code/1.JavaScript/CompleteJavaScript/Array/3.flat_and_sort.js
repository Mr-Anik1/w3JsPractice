let arrOfObj = [
  { obj1: "Hello", arr: [0, [10, 23]] },
  { obj2: "Gelo", arr: [1, [20, 34]] },
  { obj3: "What", arr: [2, [30, 56]] },
  { obj4: "Who", arr: [3, [40, 67]] },
  { obj5: "Where", arr: [4, [50, 98]] },
];

//First used map then flat()
let mapArr = arrOfObj.map((obj) => obj.arr);
//console.log(mapArr.flat(2));
//[ 0, 10, 23, 1, 20, 34, 2, 30, 56, 3, 40, 67, 4, 50, 98 ]

/**
 * @Using_flatMap
 * flat() and map() together
 */
let flatMap = arrOfObj.flatMap((obj) => obj.arr);
//console.log(flatMap);
/**
 * @It_works_only_one_D_array
 * 
   [
     0, [ 10, 23 ],
     1, [ 20, 34 ],
     2, [ 30, 56 ],
     3, [ 40, 67 ],
     4, [ 50, 98 ]
   ]
 * 
 */

/**
 * @Deep_flat_using_reduce_method
 * Highly recommand
 */
let flaten = (arr) =>
  arr.reduce(
    (acc, cur) => acc.concat(Array.isArray(cur) ? flaten(cur) : cur),
    []
  );

//console.log(flaten(mapArr));
//[ 0, 10, 23, 1, 20, 34, 2, 30, 56, 3, 40, 67, 4, 50, 98 ]

/**
 * @Sort
 *
 * return < 0 -> a,b
 * return > 0 -> b,a
 *
 * @Assening_Order
   nArr.sort((a, b) => {
     if (a > b) {
       // b is less than a :=> return > 0 -> b,a
       return 1;
     }
     if (b > a) {
       // a is less than b :=> return < 0 -> a,b
       return -1;
     }
   });
 * 
 * 
 * @Assening_Order
 * nArr.sort((a,b)=>a-b)
 * 
 */

let nArr = flaten(mapArr).sort((a, b) => a - b);
//console.log(nArr);
//[ 0,  1,  2,  3,  4, 10, 20, 23, 30, 34, 40, 50, 56, 67, 98 ]
