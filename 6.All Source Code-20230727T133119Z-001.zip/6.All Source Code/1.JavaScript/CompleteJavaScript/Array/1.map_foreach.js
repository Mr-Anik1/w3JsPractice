// let juliasPet = [3, 5, 2, 12, 7];
// let katesPet = [4, 1, 15, 8, 3];

// let checkDogs = (julia, kate) => {
//   let juliasDog = julia.slice(1, -2);
//   let allPets = juliasDog.concat(kate);

//   allPets.forEach((v, i) => {
//     let type = v >= 3 ? `an adult, and is ${v} years old.` : "still a puppy";
//     console.log(`Dog number ${i + 1} is ${type}`);
//   });
// };
// checkDogs(juliasPet, katesPet);

// let euros = [40, 21, 15, 18, 3];
// let dollars = euros.map((v) => +(v * 1.1).toFixed(2));
// console.log(dollars);

let user1 = "Steven Thomas Williams";
let user2 = "Manik Chandra Chattapwaddy";
let user3 = "Thomas Alva Edision";

let userName = (user) => {
  return user
    .split(" ")
    .map((v) => v[0])
    .join("")
    .toLocaleLowerCase();
};

// console.log(userName(user1)); //stw
// console.log(userName(user2)); //mcc
// console.log(userName(user3)); //tae

let person1 = {
  owner: "Nicola Tesla",
  profession: "Scientiest",
  age: 68,
};

let person2 = {
  owner: "Jagodish Chandra Bosu",
  profession: "Scientiest",
  age: 40,
};

let person3 = {
  owner: "Mark Zuckerberg",
  profession: "Programmer",
  age: 19,
};

let person4 = {
  owner: "Kazi Nazrul Islam",
  profession: "Poet",
  age: 33,
};

let person5 = {
  owner: "Denich Ricchi",
  profession: "Programmer",
  age: 52,
};

let persons = [person1, person2, person3, person4, person5];

let modifiedPerson = (personArr) => {
  personArr.forEach((person) => {
    //add userName property in every object
    person.userName = person.owner
      .split(" ")
      .map((v) => v[0])
      .join("")
      .toLocaleLowerCase();
  });
};

// modifiedPerson(persons);
// console.log(persons);
/**
 * @Modified_Object__add_userName_property
 * 
[
  {
    owner: 'Nicola Tesla',
    profession: 'Scientiest',
    age: 68,
    userName: 'nt'
  },
  {
    owner: 'Jagodish Chandra Bosu',
    profession: 'Scientiest',
    age: 40,
    userName: 'jcb'
  },
  {
    owner: 'Mark Zuckerberg',
    profession: 'Programmer',
    age: 19,
    userName: 'mz'
  },
  {
    owner: 'Kazi Nazrul Islam',
    profession: 'Poet',
    age: 33,
    userName: 'kni'
  },
  {
    owner: 'Denich Ricchi',
    profession: 'Programmer',
    age: 52,
    userName: 'dr'
  }
]

 * 
 */

/**
 * @If_I_Want_to_Extract_Only_UserName
 */
let extractUserName = (personArr) => {
  return personArr.map((person) =>
    person.owner
      .split(" ")
      .map((v) => v[0])
      .join("")
      .toLocaleLowerCase()
  );
};

//console.log(extractUserName(persons));
//[ 'nt', 'jcb', 'mz', 'kni', 'dr' ]
