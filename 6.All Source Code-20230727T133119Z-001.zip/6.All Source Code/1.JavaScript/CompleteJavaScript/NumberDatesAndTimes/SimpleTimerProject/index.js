let startBTN = document.querySelector(".btn");
let counter = document.querySelector(".timer");

startBTN.addEventListener("click", () => {
  //When timer will start then start button will be disabled.
  startBTN.disabled = true;
  let time = 120;
  let timer = setInterval(() => {
    let min = `${Math.trunc(time / 60)}`.padStart(2, 0);
    let sec = `${time % 60}`.padStart(2, 0);

    //Set minute & second format
    counter.textContent = `${min}:${sec}`;

    //when time will less than 0 or equal to 0 then timer will be stopped.
    if (time <= 0) {
      clearInterval(timer);
    }

    //Decresed time
    time--;
  }, 1000);
});
