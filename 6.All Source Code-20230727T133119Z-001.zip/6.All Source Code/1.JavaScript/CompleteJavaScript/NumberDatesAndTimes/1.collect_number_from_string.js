/**
 * @Collect_Number_from_string
 */

let numStr = "34tyGH7xg489iTzE2o5Pu";
console.log(+numStr.replace(/[^\d]/g, ""));
//34748925

/**
 * @Hint
 * console.log(!+"a"); //true -> +'a' -> NaN -> !NaN -> true
   console.log(!+"1"); //false -> +'1' -> 1 -> !1 -> false
   // So we decided that when !+v returns false then it is Number and when true then it is string.

   !+v same as Number.isNaN(+v) 
 * 
 */
let num = +numStr
  .split("")
  .filter((v) => !+v === false)
  .join("");

console.log(num); //34748925

console.log(numStr.match(/[\d]/g).map((v) => +v));
//All values are number: [ 3, 4, 7, 4, 8, 9, 2, 5 ]

/**
 * @Best_Way
 * isFinite() is the best way of checking if a value is a number.
 *
 */
let num2 = +numStr
  .split("")
  .filter((v) => Number.isFinite(+v))
  .join("");

console.log(num2); //34748925
