// //Square Root
// console.log(Math.sqrt(25)); //5
// console.log(25 ** (1 / 2)); //5

// //Qubic Root
// console.log(8 ** (1 / 3)); //2

// //Maximum Number
// console.log(Math.max(23, 123, 90, 45, 234, 1, 67, 2)); //234

// //Minimum Number
// console.log(Math.min(23, 90, 45, 234, 1, 67, 2)); //1
let days = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thurstday",
  "friday",
  "saturday",
];

let now = new Date();

// let day = `${now.getDate()}`.padStart(2, 0);
// let month = `${now.getMonth() + 1}`.padStart(2, 0);
// let year = now.getFullYear();
// let hour = now.getHours();
// let minute = now.getMinutes();
// let amPm = hour >= 12 ? `PM` : `AM`;

// let todaysDate = `${day}/${month}/${year} ~ ${hour}:${minute} ${amPm}`;
// console.log(todaysDate);

// console.log(now.toISOString());

//Claculate Dates
// let calcDate = (date1, today) => {
//   let res = Math.abs((today - date1) / (1000 * 60 * 60 * 24));
//   return res === 0 ? `Today` : `${res} days ago.`;
// };

// console.log(calcDate(new Date(), new Date()));
// console.log(calcDate(new Date("2023-05-15"), new Date("2023-05-25")));

/**
 * @Internationalization_Date
 * Date and time format for every single country.
 * Intl Object -> DateTimeFormat('Locals',options) -> format(Date objet)
 */

//Option Object is very important for format date and times.
let options = {
  hour: "numeric",
  minute: "numeric",
  day: "numeric",
  month: "numeric", //'long' or 'numeric',
  year: "numeric", // only 'numeric'
  weekday: "long", //only 'long'
};

let bdTimeOptions = {
  hour: "numeric",
  minute: "numeric",
};
//Only Bangladesh Date Format
console.log(Intl.DateTimeFormat("bn-BD").format(now));
// ২/৫/২০২৩

//Only Bangladesh Time Format
console.log(Intl.DateTimeFormat("bn-BD", bdTimeOptions).format(now));
// ১২:০৯ PM

//USA Time & Date Format
console.log(Intl.DateTimeFormat("en-US", options).format(now));
//Tuesday, 5/2/2023, 12:15 PM

//Bangladesh Time & Date Format
console.log(Intl.DateTimeFormat("bn-BD", options).format(now));
// মঙ্গলবার, ২/৫/২০২৩ ১২:১৯ PM

// //UK
// console.log(Intl.DateTimeFormat("en-UK").format(now));
// //02/05/2023

// //Syria
// console.log(Intl.DateTimeFormat("ar-SY").format(now));
// //٢/٥/٢٠٢٣

// console.log(Intl.DateTimeFormat("af").format(now));

/**
 * @Dynamic_locals_using_user_browser
 * Test in browser
 */
// let dynamicLocals = navigator.language;

// console.log(Intl.DateTimeFormat(dynamicLocals, options).format(now));

/**
 * @Number_Format
 */
let num = 56348.35;
let numOptions = {
  style: "unit",
  unit: "mile-per-hour",
};

//Syria
console.log("Syria: ", new Intl.NumberFormat("ar-SY").format(num));
// Syria: ٥٦٬٣٤٨٫٣٥

//Bangladesh
console.log("Bangladesh: ", new Intl.NumberFormat("bn-BD").format(num));
// Bangladesh:  ৫৬,৩৪৮.৩৫

//USA
console.log("USA: ", new Intl.NumberFormat("en-US").format(num));
// USA:  56,348.35

let currencyOptions = {
  style: "currency",
  currency: "BDT",
};

//This currencyOptions set ৳ sign.
console.log(
  "Bangladesh: ",
  new Intl.NumberFormat("bn-BD", currencyOptions).format(num)
);
//Bangladesh:  ৫৬,৩৪৮.৩৫৳

// setTimeout(
//   (firstName, lastName) =>
//     console.log(`Hello my name is ${firstName} ${lastName}`),
//   2000,
//   "Mr.",
//   "Anik"
// );

// let time = 5;
// let timer = setInterval(() => {
//   let min = `${Math.trunc(time / 60)}`.padStart(2, 0);
//   let sec = `${time % 60}`.padStart(2, 0);

//   //Print Minute & Second Format
//   console.log(`${min}:${sec}`);

//   //When time will 0 then timer will be stopped.
//   if (time === 0) {
//     clearInterval(timer);
//   }

//   //Decresed time
//   time--;
// }, 1000);
