let pass =
  "a3b5c1a2d4 s2a5c4bb24d b2a2c1b2d4 b4a2d1b2c5 b2a32c14bb24d4 e3b2c1a2d4 c5a2d1c2b4 b6a2c1b2d4";

let regGrouping = /([a-d][1-5]){5}/gi;
console.log(pass.match(regGrouping));
//[ 'a3b5c1a2d4', 'b2a2c1b2d4', 'b4a2d1b2c5', 'c5a2d1c2b4' ]

//In this instance, I was grouping with (), which implies that the range [a-d] first chooses one value, followed by [1-5], and it means ([a-d][1-5]) is grouping. This procedure is repeated five times.

/**
 * @Explain
 * 
 The given string pass contains multiple sets of characters that are separated by spaces. Each set contains a combination of 5 letters from a to d and numbers from 1 to 5.


 The regular expression regGrouping is defined with the pattern ([a-d][1-5]){5}. This pattern includes a grouping mechanism using parentheses (). The grouping mechanism ( ) implies that the range [a-d] first chooses one character from a to d, followed by one number from 1 to 5. The {5} quantifier specifies that this entire pattern should be repeated exactly 5 times, forming a group of 5 characters.
 * 
 */

/**
 * @Using_pipe_and_grouping
 */

let text1 =
  "Each and every Friday, at the beginning of the day, we hold a staff meeting. At the Tuesday staff meeting, you will need to make a report on the past weeks progress, and you will receive assignments for the following sunday. Just be aware that somedays this Tuesday meeting might not occur. When that happens, we will make an announcement. Oh my saturdayNT and Thursday. FridayNT sundayNT TuesdayNT";

/*

   Every time I use word boundaries It is not good practice

  let reg2 =
  /\bsaturday\b|\bsunday\b|\bmonday\b|\btuesday\b|\bwednesday\b|\bthursday\b|\bfriday\b/gi;

*/

//In this case I use grouping mechanism all the days and then use word boundaries
let reg2 = /\b(saturday|sunday|monday|tuesday|wednesday|thursday|friday)\b/gi;
console.log(text1.replace(reg2, "Monday"));
//Each and every Monday, at the beginning of the day, we hold a staff meeting. At the Monday staff meeting, you will need to make a report on the past weeks progress, and you will receive assignments for the following Monday. Just be aware that somedays this Monday meeting might not occur. When that happens, we will make an announcement. Oh my saturdayNT and Monday. FridayNT sundayNT TuesdayNT

/**
 *
 * @Using_Grouping_With_JavaScript
 *
 */

let dat = "2003-02-23";
let dat2 = "2003.02.23";

let datReg = /^(\d{4})[-./](\d{1,2})[-./](\d{1,2})$/;

console.log(datReg.test(dat)); //true
console.log(datReg.test(dat2)); //true
console.log(datReg.exec(dat));
/**
 * @Its_looks_like_split_method
 * 
   [
    '2003-02-23',
    '2003',
    '02',
    '23',
    index: 0,
    input: '2003-02-23',
    groups: undefined
  ]
 
  datReg.exec(dat)[0] => '2003-02-23'
  datReg.exec(dat)[1] => '2003'
  datReg.exec(dat)[2] => '02'
  datReg.exec(dat)[3] => '23'

 */

/**
 * @Simple_Split_Like_Function_With_Grouping_in_Regular_Expression
 *
 */
let regSplit = (str) => {
  let datReg = /^(\d{4})[-./](\d{1,2})[-./](\d{1,2})$/;
  let year, month, day;

  if (datReg.test(str)) {
    let splitResArr = datReg.exec(str);
    year = splitResArr[1];
    month = splitResArr[2];
    day = splitResArr[3];
  }

  return `Year:${year}, Month:${month}, Day:${day}`;
};

console.log(regSplit("2003-02-23"));
//Year:2003, Month:02, Day:23
console.log(regSplit("2023.03.31"));
//Year:2023, Month:03, Day:31

/**
 *
 * @How_Can_I_Write_Regular_Expression_With_Grouping
 *
 */
let tel1 = "12347";
let tel2 = "12345-4444";

let reg1 = /^[0-9]{5}(-[0-9]{4})?$/;
console.log(reg1.test(tel1)); //true
console.log(reg1.test(tel2)); //true

/*
   In this code -[0-9]{4} is optional ?

   The ^ and $ anchors match the start and end of the string respectively, so this regular expression ensures that the string contains exactly 5 digits at the beginning followed by an optional hyphen and 4 more digits.

*/

/**
 * @Capturing_Group
 *
 * @Non_Capturing_Group
 * (?:\d{4}) => ?: implies that it is non capturing group
 */

let yearStr = "2018/3/25";

//let helloCapture = /^(\d{4})[-./](\d{1,2})[-./](\d{1,2})$/;
let helloCapture = /^(\d{4})([-./])(\d{1,2})\2(\d{1,2})$/;
//We repeat ([-./])
//for this reason we use capturing group policy
//In this case ([-./]) is => 2
//for this reason when we repeat it then we simply use \2

console.log(yearStr.match(helloCapture));
/*

  [
   '2018/3/25',
   '2018',
   '/',
   '3',
   '25',
   index: 0,
   input: '2018/3/25',
   groups: undefined
  ]

*/
console.log(helloCapture.test(yearStr)); //true

/**
 *
 * @LookAhead_Group
 * 
 * @Positive_LookAhead_Group ?=
 *  
  Positive lookahead is denoted by (?=pattern) and matches the pattern only if it is followed by another pattern. For example, the regular expression /foo(?=bar)/ would match the string "foobar" but not "foobaz".
 * 
 *
 */

let dotCom =
  "helloanik.com theanik.co and the future.com is very helpful for us. The google.com is not chatGPT.net I hope bing.co is not a big issu for alphabet.net. https://jsinfo.com";
let lookAhedReg1 = /\w+(?=\.com)/g;
//it matches one or more word characters (\w+) that are immediately followed by the string .com using a positive lookahead group ((?=\.com)).
console.log(dotCom.match(lookAhedReg1));
//[ 'helloanik', 'future', 'google', 'jsinfo' ]

//The previous string of .com means only the domain name is selected, and https:// is also not selected. Any other string or domain name is not selected.

/**
 * @Password_Matching
 *
 * `/^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).*$/`
 *
 */
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)\w{8,}$/;

let passStr = "Abcd1234abcd1234ABCD1234Abcd";

console.log(passwordRegex.test("Abcd1234")); // true
console.log(passwordRegex.test("abcd1234")); // false (no uppercase letter)
console.log(passwordRegex.test("ABCD1234")); // false (no lowercase letter)
console.log(passwordRegex.test("Abcd")); // false (too short)
console.log(passwordRegex.test(passStr)); //true
/*
   \w  => [a-zA-Z0-9_]
   
   In this example, we use three positive lookahead groups to assert that the password contains at least one lowercase letter, one uppercase letter, and one digit. The .{8,} portion of the regex matches any character 8 or more times to ensure that the password is at least 8 characters long. Finally, we use the \w => [a-zA-Z\d]{8,} pattern to match any combination of uppercase letters, lowercase letters, and digits that is at least 8 characters long.
*/

/*



-------------/////------------/////----------------/////-------



*/

/**
 * @Negative_LookAhead_Group ?!
 * 
 *
  Negative lookahead is denoted by (?!pattern) and matches the pattern only if it is not followed by another pattern. For example, the regular expression /foo(?!bar)/ would match the string "foobaz" but not "foobar".
 * 
 */

/*

     /\w+(?=\.com)/  vs /\w+(?=.com)/

  The regular expression /\w+(?=\.com)/ matches one or more word characters that are immediately followed by the string ".com" using a positive lookahead group. The reason why it does not match "www" in the string "www.example.com" is because "www" is not immediately followed by the string ".com".

  On the other hand, the regular expression /\w+(?=.com)/ matches one or more word characters that are followed by the string ".com" using a positive lookahead group. The reason why it matches "www" in the string "www.example.com" is because "www" is followed by the string ".com".

  The difference between the two regular expressions is that the first one (/\w+(?=\.com)/) matches a word character sequence that is immediately followed by the string ".com", whereas the second one (/\w+(?=.com)/) matches a word character sequence that is followed by the string ".com" but does not require it to be immediately following the sequence.


  */
