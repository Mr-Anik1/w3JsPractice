/**
 * @Exercise_6
 *
 * Extract all the numbers from this phrase and capture those numbers. Then sum the numbers.
 *
 */

let phrase =
  "First number: 32 and second number: 100. Here is the last number 15.";

let captureNumber = (str) => {
  let reg = /\d{1,}/g;
  let numberArr = str.match(reg);
  return numberArr.reduce((acc, cur) => {
    return acc + +cur;
  }, 0);
};

console.log(captureNumber(phrase)); //147

/*
   You can use \d+ insted of \d{1,}

   //let reg = /\d+/g;
   let reg2 = /\d{1,}/g;
   console.log(phrase.match(reg2));
   //[ '32', '100', '15' ]
*/

/**
 * @Exercise_7
 *
 * Retrieve the starting index for the match, the length of the match and the actual match.
 *
 */

let retrieveIndex = (str) => {
  let reg = /\d{1,}/;
  let detailArr = reg.exec(phrase);
  return `Starting Index: ${detailArr.index}, Length of the Match: ${detailArr[0].length} and The Actual Match: ${detailArr[0]}`;
};

console.log(retrieveIndex(phrase));

/**
 * @Exercise_8
 *
 * Iterate over each match and log the information to the console.
 *
 * In this case I use \d+ insted of \d{1,}
 *
 */

let iterateMatch = (str) => {
  let reg = /\d+/g;
  let matchesArr = str.match(reg);
  matchesArr.forEach((v) => console.log(v));
};

iterateMatch(phrase);
/*
   32
   100
   15
*/
