/*

   g - global flag match more than one occurance
   i - case insensitive flag case doesn't matter
   m - multi-line match

*/
let text =
  "Hello what is your nameS ? The ss developmentS in the Europe is so far";

let reg1 = /s\s/g;
//s means we are searching for s in the text, and \s means space, so finally, when s and space are connected( 's')) then it matches. last g for global flag.

console.log(text.match(reg1));
//[ 's ', 's ', 's ' ]
//In the text we have three s+space( 's ' )

let regCaseInsensitive = /s\s/gi;
console.log(text.match(regCaseInsensitive));
//[ 's ', 'S ', 's ', 'S ', 's ' ]
//In the text, we have five s+space( 's ' ) but in the previous example, it shows only three. In this case, we have used the case-insensitive flag(i) which means we don't care what the case is. As a result, all targeted items are displayed in upper and lower case. 
