let txt = "Hello this is last first and Hello this is last";

/**
 * @Match_First_Chracter
 * @Its_Like_startsWith ()
 * ^ indicate if is it first chracter
 */
let regEx1 = /^Hello/g;
let regEx2 = /^first/g;
console.log(regEx1.test(txt)); //true
console.log(regEx2.test(txt)); //false
//console.log(txt.startsWith("Hello"));//true

/**
 * @Match_Last_Chracter
 * @Its_Like_endsWith ()
 * $ indicate if is it last chracter
 */

let regEx3 = /last$/g;
let regEx4 = /and$/g;
console.log(regEx3.test(txt)); //true
console.log(regEx4.test(regEx4)); //false
//console.log(txt.endsWith("last")); //true

/**
 * @Word_Boundaries
 * \b
 */

let wBoundaries =
  "Inplant Hello my name is Anik and I am from Bangladesh where are you from? China has been banned facebook plant. My plan is I will used Telegram";

//detect every target item even if it is not a single word
let nonWReg = /plan/gi;
console.log(wBoundaries.match(nonWReg));
//[ 'plan', 'plan', 'plan' ]

//If target item first of the word then it select
let wReg1 = /\bplan/gi;
console.log(wBoundaries.match(wReg1)); //[ 'plan', 'plan' ]

let wReg2 = /\bplan\b/gi;
//The word boundary metacharacters ensures that only the word "plan" and not substrings such as "Inplant" or "plant" are matched.
console.log(wBoundaries.match(wReg2)); //[ 'plan' ]

/**
 * @How_Can_I_Write_Regular_Expression
 */
let tel1 = "12347";
let tel2 = "12345-4444";

let reg1 = /^[0-9]{5}(-[0-9]{4})?$/;
console.log(reg1.test(tel1));
console.log(reg1.test(tel2));

/*
   In this code -[0-9]{4} is optional

   The ^ and $ anchors match the start and end of the string respectively, so this regular expression ensures that the string contains exactly 5 digits at the beginning followed by an optional hyphen and 4 more digits.

*/
