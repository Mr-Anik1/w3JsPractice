/**
 * @Exercise -4
 *
 * The content.js file contains a string of text stored in a variable text1. This string of text is a statement that contains a day of the week as a part of the statement. Write a regular expression that will match any day of the week and then replace that day of the week in the string with Monday. Display the results to the console.
 *
 */
import { text1 } from "./content.js";

let replaceReg = /\b[s,m,t,w,f][a-z]{1,4}[r,n,s,i]day\b/gi;
console.log(text1.replace(replaceReg, "Monday"));
//Each and every Monday, at the beginning of the day, we hold a staff meeting. At the Monday staff meeting, you will need to make a report on the past weeks progress, and you will receive assignments for the following Monday. Just be aware that somedays this Monday meeting might not occur. When that happens, we will make an announcement. Oh my saturdayNT and Monday. FridayNT sundayNT TuesdayNT

/**
 * @Solve_This_Problem_Using_pipe
 */
// let reg2 = /\b(saturday|sunday|monday|tuesday|wednesday|thursday|friday)\b/gi;

let reg2 =
  /\bsaturday\b|\bsunday\b|\bmonday\b|\btuesday\b|\bwednesday\b|\bthursday\b|\bfriday\b/gi;
console.log(text1.replace(reg2, "Monday"));
//Each and every Monday, at the beginning of the day, we hold a staff meeting. At the Monday staff meeting, you will need to make a report on the past weeks progress, and you will receive assignments for the following Monday. Just be aware that somedays this Monday meeting might not occur. When that happens, we will make an announcement. Oh my saturdayNT and Monday. FridayNT sundayNT TuesdayNT
