let text1 =
  "Each and every Friday, at the beginning of the day, we hold a staff meeting. At the Tuesday staff meeting, you will need to make a report on the past weeks progress, and you will receive assignments for the following sunday. Just be aware that somedays this Tuesday meeting might not occur. When that happens, we will make an announcement. Oh my saturdayNT and Thursday. FridayNT sundayNT TuesdayNT";

export { text1 };
