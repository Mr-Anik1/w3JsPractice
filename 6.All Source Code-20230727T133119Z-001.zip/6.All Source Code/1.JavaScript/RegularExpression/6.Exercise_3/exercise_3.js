/**
 * @Exercise -3
 * 
   Validate phone numbers entered into the text field. As the number is entered, check to see if it matches this formats: (nnn)-nnn-nnnn, nnn.nnn.nnnn, nnn-nnn-nnnn, nnnnnnnnnn, (nnn)nnn-nnnn. If the number matches change the text color from red to green.  
 * 
 */

(function () {
  let phone = document.getElementById("phone");
  let regPhone = /\(?\d{3}\)?[-.]?\d{3}[-.]?\d{4}$/;
  phone.addEventListener("keyup", function () {
    if (regPhone.test(phone.value)) {
      phone.classList.remove("red");
      phone.classList.add("green");
    } else {
      phone.classList.remove("green");
      phone.classList.add("red");
    }
  });
})();

/**
 * @Explain => let regPhone = /\(?\d{3}\)?[-.]?\d{3}[-.]?\d{4}/;
 * 
   
  / : Start of the regular expression pattern

  \(? : An optional opening parenthesis (\(). The backslash (\) is used to escape the parenthesis, because parentheses have a special meaning in regular expressions.

  \d{3} : Exactly three digits. The \d shorthand character class matches any digit [0-9], and the {3} quantifier means "exactly three times".

  \)? : An optional closing parenthesis (\)). Again, the backslash is used to escape the parenthesis.

  [-.]? : An optional dash (-) or period (.) character. The square brackets ([]) create a character set, which means "match any of the characters inside". The question mark (?) after the character set makes it optional.

  \d{3} : Another group of exactly three digits.

  [-.]? : Another optional dash or period character.

  \d{4} : Exactly four digits.

  $  : add a $ at the end of the pattern to ensure that there are no extra digits after the last group.

  / : End of the regular expression pattern.
 * 
 */
