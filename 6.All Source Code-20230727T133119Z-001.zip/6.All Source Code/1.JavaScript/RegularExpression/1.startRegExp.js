//There are two way to create Regular Expression

let txt = "Programming courses always starts with a hello world example";

//Constructor
let constructReg = new RegExp("hello");
console.log(constructReg.test(txt)); //true
//In this code, I checked if "hello" exists in this code; yes, "hello" exists in this code, so it returns true.

//Literal
let literalReg = /world/;
console.log(literalReg.test(txt)); //true

let reg1 = /good/;
console.log(reg1.test(txt)); //false
//I checked if "good" exists in this code; no, "good" doesn't exist in this code, so it returns false.

console.log(literalReg.exec(txt));
//'world' match in 47 no index in this txt
/*
   [
    'world',
     index: 47,
     input: 'Programming courses always starts with a hello world example',
     groups: undefined
  ]
*/

console.log(txt.match("courses"));
/*
returns of an array of matches just like exec() in RegExp

    [
     'courses',
      index: 12,
      input: 'Programming courses always starts with a hello world example',
      groups: undefined
    ]
*/

let spa = /\s/; //In RegExp it means space
console.log(txt.split(spa));
/*
Plain text to an array of Strings

  [
  'Programming', 'courses',
  'always',      'starts',
  'with',        'a',
  'hello',       'world',
  'example'
 ]

*/
