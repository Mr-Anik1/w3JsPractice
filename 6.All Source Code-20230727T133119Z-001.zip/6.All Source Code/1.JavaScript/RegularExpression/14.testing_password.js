let passwordValidator = (pass) => {
  let theLength = /^.{8,32}$/,
    upper = /[A-Z]/,
    lower = /[a-z]/,
    number = /[0-9]/,
    specialChar = /[^a-zA-Z0-9]/;
  if (
    theLength.test(pass) &&
    upper.test(pass) &&
    lower.test(pass) &&
    number.test(pass) &&
    specialChar.test(pass)
  ) {
    return `Password is valid`;
  } else {
    return `Password is invalid`;
  }
};

console.log(passwordValidator("Hell@4d$T9")); //Password is valid

// let pass = "Hell@4d$T9";
// let specialChar = /([^A-Za-z0-9])/g;
// console.log(pass.match(specialChar));
