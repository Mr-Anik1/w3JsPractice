let str = "<b>Hello My Name is Anik</b>";

let reg = /b\>/g;
//console.log(str.replace(reg, "strong>"));
//console.log(str.replaceAll("b>", "strong>"));

//repalce
let data = ["Jasen, Dale", "Smith, Andrea", "Lopez, Monica"];
let nName = data.map((v) => {
  return v.replace(/(\w+),[\s]?(\w+)/, "$2 $1");
});
console.log(nName);
//[ 'Dale Jasen', 'Andrea Smith', 'Monica Lopez' ]
