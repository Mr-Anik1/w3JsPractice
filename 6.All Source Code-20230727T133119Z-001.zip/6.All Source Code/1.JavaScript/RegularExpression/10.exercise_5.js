/**
 * @Exercise_5
 *
 * Iterate through the data provided. Use a regular expression to store the names in a new array but change the order of the name so first name is listed first and last name is last
 *
 * /(^[a-z]{1,8})[,-/][\s]?([a-z]{1,8})$/i
 * simillar => /(\w+),[\s]?(\w+)/
 *
 */

let data = ["Jasen, Dale", "Smith, Andrea", "Lopez, Monica"];

let listedName = (arr) => {
  let reg = /^([a-z]{1,8})[,-/][\s]?([a-z]{1,8})$/i;
  let nameArr = [];
  for (let i = 0; i < arr.length; i++) {
    if (reg.test(arr[i])) {
      let fullName = `${reg.exec(arr[i])[2]} ${reg.exec(arr[i])[1]}`;
      nameArr.push(fullName);
    }
  }
  return nameArr;
};

console.log(listedName(data));
//[ 'Dale Jasen', 'Andrea Smith', 'Monica Lopez' ]

/**
 * @Another_Way
 * @Not_Good
 */

let anotherName = (arr) => {
  let reg = /(\w+),[\s]?(\w+)/;
  return arr.map((v) => v.replace(reg, "$2 $1"));
};
console.log(anotherName(data));
//[ 'Dale Jasen', 'Andrea Smith', 'Monica Lopez' ]
