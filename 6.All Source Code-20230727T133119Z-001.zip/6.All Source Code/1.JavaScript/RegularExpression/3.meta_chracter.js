let txt = "Hello who are you? Whats your name? Y#u yooou whTRe whatero bou ";

let wildCard = /y.u/gi;
//In this case . Indicate any single character after y.

//console.log(txt.match(wildCard));
//[ 'you', 'you', 'Y#u' ]

let reg2 = /o\u\s/g;
//escape \
// o\u\s means that there must be an u after the letter o and a space after the u.

//console.log(txt.match(reg2));
//[ 'ou ', 'ou ' ]

/*
    \t tab
    \v verticle tab
    \n new line
    \c carriage return
*/

/**
 * @Exercise -1
 * Using the provided array, create a second array that only includes the numbers with the 801 area code. (The area code is the first 3 numbers)
 */

let phoneNumbers = [
  "801-766-9786",
  "456-766-9786",
  "322-676-8016",
  "801-932-5676",
  "456-789-8016",
  "801-789-2316",
  "456-676-9096",
  "801-421-1201",
];

let only801 = (arr) => {
  let reg = /801\-/;
  let nArr = arr.filter((v) => reg.test(v));
  return nArr;
};

//console.log(only801(phoneNumbers));
//[ '801-766-9786', '801-932-5676', '801-789-2316', '801-421-1201' ]

/**
 * @Antother
 */

let text1 = "grey of gray of the grty groy";
let reg3 = /gr[ea]y/g;
// Inside the square bracket character, only one of them will be used: e or a. In this case, the gray or gray word will be match.
//console.log(text1.match(reg3));
//[ 'grey', 'gray' ]

let reg4 = /[r][ea]/g;
//console.log(text1.match(reg4));
//[ 're', 'ra' ]

/**
 * @How_many_vowels_in_the_text
 */

let vow = "The name of my country is Bangladesh. I love my country very much.";
let selectVow = /[aeiou]/gi;
//console.log(vow.match(selectVow));
// [ 'e', 'a', 'e', 'o', 'o', 'u', 'i', 'a', 'a', 'e', 'I', 'o', 'e', 'o', 'u', 'e', 'u' ]
//console.log(vow.match(selectVow).length); //17

/**
 * @Specifying_range
 */

let text2 = "Hello 1 and 4 what 0-8 are 0 you 8 doing 3here?";
let rangeReg = /[1-7]/g;
//Here, - denotes a range; in this case, 1-7 denotes a match of all numbers from 1 to 7. 0 and 8 are out of the range, so they don't match. The result is [1,4,3]
//console.log(text2.match(rangeReg));
//[ '1', '4', '3' ]

//If I want to select all lower case characters in the text2
let lowerCaseChar = /[a-z]/g;
//console.log(text2.match(lowerCaseChar));
/*
Result:~:

 [
  'e', 'l', 'l', 'o', 'a', 'n',
  'd', 'w', 'h', 'a', 't', 'a',
  'r', 'e', 'y', 'o', 'u', 'd',
  'o', 'i', 'n', 'g', 'h', 'e',
  'r', 'e'
 ]

Here, the number and upper-case letter don't match.

//If I want to select all characters and numbers, then

let allCharNumber=/[0-8a-z]/gi
console.log(text2.match(allCharNumber))
*/

let allCharNumber = /[0-8a-z]/gi;
// Match 0 to 8 and a to z
//console.log(text2.match(allCharNumber));

//If I want to match only 0 and 8 and -
let match5 = /[0\-8]/g;
// The escape character \ indicates that it is not in the 0-8 range. It is individually 0, -, and 8.

//console.log(text2.match(match5));
//[ '0', '-', '8', '0', '8' ]

/**
 * @Negotion_not_match
 * @Carrot ^
 */

let myTxt = "abc of the abd and";
//I don't want to match a-c characters.
let negotionReg = /[^a-c]/g;

//console.log(myTxt.match(negotionReg));
/*
All of the characters are matched without a-c
  [
   ' ', 'o', 'f', ' ',
   't', 'h', 'e', ' ',
   'd', ' ', 'n', 'd'
  ]

*/

//If I don't want to match the b-d character and all spaces
let anotherNegoReg = /[^b-d\s]/g;

console.log(myTxt.match(anotherNegoReg));

/*
Now all characters are matched without b-d and spaces.

 [
  'a', 'o', 'f',
  't', 'h', 'e',
  'a', 'a', 'n'
 ]

*/
