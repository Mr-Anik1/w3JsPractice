/**
 * @Chracter_Set_ShortHand
 */
/**
 * 
   \d  => [0-9]
   \w  => [a-zA-Z0-9_]
   \s  => [ \t\r\n]

 */

let txt = "Bangladesh range is 1 lakh 47 thousand 570 square_kilometers";

let regNum = /\d/g;
//It selects all number and \d equvalient is [0-9]

//console.log(txt.match(regNum));
//[ '1', '4', '7', '5', '7', '0' ]

let regAllNumChar = /\w/g;
//It selects all character and number and \w equvaliant is [a-zA-Z0-9_]

//console.log(txt.match(regAllNumChar));
/*
Result:~: 

 [
  'B', 'a', 'n', 'g', 'l', 'a', 'd', 'e',
  's', 'h', 'r', 'a', 'n', 'g', 'e', 'i',
  's', '1', 'l', 'a', 'k', 'h', '4', '7',
  't', 'h', 'o', 'u', 's', 'a', 'n', 'd',
  '5', '7', '0', 's', 'q', 'u', 'a', 'r',
  'e', '_', 'k', 'i', 'l', 'o', 'm', 'e',
  't', 'e', 'r', 's'
]
*/

/**
 * @Negotion_Carrot_Symbol ^
 * 
    \D  => [^0-9]
    \W  => [^a-zA-Z0-9_]
    \S  => [^ \t\r\n]

 */

let neogNumReg = /\D/g;
//Match everything except the numbers

//console.log(txt.match(neogNumReg));

let negoCharReg = /\W/g;
//Match everything except the numbers,letter and underscore _

//console.log(txt.match(negoCharReg));

/**
 * @Exercise -2
 * 
   Using the provided array, create a second array that only includes the numbers with the 801 area code. (The area code is the first 3 numbers). Make sure that the phone numbers a valid (nnn-nnn-nnnn)
 * 
 */

let phoneNumbers = [
  "801-766-9786",
  "456-766-9786",
  "801-56-9877",
  "322-676-8016",
  "801-932-567",
  "456-789-8016",
  "801-789-231613",
  "456-676-9096",
  "801-421-120",
];

let only801 = (arr) => {
  let reg = /801-\d\d\d-\d\d\d\d$/;
  //let reg = /801-\d{3}-\d{4}$/;
  let nArr = arr.filter((v) => reg.test(v));
  return nArr;
};

console.log(only801(phoneNumbers));
//[ '801-766-9786' ]

/**
 * @Explain 
 * 
 * 
  Only valid phone numbers are matched.
  In this case \d\d\d means [0-9][0-9][0-9] => nnn
  More shorter=> let reg = /801-\d{3}-\d{4}$/;
 * 
  add a $ at the end of the pattern to ensure that there are no extra digits after the last group.
 * 
 * 
 */
