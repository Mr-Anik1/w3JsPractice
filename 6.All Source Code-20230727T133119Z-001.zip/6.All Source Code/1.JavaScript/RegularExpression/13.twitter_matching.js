//Twitter userHint must be @ in first of the string then \w means [a-zA-Z0-9_]

let userHint1 = "@hello_javascript";
let userHint2 = "@hello#javascript"; //# not allow
let userHint3 = "@@hello_javascript"; //twice time @ not allow
let userHint4 = "hello_javascript"; //@ doesn't exist

let twitReg = /^@(\w+)$/g;

console.log(twitReg.test(userHint1)); //true
console.log(twitReg.test(userHint2)); //false
console.log(twitReg.test(userHint3)); //false
console.log(twitReg.test(userHint4)); //false
