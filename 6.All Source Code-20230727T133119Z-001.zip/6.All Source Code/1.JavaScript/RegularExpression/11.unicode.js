/**
 * @Using_Unicode_in_Regular_Expression
 *
 * A => \u0041
 * a => \u0061
 *
 */

let str = "Hello my name is Anik what is your name?";
let unicodeReg = /\u0061/g;
console.log(str.match(unicodeReg));
//[ 'a', 'a', 'a' ]

let unicodeReg2 = /\u0041/g;
console.log(str.match(unicodeReg2));
//[ 'A' ]
