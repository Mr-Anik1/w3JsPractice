let str = "helloanik@domain.com";
let reg = /.+@.+\..+/g;
console.log(reg.test(str)); //true
// console.log(str.match(reg));

let reg2 = /^[^\s@]+@[^\s@.]+\.[^\s@.]+$/g;
console.log(reg2.test(str)); //true
/**
 
   [^\s@]+ => first it select everything without space \s and @ 

   @[^\s@.]+ => then it select @ sign and after select @ it will select everything without space(\s) , dot(.) and @ 
  
   \. => then it select dot .

   [^\s@]+ => after select dot(.) then it will select everything without space(\s) , dot(.) and @

 */
