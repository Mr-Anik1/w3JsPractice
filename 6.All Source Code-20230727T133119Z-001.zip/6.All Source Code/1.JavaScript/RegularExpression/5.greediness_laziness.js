let txt = `<p>This is the first paragraph tag.</p><p>Paragraph number two.</p>

<p>This is the first paragraph tag.</p><p>Paragraph number two.</p>`;

let greedyReg = /<p>.*<\/p>/;
//It is not stopping first ending paragraph, that is greediness

//console.log(txt.match(greedyReg));
//'<p>This is the first paragraph tag.</p><p>Paragraph number two.</p>'

let lazyReg = /<p>.*?<\/p>/;
//Now we are selecting only first paragraph not the whole, because ? mark after *

//console.log(txt.match(lazyReg));
//'<p>This is the first paragraph tag.</p>'

/**
 * @Specifying_Repitition_Amount
 * 
   {min,max} => Matches min to max occurrences
   {min} => Matches min occurrences
   {min,} => Matches min or more occurrences
 * 
 */

let txt2 = "My telephone number is as follows: 801-453-8963.";
let repReg = /\w{3,5}/g;

//console.log(txt2.match(repReg));
/**
 * @Result
 
   [
    'telep', 'hone',
    'numbe', 'follo',
    '801',   '453',
    '8963'
   ]

 */

let txt3 = "#ff0000 #C0C0C0 these are hex numbers";
let regHex = /#[0-9A-Z]{6}/g;

//console.log(txt3.match(regHex));
//[ '#C0C0C0' ]
