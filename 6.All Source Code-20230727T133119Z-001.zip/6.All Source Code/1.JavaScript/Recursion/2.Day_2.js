let lRec = (n) => {
  if (n < 1) {
    return;
  }
  //console.log(n);
  lRec(n - 1);
  console.log(n);
};
//lRec(5);

let fact = (n) => {
  if (n <= 1) {
    return 1;
  }
  return n * fact(n - 1);
};
//console.log(fact(5));

/**
 *
 * @General_Way
 *
 *
 */
let single = (n) => {
  let rem = 0;
  while (n != 0) {
    rem += n % 10;
    n = Math.floor(n / 10);
  }
  return rem;
};
//console.log(single(12345)); //15

/**
 *
 * @Recursive_Way
 * @Digit_add_of_a_Number
 *
 */
let addDigit = (num) => {
  if (num < 1) {
    return 0;
  }
  return (num % 10) + addDigit(Math.floor(num / 10));
};
//console.log(addDigit(12345)); //15

/**
 * @Reverse_Number
 *
 */
let revNum = 0;
let reverseNumber = (num) => {
  if (num == 0) {
    return;
  }
  let rem = num % 10;
  revNum = revNum * 10 + rem;
  reverseNumber(Math.floor(num / 10));
};
//reverseNumber(123456);
//console.log(revNum); //654321

/**
 * @Reverse_Number
 *
 */
let reverseNumber1 = (num, revNum = 0) => {
  if (num == 0) {
    return revNum;
  }
  let rem = num % 10;
  revNum = revNum * 10 + rem;
  return reverseNumber1(Math.floor(num / 10), revNum);
};
//console.log(reverseNumber1(14982));

/**
 * @Palindrome_Number_Check_with_Recursion
 *
 */
let plainD = (n) => {
  let myNum = n;
  let revN = 0;
  let revFunk = (num) => {
    if (num === 0) {
      return;
    }
    let rem = num % 10;
    revN = revN * 10 + rem;
    revFunk(Math.floor(num / 10));
  };
  revFunk(myNum);
  return myNum === revN
    ? `${myNum} is a palindrome Number`
    : `${myNum} is not a palindrome Number`;
};
//console.log(plainD(343)); //343 is a palindrome Number
//console.log(plainD(4567)); //4567 is not a palindrome Number

/**
 * @General_Way_to_Check_Palindrome_Number
 */
let plain = (n) => {
  let rev = String(n).split("").reverse().join("");
  return n === +rev
    ? `${n} is a palindrome Number`
    : `${n} is not a palindrome Number`;
};
//console.log(plain(2002)); //2002 is a palindrome Number
//console.log(plain(2034)); //2034 is not a palindrome Number

/**
 * @General_Way_Check_Zero
 *
 */
let countZero = (num) => {
  let z = 0;
  let nStr = String(num);
  for (let i = 0; i <= nStr.length - 1; i++) {
    if (nStr[i] == 0) {
      z += 1;
    }
  }
  return z;
};
//console.log(countZero(120450607080)); //5

/**
 * @Check_Zero_with_Recursion_Way
 *
 */
let zeroCheck = (n) => {
  let z = 0;
  let checkFunk = (num) => {
    if (num < 1) {
      return;
    }
    if (num % 10 == 0) {
      z += 1;
    }
    checkFunk(Math.floor(num / 10));
  };
  checkFunk(n);
  return z;
};
//console.log(zeroCheck(10204)); //2

/**
 * @OR
 */
let checkFunk = (num, z = 0) => {
  if (num < 1) {
    return z;
  }
  if (num % 10 == 0) {
    z += 1;
  }
  return checkFunk(Math.floor(num / 10), z);
};
//console.log(checkFunk(102030)); //3

/**
 * 
 * @Number_of_Steps_to_Reduce_a_Number_to_Zero
 * @LeetCode_Problem_No_1342
 * 
 Given an integer num, return the number of steps to reduce it to zero.
 In one step, if the current number is even, you have to divide it by 2, otherwise, you have to subtract 1 from it.
 *  
 */
let numberOfSteps = (num, step = 0) => {
  if (num < 1) {
    return step;
  }
  if (num % 2 == 0) {
    return numberOfSteps(num / 2, (step += 1));
  } else if (num % 2 != 0) {
    return numberOfSteps(num - 1, (step += 1));
  }
};
//console.log(numberOfSteps(14)); //6
//console.log(numberOfSteps(8)); //4
//console.log(numberOfSteps(123)); //12
/*
Input: num = 14
Output: 6
Explanation: 
Step 1) 14 is even; divide by 2 and obtain 7. 
Step 2) 7 is odd; subtract 1 and obtain 6.
Step 3) 6 is even; divide by 2 and obtain 3. 
Step 4) 3 is odd; subtract 1 and obtain 2. 
Step 5) 2 is even; divide by 2 and obtain 1. 
Step 6) 1 is odd; subtract 1 and obtain 0.
*/
