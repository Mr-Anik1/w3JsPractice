/**
 * @How_Understand_and_approch_a_problem
 *
 * Identify if you can break down problem into smaller problems
 *
 * Write the recurrence relation if needed
 *
 * Draw the recursive_tree
 *
 * About the tree
 */

let funk = (i) => {
  if (i > 5) {
    return;
  }
  console.log(`${i}.Hello Anik`);
  return funk(i + 1);
};
// funk(1);

/**
 * @Fibonacci_Number_in_General_Way
 *
 */
let helloFibo = (num, arr = [0, 1]) => {
  while (num > 2) {
    let [previousLast, last] = arr.slice(-2);
    arr.push(previousLast + last);
    num -= 1;
  }
  return arr;
};
//console.log(helloFibo(10));

/**
 * @Fibonacci_Number_in_Recursion_Way
 *
 */

let fiboSequence = (num, arr = [0, 1]) => {
  if (num <= 2) {
    return arr;
  }
  let [nextToLast, last] = arr.slice(-2);
  return fiboSequence(num - 1, [...arr, nextToLast + last]);
};
// console.log(fiboSequence(8));

/**
 * @Position_of_Fibonacci_Number_in_Recursion_Way
 *
 */

let checkFibo = (num) => {
  if (num < 2) {
    return num;
  }
  return checkFibo(num - 1) + checkFibo(num - 2);
};

//console.log(checkFibo(4)); //3

/**
 * @Recursion__Tree
 
                            1
         ----------------fib(4)=3---------
      2/                                  \7
      fib(3)=2------          +          fib(2)=1---
   3/               \6                    |8        \9
   fib(2)=1---   +  fib(1)=1          fib(1)=1  +  fib(0)=0
  4/          \5
 fib(1)=1  +  fib(0)=0


 *@Good
 * 1:18 min
 */

/**
 * @Binary_Search_Useing_Recursion
 *
 */

let biSearch = (arr, target, s = 0, e = arr.length - 1) => {
  let m = Math.floor(s + (e - s) / 2);
  if (s > e) {
    return -1;
  }
  if (arr[m] === target) {
    return m;
  }

  if (target < arr[m]) {
    return biSearch(arr, target, s, (e = m - 1));
  }
  return biSearch(arr, target, (s = m + 1), e);
};
let arr = [1, 2, 3, 4, 5, 6, 7, 8];
// console.log(biSearch(arr, 7)); //6

/**
 * @step_1
   tarrget=7 s=0 & e=7 
   m=0+(7-0)/2=0+3.5=3.5~3
   m=3
   biSearch(tarrget=7 s=m+1=3+1=4 & e=7 )
 * 
 * 
 * @step_2
   tarrget=7 s=4 & e=7
   m=4+(7-4)/2=4+1.5=5.5~5
   m=5
   biSearch(tarrget=7 s=m+1=5+1=6 & e=7 )
 * 
 * 
 * @step_3
   tarrget=7 s=6 & e=7
   m=6+(7-6)/2=6+0.5=6.5~6
   m=6

   arr[m] === target
   arr[6] === 7
   7===7 
   return m ~ return 6

   Result=6
 * 
 * 
 * 
 */

/**
 * @Another_Example
 *
 * @Prvious_e
 * "e" will automatically get the previous value.
 *
 */
let binarySearch = (arr, target, s = 0, e = arr.length - 1) => {
  let m = Math.floor(s + (e - s) / 2);
  if (s > e) {
    return -1;
  }
  if (arr[m] === target) {
    return m;
  }
  if (target < arr[m]) {
    return binarySearch(arr, target, s, (e = m - 1));
  }
  return binarySearch(arr, target, (s = m + 1), e);
};
let arr1 = [1, 2, 3, 4, 5, 6, 7];
//console.log(binarySearch(arr1, 3)); //2

/**
 * 
 * @step_1
   target=3, s=0, e=6
   m=0+(6-0)/2=3
   binarySearch(arr, target, s, (e=m-1=3-1=2))
 * 
 * 
 * @step_2
   target=3, s=0, e=2
   m=0+(2-0)/2=1
   binarySearch(arr, target, (s=m+1=1+1=2), e);
 * 
 * 
 * @step_3
   target=3, s=2, e=2 //"e" will automatically get the previous value.
   m=2+(2-2)/2=2+0=2
  
   arr[m] === target
   arr[2] === 3
   3 === 3
   return m ~ return 2
  
   Result:2
 * 
 */
