/**
 *
 * @Best_Case
 * Quick Sort implementation with Hoare partition scheme
 * https://www.guru99.com/quicksort-in-javascript.html
 *
 */

// Helper Function swap
function swap(items, leftIndex, rightIndex) {
  let temp = items[leftIndex];
  items[leftIndex] = items[rightIndex];
  items[rightIndex] = temp;
}

// Helper Function partition
function partition(items, left, right) {
  let pivot = items[Math.floor((right + left) / 2)]; //middle element
  let i = left; //left pointer
  let j = right; //right pointer
  while (i <= j) {
    while (items[i] < pivot) {
      i++;
    }
    while (items[j] > pivot) {
      j--;
    }
    if (i <= j) {
      swap(items, i, j); //sawpping two elements
      i++;
      j--;
    }
  }
  return i;
}

//Final Function
function quickSort(items, left = 0, right = items.length - 1) {
  let index;
  if (items.length > 1) {
    index = partition(items, left, right); //index returned from partition
    if (left < index - 1) {
      //more elements on the left side of the pivot
      quickSort(items, left, index - 1);
    }
    if (index < right) {
      //more elements on the right side of the pivot
      quickSort(items, index, right);
    }
  }
  return items;
}

// Final Testing
let testArr = [5, 0, 2, 9, -1];
//console.log(quickSort(testArr)); //[ -1, 0, 2, 5, 9 ]

/**
 * @Code_2
 * Lomuto partition scheme
 */
function quickSort2(arr) {
  if (arr.length <= 1) {
    return arr;
  }

  const pivot = arr[Math.floor(arr.length / 2)];
  const less = [];
  const equal = [];
  const greater = [];

  for (let element of arr) {
    if (element < pivot) {
      less.push(element);
    } else if (element === pivot) {
      equal.push(element);
    } else {
      greater.push(element);
    }
  }

  return [...quickSort2(less), ...equal, ...quickSort2(greater)];
}

/**
 * @Code_3
 * Lomuto partition scheme
 */
let quickSort3 = (arr) => {
  if (arr.length <= 1) {
    return arr;
  }

  let pivot = arr[arr.length - 1];
  let leftArr = [];
  let rightArr = [];

  //   for (let el of arr.slice(0, arr.length - 1)) {
  //     el < pivot ? leftArr.push(el) : rightArr.push(el);
  //   }

  for (let i = 0; i < arr.length - 1; i++) {
    if (arr[i] < pivot) {
      leftArr.push(arr[i]);
    } else {
      rightArr.push(arr[i]);
    }
  }

  if (leftArr.length > 0 && rightArr.length > 0) {
    return [...quickSort3(leftArr), pivot, ...quickSort3(rightArr)];
  } else if (leftArr.length > 0) {
    return [...quickSort3(leftArr), pivot];
  } else {
    return [pivot, ...quickSort3(rightArr)];
  }
};

/**
 * @Code_4
 * Udemy Instructor
 */
function swap2(array, firstIndex, secondIndex) {
  let temp = array[firstIndex];
  array[firstIndex] = array[secondIndex];
  array[secondIndex] = temp;
}

function pivot(array, pivotIndex = 0, endIndex = array.length - 1) {
  let swapIndex = pivotIndex;
  for (let i = pivotIndex + 1; i <= endIndex; i++) {
    if (array[i] < array[pivotIndex]) {
      swapIndex++;
      swap2(array, swapIndex, i);
    }
  }
  swap2(array, pivotIndex, swapIndex);

  return swapIndex;
}

function quickSort4(array, left = 0, right = array.length - 1) {
  if (left >= right) return;

  let pivotIndex = pivot(array, left, right);
  quickSort4(array, left, pivotIndex - 1);
  quickSort4(array, pivotIndex + 1, right);
}
