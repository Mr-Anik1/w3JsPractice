let arr1 = [1, 2, 3, 4, 5, 9, 7, 6, 7, 9];
let arr2 = [1, 2, 3, 4, 5, 6];

/**
 *@Find_if_Array_sorted_or_not
 *@Recursion_Way
  This is good one
 */
let bestRecSort = (arr, i = 0) => {
  if (i == arr.length - 1) {
    return true;
  }
  return arr[i] < arr[i + 1] && bestRecSort(arr, (i += 1));
};
// console.log(bestRecSort(arr1)); //false
// console.log(bestRecSort(arr2)); //true

/**
 *@Find_if_Array_sorted_or_not
 *@General_Way
 */

let checkSort = (arr) => {
  for (let i = 0; i < arr.length - 1; i++) {
    if (arr[i] > arr[i + 1]) {
      return `Array is not sorted`;
    }
  }
  return `Array is sorted`;
};
// console.log(checkSort(arr1)); //Array is not sorted
// console.log(checkSort(arr2)); //Array is sorted

/**
 *@Find_if_Array_sorted_or_not
 *
 */
let sortRec = (arr, i = 0) => {
  if (arr[i] < arr[i + 1]) {
    return sortRec(arr, (i += 1));
  }
  if (arr[i] > arr[i + 1]) {
    return `Array is not sorted`;
  }
  return `Array is sorted`;
};
// console.log(sortRec(arr1));
// console.log(sortRec(arr2));

/**
 * @Find_an_Array_Element_using_Recursion
 *
 */
let arr3 = [10, 2, 37, 4, 53, 6];
let findArrItem = (arr, target, i = 0) => {
  if (i == arr.length) {
    return false;
  }
  return arr[i] == target || findArrItem(arr, target, (i += 1));
};
// console.log(findArrItem(arr3, 60)); //False
// console.log(findArrItem(arr3, 6)); //True
/**
 * @OR
 *
 */
let findA = (arr, target, i = 0) => {
  if (i == arr.length) {
    return `${target} is Not Found in this Array`;
  }
  if (arr[i] == target) {
    return `${target} is found in index ${i} `;
  }
  return findA(arr, target, (i += 1));
};
//console.log(findA(arr3, 6)); //6 is found in index 5

/**
 * @Find_Similar_Item_Indexes
 */
let testArr = [1, 2, 3, 4, 2, 3, 4, 4, 5, 6, 7, 3];
let allIndex = (arr, tar, nArr = [], i = 0) => {
  if (i == arr.length) {
    return nArr;
  }
  if (arr[i] == tar) {
    nArr.push(i);
  }
  // return allIndex(arr, tar, [...nArr], (i += 1));
  return allIndex(arr, tar, nArr, (i += 1));
};
//console.log(allIndex(testArr, 3)); //[ 2, 5, 11 ]
/*
Target element 3 is present in this array at indexes 2, 5, and 11.
*/

/**
 * @Important
 * @Input_Unsorted_Array_And_Find_Element
 */
let unSortArray = [
  1, 4, 5, 10, 14, 0, 93, 8, 16, 2, 9, 3, 6, 1000, 601, 401, 402, 608, 77, 78,
  89, 34, 79, 123, 456, 98, 96,
];
let sortAndFind = (arr, tar) => {
  //Sort
  let nArr = [...arr];
  for (let i = 0; i < nArr.length; i++) {
    for (j = 0; j < nArr.length; j++) {
      if (nArr[j] > nArr[j + 1]) {
        [nArr[j], nArr[j + 1]] = [nArr[j + 1], nArr[j]]; //swap
      }
    }
  }

  //Binary Search
  let binar = (nArr, tar, s = 0, e = nArr.length - 1) => {
    let m = Math.floor(s + (e - s) / 2);
    if (s > e) {
      return `${tar} is not found `;
    }
    if (tar == nArr[m]) {
      return `${tar} is found`;
    }
    if (tar < nArr[m]) {
      return binar(nArr, tar, s, (e = m - 1));
    }
    return binar(nArr, tar, (s = m + 1), e);
  };
  return binar(nArr, tar);
};
// console.log(sortAndFind(unSortArray, 200)); //200 is not found
// console.log(sortAndFind(unSortArray, 3)); //3 is found
// console.log(sortAndFind(unSortArray, 77)); //77 is found:=>Right Answer
// console.log(sortAndFind(unSortArray, 456)); //456 is found:=>Right Answer
// console.log(sortAndFind(unSortArray, 96)); //96 is found:=>Right Answer
// console.log(sortAndFind(unSortArray, 420)); //420 is not found:=>Right Answer

/**
 *
 * @Wrong_Way
 * @I_do_not_understand_the_last_part_so_I_solve_this_problem_above_way
 *
 * 1:04 min to last this day-3 video
 *
 * @Its_provide_wrong_answer so I will not use this in future
 */

/**
 *
 * @Hard_to_understand
 * Little bit Hard
 */
let unSortArray2 = [
  1, 4, 5, 10, 14, 0, 93, 8, 16, 2, 9, 3, 6, 1000, 601, 401, 402, 608, 77, 78,
  89, 34, 79, 123, 456, 98, 96,
];
let badSearch = (arr, tar, s = 0, e = arr.length - 1) => {
  let m = Math.floor(s + (e - s) / 2);
  if (s > e) {
    return `${tar} is not found`;
  }
  if (arr[m] == tar) {
    return `${tar} is found `;
  }

  if (arr[s] <= arr[m]) {
    if (tar >= arr[s] && tar <= arr[m]) {
      return badSearch(arr, tar, s, (e = m - 1));
    } else {
      return badSearch(arr, tar, (s = m + 1), e);
    }
  }

  if (tar >= arr[m] && tar <= arr[e]) {
    return badSearch(arr, tar, (s = m + 1), e);
  }
  return badSearch(arr, tar, s, (e = m - 1));
};
// console.log(badSearch(unSortArray2, 1000)); //1000 is found:=>Right Answer
// console.log(badSearch(unSortArray2, 102)); //102 is not found:=>Right Answer
// console.log(badSearch(unSortArray2, 14)); //14 is found:=>Right Answer
// /**
//  * @But_Wrong
//  */
// console.log(badSearch(unSortArray2, 77)); //77 is not found:=>Wrong Answer
// console.log(badSearch(unSortArray2, 456)); //456 is not found:=>Wrong Answer
// console.log(badSearch(unSortArray2, 96)); //96 is not found:=>Wrong Answer
