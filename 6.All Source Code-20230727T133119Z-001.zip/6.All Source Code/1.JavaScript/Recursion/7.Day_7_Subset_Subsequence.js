let str = "baccad";

function recursiveFunk(strArr, i = 0) {
  if (i < strArr.length) {
    if (strArr[i] === "a") strArr[i] = "";
    i++;
    recursiveFunk(strArr, i);
  }
  return strArr.join("");
}

function removeA(str) {
  let strArr = str.split("");
  return recursiveFunk(strArr);
}

//console.log(removeA(str));

/**
 * @Best_Way
 */
function skip(str) {
  if (str.length === 0) {
    return "";
  }
  let ch = str[0];
  if (ch === "a") {
    return skip(str.substring(1));
  } else {
    return ch + skip(str.substring(1));
  }
}
//console.log(skip(str)); //bccd

/**
 * @Skip_Word
 */
function skipApple(str) {
  if (str.length === 0) {
    return "";
  }

  if (str.startsWith("apple")) {
    return skipApple(str.substring(5));
  } else {
    return str[0] + skipApple(str.substring(1));
  }
}
//console.log(skipApple("AnikappleVai")); //AnikVai

/**
 * @StartsWith_app_but_not_appple
 */
function skipAppNotApple(str) {
  if (str.length === 0) {
    return "";
  }

  if (str.startsWith("app") && !str.startsWith("apple")) {
    return skipAppNotApple(str.substring(3));
  } else {
    return str[0] + skipAppNotApple(str.substring(1));
  }
}
//console.log(skipAppNotApple("AlgoappButNotappleapp")); //AlgoButNotapple

//-------------////------------////-----------////----------//

/**
 * @Subset_Recursive_Tree
 * t ~ take it
 * i ~ ignore it
 * Date: 9 July 2023 ~ 1:40 AM 
 * 
 

               ------------------(""/abc)---------------
            t/                                          \i
          ("a"/bc)-----                              (""/"bc")---
        t/             \i                            t/          \i   
      ("ab"/c)         ("a"/c)------               ("b"/c)    (""/c)----
    t/       \i          t/         \i           t/     \i      t/      \i
("abc"/"")  ("ab"/"")  ("ac"/"")  ("a"/"") ("bc"/"") ("b"/"") ("c"/"") (""/"")


 * 
 */

/**
 *@Implemantation_Subset
 */
let arr = [];
function subsetFunk(p = "", un) {
  if (un.length === 0) {
    return arr.push(p);
  }

  return (
    subsetFunk(un[0] + p, un.substring(1)) + subsetFunk(p, un.substring(1))
  );
}
subsetFunk("", "abc");
//console.log(arr);
//[ 'cba', 'ba', 'ca', 'a', 'cb', 'b', 'c', '' ]

/**
 * @Subset_Implemantation
 * @Another_Way_Retrun_Array
 */
function arrayList(p = "", un) {
  if (un.length === 0) {
    return new Array(p);
  }

  let left = arrayList(un[0] + p, un.substring(1));
  let right = arrayList(p, un.substring(1));

  return left.concat(right);
}
//console.log(arrayList("", "abc"));
//[ 'cba', 'ba', 'ca', 'a', 'cb', 'b', 'c', '' ]
