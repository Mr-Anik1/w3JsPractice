/**
 * @Merge_Sort
 *
 */

//Helper Function
let merge = (leftArr, rightArr) => {
  let outPut = [];
  let leftIndex = 0;
  let rightIndex = 0;

  while (leftIndex < leftArr.length && rightIndex < rightArr.length) {
    let leftEl = leftArr[leftIndex];
    let rightEl = rightArr[rightIndex];

    if (leftEl < rightEl) {
      outPut.push(leftEl);
      leftIndex++;
    } else {
      outPut.push(rightEl);
      rightIndex++;
    }
  }
  return [
    ...outPut,
    ...leftArr.slice(leftIndex),
    ...rightArr.slice(rightIndex),
  ];
};

//Recursion
let mergeSort = (arr) => {
  if (arr.length <= 1) {
    return arr;
  }

  let middleIndex = Math.floor(arr.length / 2);
  let leftArr = arr.slice(0, middleIndex);
  let rightArr = arr.slice(middleIndex);

  return merge(mergeSort(leftArr), mergeSort(rightArr));
};

let unSort = [5, 21, 1, 3, 100, -1, 6, 45, 7, 56, 2, 8, 99, 4];
//console.log(mergeSort(unSort));

/**
 *
 * @Another_Way
 *
 */

//Helper Function
let mergeHelper = (leftArr, rightArr) => {
  let res = [];

  let i = 0; //leftArr index
  let j = 0; //rightArr index
  let k = 0; //res index

  while (i < leftArr.length && j < rightArr.length) {
    if (leftArr[i] < rightArr[j]) {
      res[k] = leftArr[i];
      k++;
      i++;
    } else {
      res[k] = rightArr[j];
      k++;
      j++;
    }
  }

  //If one Array is not complete
  while (i < leftArr.length) {
    res[k] = leftArr[i];
    k++;
    i++;
  }

  //If another one not complete
  while (j < rightArr.length) {
    res[k] = rightArr[j];
    k++;
    j++;
  }

  return res;
};

//Recursive
let anotherMerge = (arr) => {
  if (arr.length <= 1) {
    return arr;
  }
  let mid = Math.floor(arr.length / 2);
  let leftArr = arr.slice(0, mid);
  let rightArr = arr.slice(mid);

  return mergeHelper(anotherMerge(leftArr), anotherMerge(rightArr));
};

let hotArr = [89, 0, 420, 3, 100, -1, 45, 7, -3, 56, 2, 8, 45, 4];
// console.log(anotherMerge(hotArr));
// console.log(anotherMerge(unSort));
