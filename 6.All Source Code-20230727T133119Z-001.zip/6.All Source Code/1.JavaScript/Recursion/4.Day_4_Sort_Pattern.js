/**
 *
 * @Pattern_General_way
 *
 */
let pattFunk = (num) => {
  let pattrn = "";
  for (let row = 1; row <= num; row++) {
    for (let col = 1; col <= row; col++) {
      pattrn += `${col}`;
    }
    pattrn += "\n";
  }

  for (let row = num - 1; row >= 1; row--) {
    for (let col = 1; col <= row; col++) {
      pattrn += `${col}`;
    }
    pattrn += "\n";
  }
  return pattrn;
};
//console.log(pattFunk(5));

/**
 *
 * @Pattern_Recursion_Way
 *
 */
let recPatt = (row, col = 0, pat = "") => {
  if (row < 1) {
    return pat;
  }
  if (col < row) {
    return recPatt(row, (col += 1), (pat += "*"));
  }
  pat += "\n";
  return recPatt(row - 1, (col = 0), pat);
};
// console.log(recPatt(5));

let recPatt2 = (num, row = 1, col = 0, pat = "") => {
  if (row > num) {
    return pat;
  }
  if (col < row) {
    return recPatt2(num, row, (col += 1), (pat += "*"));
  }
  pat += "\n";
  return recPatt2(num, (row += 1), (col = 0), pat);
};
// console.log(recPatt2(5));

/**
 * @Babble_Sort_With_Recursion
 *
 */
let bubbleSort = (arr, i = 0, j = 0) => {
  //Base Condition
  if (i >= arr.length) {
    return arr;
  }
  //Sub Base Condition
  if (j < arr.length) {
    if (arr[j] > arr[j + 1]) {
      [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
      return bubbleSort(arr, i, (j += 1));
    } else {
      return bubbleSort(arr, i, (j += 1));
    }
  }
  return bubbleSort(arr, (i += 1), (j = 0));
};
let myArr = [1, 4, 78, 8, 3, 45, 2, 100, 89, 9, 12, 7, 50, 10, 5, 23, 6];
//console.log(bubbleSort(myArr));
//[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 23, 45, 50, 78, 89, 100]

/**
 * @Selection_Sort_With_Recursion
 *
 */
let selectionSort = (arr, i = 0, j = i + 1, lowest = i) => {
  if (i >= arr.length) {
    //Base Condition
    return arr;
  }
  if (j < arr.length) {
    //Sub Base Condition
    if (arr[lowest] > arr[j]) {
      lowest = j;
      return selectionSort(arr, i, (j += 1), lowest);
    } else {
      return selectionSort(arr, i, (j += 1), lowest);
    }
  }
  //swap
  [arr[i], arr[lowest]] = [arr[lowest], arr[i]];
  return selectionSort(arr, (i += 1), (j = i + 1), (lowest = i));
};
let unSort = [
  1, 4, 5, 10, 14, 0, -93, 8, 16, 2, 9, 3, 6, -1000, 601, 401, 402, 608, 77, 78,
  89, 34, -79, 123, 456, -98, 96,
];
//console.log(selectionSort(unSort));
//[-1000, -98, -93, -79, 0, 1, 2, 3, 4, 5, 6, 8, 9, 10, 14, 16, 34, 77, 78, 89, 96, 123, 401, 402, 456, 601, 608]

/**
 * @Selection_Sort_General_Way
 *
 */
let genSelectionSort = (arr) => {
  for (let i = 0; i < arr.length; i++) {
    let lowest = i;
    for (let j = i + 1; j < arr.length; j++) {
      if (arr[lowest] > arr[j]) {
        lowest = j;
      }
    }
    //Swap
    [arr[i], arr[lowest]] = [arr[lowest], arr[i]];
  }
  return arr;
};
let arr = [
  1, 4, 5, 10, 14, 0, -93, 8, 16, 2, 9, 3, 6, -1000, 601, 401, 402, 608, 77, 78,
  89, 34, -79, 123, 456, -98, 96,
];
//console.log(genSelectionSort(arr));
