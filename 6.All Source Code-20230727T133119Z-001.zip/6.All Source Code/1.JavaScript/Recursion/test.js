let fiboSequence = (num, arr = [0, 1]) => {
  if (num <= 2) {
    return arr;
  }
  let [previousLast, last] = arr.slice(-2);
  return fiboSequence(num - 1, [...arr, previousLast + last]);
};
//console.log(fiboSequence(10));

let fiboCheck = (num) => {
  if (num < 2) {
    return num;
  }
  return fiboCheck(num - 1) + fiboCheck(num - 2);
};
//console.log(fiboCheck(6));

let binarySearch = (arr, targetValue, start = 0, end = arr.length - 1) => {
  let middle = Math.floor(start + (end - start) / 2);
  if (start > end) {
    return `${targetValue} not found in the database`;
  }
  if (targetValue === arr[middle]) {
    return middle;
  }
  if (targetValue < arr[middle]) {
    return binarySearch(arr, targetValue, start, (end = middle - 1));
  }
  return binarySearch(arr, targetValue, (start = middle + 1), end);
};
let arra = [1, 2, 3, 4, 5, 6, 72, 84, 99];
//console.log(binarySearch(arra, 21));

let bin = (arra, tar, s = 0, e = arra.length) => {
  let m = Math.floor(s + (e - s) / 2);
  if (s > e) {
    return `Item is not found in the database`;
  }
  if (tar === arra[m]) {
    return m;
  }
  if (tar < arra[m]) {
    return bin(arra, tar, s, (e = m - 1));
  }
  return bin(arra, tar, (s = m + 1), e);
};
let myArra = [1, 2, 3, 4, 5, 6, 7, 8, 9];
//console.log(bin(myArra, 3));

let plain = (n) => {
  let rev = String(n).split("").reverse().join("");
  return n === +rev ? `${n} is a PlainDrome` : `${n} is not a PlainDrome`;
};
// console.log(plain(343));
// console.log(plain(4567));

let reverseNumber1 = (num, revNum = 0) => {
  if (num == 0) {
    return revNum;
  }
  let rem = num % 10;
  revNum = revNum * 10 + rem;
  return reverseNumber1(Math.floor(num / 10), revNum);
};
//console.log(reverseNumber1(14982));

let arr1 = [1, 2, 3, 5, 2];
let sortRec = (arr, i = 0) => {
  if (arr[i] < arr[i + 1]) {
    return sortRec(arr, (i += 1));
  }
  if (arr[i] > arr[i + 1]) {
    return `Array is not sorted`;
  }
  return `Array is sorted`;
};
//console.log(sortRec(arr1));
let arr3 = [10, 2, 37, 4, 53, 6, 9];
let findA = (arr, target, i = 0) => {
  if (i == arr.length) {
    return `${target} is Not Found in this Array`;
  }
  if (arr[i] == target) {
    return `${target} is found in index ${i} `;
  }
  return findA(arr, target, (i += 1));
};
//console.log(findA(arr3, 9));

let testArr = [1, 3, 4, 3, 2, 3];
let allIndex = (arr, tar, nArr = [], i = 0) => {
  if (i == arr.length) {
    return nArr;
  }
  if (arr[i] == tar) {
    nArr.push(i);
  }
  return allIndex(arr, tar, [...nArr], (i += 1));
  //return allIndex(arr, tar, [...nArr], (i += 1));//same
};
//console.log(allIndex(testArr, 3)); //[ 1, 4 ]

/**
 * @Sort_WoW
 */
let unSortArray = [
  1, 4, 5, 10, 14, 0, 93, 8, 16, 2, 9, 3, 6, 1000, 601, 401, 402, 608, 77, 89,
  34, 79, 123, 456, 98, 96,
];
//let unSortArray = [1, 4, 5, 10, 0, 93, 8, 2, 9, 3, 6];
let sortAndFind = (arr, tar) => {
  //Sort
  let nArr = [...arr];
  for (let i = 0; i < nArr.length; i++) {
    for (j = 0; j < nArr.length; j++) {
      if (nArr[j] > nArr[j + 1]) {
        [nArr[j], nArr[j + 1]] = [nArr[j + 1], nArr[j]];
      }
    }
  }

  //Binary Search
  let binar = (nArr, tar, s = 0, e = nArr.length - 1) => {
    let m = Math.floor(s + (e - s) / 2);
    if (s > e) {
      return `${tar} is not found `;
    }
    if (tar == nArr[m]) {
      return `${tar} is found`;
    }
    if (tar < nArr[m]) {
      return binar(nArr, tar, s, (e = m - 1));
    }
    return binar(nArr, tar, (s = m + 1), e);
  };
  return binar(nArr, tar);
};
// console.log(sortAndFind(unSortArray, 200)); //200 is not found
//console.log(sortAndFind(unSortArray, 77)); //Right Answer

/**
 *
 * @Wrong_way
 * Little bit Hard
 */
let unSortArray2 = [
  1, 4, 5, 10, 14, 0, 93, 8, 16, 2, 9, 3, 6, 1000, 601, 401, 402, 608, 77, 78,
  89, 34, 79, 123, 456, 98, 96,
];
let goodSearch = (arr, tar, s = 0, e = arr.length - 1) => {
  let m = Math.floor(s + (e - s) / 2);
  if (s > e) {
    return `${tar} is not found`;
  }
  if (arr[m] == tar) {
    return `${tar} is found `;
  }

  if (arr[s] <= arr[m]) {
    if (tar >= arr[s] && tar <= arr[m]) {
      return goodSearch(arr, tar, s, (e = m - 1));
    } else {
      return goodSearch(arr, tar, (s = m + 1), e);
    }
  }

  if (tar >= arr[m] && tar <= arr[e]) {
    return goodSearch(arr, tar, (s = m + 1), e);
  }
  return goodSearch(arr, tar, s, (e = m - 1));
};
// console.log(goodSearch(unSortArray2, 98)); //98 is not found:=>Wrong Answer
// console.log(goodSearch(unSortArray2, 93)); //93 is found:=>Right Answer

/**
 *
 * @Pattern
 *
 */
let pattFunk = (num) => {
  let pattrn = "";
  for (let row = 1; row <= num; row++) {
    for (let col = 1; col <= row; col++) {
      pattrn += `${col}`;
    }
    pattrn += "\n";
  }

  for (let row = num - 1; row >= 1; row--) {
    for (let col = 1; col <= row; col++) {
      pattrn += `${col}`;
    }
    pattrn += "\n";
  }
  return pattrn;
};
//console.log(pattFunk(5));

//Greater to less
let recPattern = (r, c = 0, pattern = "") => {
  if (r < 1) {
    return pattern;
  }
  if (c < r) {
    return recPattern(r, (c += 1), (pattern += "*"));
  }
  pattern += "\n";
  return recPattern(r - 1, (c = 0), pattern);
};
// console.log(recPattern(5));

//less to grater
let patRec = (n, r = 1, c = 0, pattern = "") => {
  if (r > n) {
    return pattern;
  }
  if (c < r) {
    return patRec(n, r, (c += 1), (pattern += "*"));
  }
  pattern += "\n";
  return patRec(n, (r += 1), (c = 0), pattern);
};
// console.log(patRec(5));

/**
 * @Babble
 *
 */
let nSort = (arr, i = 0, j = 0) => {
  //Base Condition
  if (i >= arr.length) {
    return arr;
  }
  //Sub Base Condition
  if (j < arr.length) {
    if (arr[j] > arr[j + 1]) {
      [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
      return nSort(arr, i, (j += 1));
    } else {
      return nSort(arr, i, (j += 1));
    }
  }
  return nSort(arr, (i += 1), (j = 0));
};
// let myArr = [1, 345, 14];
// let newArr = new Set(nSort(myArr));
//console.log(nSort(myArr));

let myArr = [
  1, 4, 5, 10, 14, 0, -93, 8, 16, 2, 9, 3, 6, -1000, 601, 401, 402, 608, 77, 78,
  89, 34, -79, 123, 456, -98, 96,
];
//console.log(nSort(myArr));

/**
 * @Selection
 */
let selectionSort = (arr) => {
  for (let i = 0; i < arr.length; i++) {
    let lowest = i;
    for (let j = i + 1; j < arr.length; j++) {
      if (arr[lowest] > arr[j]) {
        lowest = j;
      }
    }
    // //Best Way
    // if (i != lowest) {
    //   //Swap
    //   [arr[i], arr[lowest]] = [arr[lowest], arr[i]];
    // }
    [arr[i], arr[lowest]] = [arr[lowest], arr[i]];
  }
  return arr;
};
let arr = [3, -1, 1, 0];
//console.log(selectionSort(arr));

let recSelection = (arr, i = 0, j = i + 1, lowest = i) => {
  if (i >= arr.length) {
    return arr;
  }
  if (j < arr.length) {
    if (arr[lowest] > arr[j]) {
      lowest = j;
      return recSelection(arr, i, (j += 1), lowest);
    } else {
      return recSelection(arr, i, (j += 1), lowest);
    }
  }
  //swap
  [arr[i], arr[lowest]] = [arr[lowest], arr[i]];
  return recSelection(arr, (i += 1), (j = i + 1), (lowest = i));
};
let ohArr = [1, 4, 5, 0, 8, 9, 34, 12, -8, 43, 2];
//console.log(recSelection(ohArr));

let mySort = (arr) => {
  for (let i = 0; i < arr.length; i++) {
    let lowest = i;
    for (let j = i + 1; j < arr.length; j++) {
      if (arr[lowest] > arr[j]) {
        lowest = j;
      }
    }
    [arr[i], arr[lowest]] = [arr[lowest], arr[i]];
  }
  return arr;
};
//console.log(mySort(ohArr));

let goodSort = (arr, i = 0, j = i + 1, lowest = i) => {
  //base condition
  if (i >= arr.length) {
    return arr;
  }
  //sub base condition
  if (j < arr.length) {
    if (arr[lowest] > arr[j]) {
      //set lowest value
      lowest = j;
      //increase j
      return goodSort(arr, i, (j += 1), lowest);
    } else {
      //increase j
      return goodSort(arr, i, (j += 1), lowest);
    }
  }
  //Swap
  [arr[i], arr[lowest]] = [arr[lowest], arr[i]];
  //increase i
  return goodSort(arr, (i += 1), (j = i + 1), (lowest = i));
};
let moRa = [12, 8, 0, 12, -1];
//console.log(goodSort(moRa)); //[ -1, 0, 8, 12, 12 ]

/**
 * @Merge_Sort
 */

//Helper Function
let merge = (leftArr, rightArr) => {
  let res = [];
  let leftIndex = 0;
  let rightIndex = 0;

  while (leftIndex < leftArr.length && rightIndex < rightArr.length) {
    let leftEl = leftArr[leftIndex];
    let rightEl = rightArr[rightIndex];

    if (leftEl < rightEl) {
      res.push(leftEl);
      leftIndex++;
    } else {
      res.push(rightEl);
      rightIndex++;
    }
  }

  return [...res, ...leftArr.slice(leftIndex), ...rightArr.slice(rightIndex)];
};

//Recursive
let mergeSort = (arr) => {
  if (arr.length <= 1) {
    return arr;
  }
  let mid = Math.floor(arr.length / 2);
  let leftArr = arr.slice(0, mid);
  let rightArr = arr.slice(mid);

  return merge(mergeSort(leftArr), mergeSort(rightArr));
};

let hotArr = [89, 0, 3, 100, -1, 7, -3, 56, 2, 8, 1, 45, 4];
//console.log(mergeSort(hotArr));

/**
 *
 * @Merge_Sort
 *
 * @param {*} left
 * @param {*} right
 * @returns
 *
 */
let testHelper = (left, right) => {
  let result = [];

  let i = 0;
  let j = 0;
  let k = 0;

  while (i < left.length && j < right.length) {
    if (left[i] < right[j]) {
      result[k] = left[i];
      k++;
      i++;
    } else {
      result[k] = right[j];
      k++;
      j++;
    }
  }

  while (i < left.length) {
    result[k] = left[i];
    k++;
    i++;
  }

  while (j < right.length) {
    result[k] = right[j];
    k++;
    j++;
  }

  return result;
};

let testMerge = (arr) => {
  if (arr.length <= 1) {
    return arr;
  }

  let mid = Math.floor(arr.length / 2);
  let leftArr = arr.slice(0, mid);
  let rightArr = arr.slice(mid);

  return testHelper(testMerge(leftArr), testMerge(rightArr));
};

//console.log(testMerge(hotArr));

/**
 *
 * @Quick_Sort
 *
 * @param {*} arr
 * @returns
 *
 */

let quickSort = (arr) => {
  if (arr.length <= 1) {
    return arr;
  }

  let pivot = arr[arr.length - 1];
  let leftArr = [];
  let rightArr = [];

  for (let el of arr.slice(0, arr.length - 1)) {
    el < pivot ? leftArr.push(el) : rightArr.push(el);
  }

  if (leftArr.length > 0 && rightArr.length > 0) {
    return [...quickSort(leftArr), pivot, ...quickSort(rightArr)];
  } else if (leftArr.length > 0) {
    return [...quickSort(leftArr), pivot];
  } else {
    return [pivot, ...quickSort(rightArr)];
  }
};

let testAr = [5, 0, 2, 9, -1];
//console.log(quickSort(testAr));
