/**
 *
 * @Higher_Order_Function
 *
 */
let multiplyBy = (num1) => {
  return (num2) => num1 * num2;
};

const multiplyByTwo = multiplyBy(2);
// console.log(multiplyByTwo(10));

const multiplyByTen = multiplyBy(10);
// console.log(multiplyByTen(10));

/**
 *
 * @Higher_Order_Function
 * step-1: Accept Function as an argument
 * step-2: return another Function
 *
 */

let authenticationAdmin = (person, fn) => {
  if (person.level == "admin") {
    return fn(person); //return another function
  } else if (person.level == "user") {
    return fn(person);
  } else {
    return "Invalid Input";
  }
};

let helloAdmin = (adminPerson) => {
  return `For Admin:~: ${adminPerson.greeting}`;
};

let helloUser = (userPerson) => {
  return `For User:~: ${userPerson.greeting}`;
};

let adminObj = {
  level: "admin",
  greeting: "Thank you admin",
};

let userObj = {
  level: "user",
  greeting: "Thank you user",
};

//Accept helloAdmin Function as an argument
console.log(authenticationAdmin(adminObj, helloAdmin)); //For Admin:~: Thank you admin
console.log(authenticationAdmin(userObj, helloUser)); //For User:~: Thank you user
