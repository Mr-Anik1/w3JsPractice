/**
 * @Class_Introduction
 */

class Car {
  constructor(name, year) {
    this.carName = name;
    this.carYear = year;
  }

  //Object like a key-value pair
  anik = "gp"; //property anik
  age = 20; //property age

  //method greet()
  greet() {
    return this.carName;
  }

  run() {
    return `${this.carName} is running since ${this.carYear}`;
  }
}

let audi = new Car("AUDI", 1950);
// let twoDarr = Object.entries(audi);
// let nObj = Object.fromEntries(twoDarr);

console.log(audi.run());

//Create another car using the Car class.
let bmw = new Car("BMW", 2000);
console.log(bmw.run());

//For the Line Gap
console.log(`
`);

/*


--------------------------|||||||-----------------------------


*/

/**
 * @Class_Inheritance
 */

//Parent Class
class FatherCar {
  constructor(name) {
    this.brandName = name;
  }

  isAccess = true; //property

  present() {
    return `I have a ${this.brandName}`;
  }
}

//Using extends, child classes inherit from their parent classes.
class sonCar extends FatherCar {
  constructor(name, model) {
    super(name); //The super() method refers to the parent class.
    this.modelName = model;
  }

  show() {
    return `${this.present()}, it is a ${this.modelName}!`;
  }
  //present() is the FatherCar method, not the SonCar method; we can access it with extends. This is class inheritance in JavaScript.
}

let myNewCar = new sonCar("Tesla", "Model 3");
console.log(myNewCar.show());
console.log(myNewCar.isAccess); //parent property access

let myAnotherCar = new sonCar("Hundai", "Top Road");
console.log(myAnotherCar.show());

/**
 * @getter_and_setter
 */

class GScar {
  constructor(model) {
    this.carName = model;
  }

  //getter
  get cName() {
    return this.carName;
  }

  //setter
  set cName(str) {
    this.carName = str;
  }

  //We can see that the getter and setter names are identical, in this case, "cName".

  //It should be noted that the getter and setter method names cannot be the same as the name of the property, in this case "carName", which is why we use the getter and setter names "cName" instead of "carName."
}

let helloMyCar = new GScar("Xavier");

//getter
console.log(helloMyCar.cName); //Xavier
//without parentheses, we can call it

//setter
helloMyCar.cName = "Toyota";

console.log(helloMyCar.cName); //Toyota

//For the Line Gap
console.log(`
`);

/*

--------------------------|||||||---------------------------

*/

/**
 * @Real_Class_Inheritance_Example_in_JavaScript
 */

//Grandfather Class
class GrandFather {
  constructor(gName, gAge) {
    this.myGName = gName;
    this.myGAge = gAge;
  }

  showGrandFather() {
    return `Hello, I'm ${this.myGName}, and I will be ${this.myGAge} years old`;
  }

  //Setter
  set ageS(x) {
    this.myGAge = x;
  }
}

//Father Class
class Father extends GrandFather {
  constructor(gName, gAge, fName, year) {
    super(gName, gAge);
    this.fatherName = fName;
    this.thisYear = year;
  }

  showFather() {
    return `${this.showGrandFather()} in ${this.thisYear}. My son's name is ${
      this.fatherName
    },`;
  }
}

//Grandson Class
class GrandSon extends Father {
  constructor(gName, gAge, fName, year, gSonName, gSonAge) {
    super(gName, gAge, fName, year);
    this.grandSonName = gSonName;
    this.grandSonAge = gSonAge;
  }

  helloGrandSon() {
    return `${this.showFather()} and you know that ${
      this.grandSonName
    } is my grandson, and he will be ${this.grandSonAge} years old in ${
      this.thisYear
    }.`;
  }
}

let nextGeneration1 = new GrandSon(
  "Abdul Samad Bapari",
  100,
  "Shiful",
  2023,
  "Anik",
  20
);

console.log(nextGeneration1.helloGrandSon());
//Hello, I'm Abdul Samad Bapari, and I will be 100 years old in 2023. My son's name is Shiful, and you know that Anik is my grandson, and he will be 20 years old in 2023.

//Setter => The GrandFather age is set at 115.
nextGeneration1.ageS = 115;

console.log(nextGeneration1.helloGrandSon());
//Hello, I'm Abdul Samad Bapari, and I will be 115 years old in 2023. My son's name is Shiful, and you know that Anik is my grandson, and he will be 20 years old in 2023.

//For the Line Gap
console.log(` 
`);

let anotherNextGeneration = new GrandSon(
  "Abdul Samad",
  90,
  "Shiful",
  2024,
  "Antor",
  16
);

console.log(anotherNextGeneration.helloGrandSon());
//Hello, I'm Abdul Samad, and I will be 90 years old in 2024. My son's name is Shiful, and you know that Antor is my grandson, and he will be 16 years old in 2024.

console.log(anotherNextGeneration);
/*

  GrandSon {
  myGName: 'Abdul Samad',
  myGAge: 90,
  fatherName: 'Shiful',
  thisYear: 2024,
  grandSonName: 'Antor',
  grandSonAge: 16
}

*/

//For the Line Gap
console.log(`
`);

/*

--------------------------|||||||-----------------------------

*/

/**
 * @JavaScript_Static_Method
 *
 *If you need to use a temporary method and you want to use it, it doesn't create an object [like nObj]. In this moment, you can apply the Javascript Static Method.
 *
 */

class HelloStatic {
  constructor(value) {
    this.myValue = value;
  }

  //Normal
  static tMethod() {
    return `Hello static Method`;
  }

  //send nObj as a parameter
  static good(x) {
    return `My static value is ${x.myValue}`;
  }
}

let nObj = new HelloStatic(20);
console.log(HelloStatic.tMethod()); //Hello static Method
//If you want to call tMethod(), you need to be HelloStatic.tMethod() insted of nObj.tMethod()

console.log(HelloStatic.good(nObj)); //My static value is 20
//If you want to use the nObj inside the static method, you can send it as a parameter.
