//Parent
function Person(name, birthYear) {
  this.name = name;
  this.birthYear = birthYear;
}

Person.prototype.calculateAge = function () {
  let date = new Date().getFullYear();
  let age = date - this.birthYear;
  console.log(`I am ${age} years old.`);
};

//Child
function Student(name, birthYear, course) {
  Person.call(this, name, birthYear); //dry principles
  this.course = course;
}

//prototype linking
Student.prototype = Object.create(Person.prototype);

Student.prototype.introduce = function () {
  console.log(
    `Hello my name is ${this.name} and I am joining to ${this.course} course.`
  );
};

let mike = new Student("Anik", 2002, "Advanced JavaScript");
mike.introduce(); //Access from Student
mike.calculateAge(); //Access from Person

console.log(mike.__proto__); //introduce:f()
console.log(mike.__proto__.__proto__); //calculateAge:f()
console.log(mike.__proto__.__proto__.__proto__); //Object
//introduce:f() < calculateAge:f() < Mother Object

/**
 *
 *@Prototype_Chaining_Exercise
 *@Polymorphism
 *
 */

//parent car
function Car(model, speed) {
  this.model = model;
  this.speed = speed;
}

//Car accelerate()
Car.prototype.accelerate = function () {
  this.speed += 10; //speed increase
  console.log(`${this.model} is going at ${this.speed} km/h .`);
};

Car.prototype.brake = function () {
  this.speed -= 5; //speed decrease
  console.log(`${this.model} is going at ${this.speed} km/h .`);
};

//child  car
function MyEV(model, speed, charge) {
  Car.call(this, model, speed); //use dry principles
  this.charge = charge;
}

//Prototype Chaining
MyEV.prototype = Object.create(Car.prototype);

//MyEV power()
MyEV.prototype.power = function (chargeTo) {
  this.charge = chargeTo;
};

//MyEV accelerate()
MyEV.prototype.accelerate = function () {
  this.speed += 20;
  this.charge -= 1;
  console.log(
    `${this.model} is going at ${this.speed} km/h with a charge of ${this.charge}% .`
  );
};

//create anikCar object
let anikCar = new MyEV("Tesla", 120, 40);

//anikCar accesses the accelerate() method from the MyEV constructor function because of its increased speed of 20 km/h.
//Speed has been increased, and charge has been decreased.
anikCar.accelerate(); //Tesla is going at 140 km/h with a charge of 39% .
anikCar.accelerate(); //Tesla is going at 160 km/h with a charge of 38% .

//anikCar accesses the brake() method from the Car constructor function .
//speed has been decreased.
anikCar.brake(); //Tesla is going at 155 km/h
anikCar.brake(); //Tesla is going at 150 km/h

//anikCar accesses the power() method from the MyEV constructor function .
//charge has been increased to 90%
anikCar.power(90);

//Speed has been increased, and charge has been decreased .
anikCar.accelerate(); //Tesla is going at 170 km/h with a charge of 89% .

//anikCar Object
console.log(anikCar); //Car { model: 'Tesla', speed: 170, charge: 89 }

console.log(anikCar.__proto__); //power:f() and accelerate:f()   => Note: This accelerate() is not similar to the Car accelerate() method; this accelerate() is from the MyEV constructor function.
console.log(anikCar.__proto__.__proto__); //accelerate:f() and brake:f()
console.log(anikCar.__proto__.__proto__.__proto__); //Object

/**
 * @Note
 */
// We have seen that Car has an accelerate() method, and MyEV also has an accelerate() method; in this case, we called it polymorphism.
