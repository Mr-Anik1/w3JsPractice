function createElf(name, weapon) {
  return {
    name: name,
    weapon: weapon,
    attack() {
      return `${this.name} attack with ${weapon}`;
    },
  };
}
