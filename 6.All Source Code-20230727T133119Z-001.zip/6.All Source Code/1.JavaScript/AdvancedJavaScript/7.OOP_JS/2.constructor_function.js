//Constructor function should start with a capital letter
function Person(name, weapon) {
  this.pName = name;
  this.pWeapon = weapon;
}

let p1 = new Person("Anik", "Fire");
console.log(p1.pName);

/**
 *
 *@Simple_Example
 *
 */

//Constructor Function
function Car(model, speed) {
  this.cModel = model;
  this.cSpeed = speed;
}

Car.prototype.accelerator = function () {
  this.cSpeed += 10; //Increase 10
  console.log(
    `Speed has increased and now ${this.cModel} speed is ${this.cSpeed} km/h`
  );
};

Car.prototype.brake = function () {
  this.cSpeed -= 5; //Decrease 5
  console.log(
    `Speed has decreased and now ${this.cModel} speed is ${this.cSpeed} km/h`
  );
};

let BMW = new Car("BMW", 150);
let toyota = new Car("Toyota", 120);

BMW.accelerator(); //160
BMW.accelerator(); //170
BMW.brake(); //165
BMW.accelerator(); //175

toyota.brake(); //115
