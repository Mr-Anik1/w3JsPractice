/**
 *
 *@Last_Exercise
 *@private_fields_and_chaining_method
 *
 */

//parent class
class Car {
  constructor(model, speed) {
    this.model = model;
    this.speed = speed;
  }

  //Car accelerate
  accelerate() {
    this.speed += 10;
    console.log(`${this.model} is going at ${this.speed} km/h .`);
    return this;
  }

  brake() {
    this.speed -= 5;
    console.log(`${this.model} is going at ${this.speed} km/h .`);
    return this;
  }
}

//child class
class MyEV extends Car {
  //private fields
  #charge;

  constructor(model, speed, charge) {
    super(model, speed); //called parents class Car
    this.#charge = charge; //Now, charge is private and it cannot be accessed outside of the class.
  }

  //MyEV accelerate
  accelerate() {
    this.speed += 20;
    this.#charge -= 1;
    console.log(
      `${this.model} is going at ${this.speed} km/h with a charge of ${
        this.#charge
      } .`
    );
    return this; //for the chaining method, and it returns a legion{ } Object.
  }

  power(chargeTo) {
    this.#charge = chargeTo;
    return this;
  }
}

let legion = new MyEV("Legion", 64, 30);

//chaining method()
legion.accelerate().accelerate().brake().brake().power(70).accelerate();
/*
     Legion is going at 84 km/h with a charge of 29 .
     Legion is going at 104 km/h with a charge of 28 .
     Legion is going at 99 km/h .
     Legion is going at 94 km/h .
     Legion is going at 114 km/h with a charge of 69 .
*/
