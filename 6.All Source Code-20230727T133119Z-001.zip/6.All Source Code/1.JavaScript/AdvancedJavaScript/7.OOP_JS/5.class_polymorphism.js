/**
 *
 *@class
 *
 *@polymorphism_and_prototype_chaining_with_class
 *@It_is_easy_to_implement_than_constructor_function
 *
 */

//parent class
class Car {
  constructor(model, speed) {
    this.model = model;
    this.speed = speed;
  }

  //Car accelerate
  accelerate() {
    this.speed += 10;
    console.log(`${this.model} is going at ${this.speed} km/h .`);
  }

  brake() {
    this.speed -= 5;
    console.log(`${this.model} is going at ${this.speed} km/h .`);
  }
}

//child class
class MyEV extends Car {
  constructor(model, speed, charge) {
    super(model, speed);
    this.charge = charge;
  }

  //MyEV accelerate
  accelerate() {
    this.speed += 20;
    this.charge -= 1;
    console.log(
      `${this.model} is going at ${this.speed} km/h with a charge of ${this.charge} .`
    );
  }

  power(chargeTo) {
    this.charge = chargeTo;
  }
}

let myNewCar = new MyEV("Tesla", 115, 43);

//accelerate() from the child class MyEV
myNewCar.accelerate(); //Tesla is going at 135 km/h with a charge of 42 .
myNewCar.accelerate(); //Tesla is going at 155 km/h with a charge of 41 .

//brake() from the parent class Car
myNewCar.brake(); //Tesla is going at 150 km/h .

//power() method from the clild class MyEV and it has been increased charge to 75%
myNewCar.power(75);

console.log(myNewCar); //MyEV { model: 'Tesla', speed: 150, charge: 75 }

console.log(myNewCar.__proto__); //MyEV{ } class and accelerate:f() & power:f() method
console.log(myNewCar.__proclass__proto__); //Car{ } class and accelerate:f() & brake:f() method
console.log(myNewCar.__proto__.__proto__.__proto__); //Object{ }

//We have seen that Car has an accelerate() method, and MyEV also has an accelerate() method; in this case, we called it polymorphism.
