/**
 *
 *@Chaining_method
 *
 */

class Account {
  //public
  helloPublic = "I am a public instance";

  //private
  #movements = [];
  #pin;

  //constructor function
  constructor(owner, currency, pin) {
    this.owner = owner;
    this.currency = currency;
    this.#pin = pin;
  }

  deposit(val) {
    this.#movements.push(val);
    return this; //for the chaining method, and it returns acc1{ } Object
  }

  withdraw(val) {
    this.#movements.push(-val);
    return this; //for the chaining method, and it returns acc1{ } Object
  }

  getMovements() {
    return this.#movements;
  }

  _approveLoan(val) {
    if (val <= 10000) {
      return true;
    } else {
      return false;
    }
  }

  requestLoan(val) {
    if (this._approveLoan(val)) {
      this.deposit(val);
      console.log(`Congrats! Your loan has been approved.`);
    } else {
      console.log(`Sorry! Your loan has not been approved.`);
    }
    return this; //for the chaining method, and it returns acc1{ } Object
  }
}

let acc1 = new Account("Anik", "BDT", 111);

//chaining method()
acc1.deposit(576).withdraw(230).requestLoan(7850).withdraw(5000);

console.log(acc1.getMovements()); //[ 576, -230, 7850, -5000 ]
console.log(acc1);

/*
Under-the-hood chaining method

->return `this` means return acc1 Object{ }
->acc1.deposit(576) => return acc1
->then acc1.withdraw(230) => its also return acc1
->then acc1.requestLoan(7850) => its also return acc1
->then acc1.withdraw(5000) => its also return acc1

*/
