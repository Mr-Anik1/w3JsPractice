/**
 * @Class_Example
 */

class Chracter {
  constructor(name, weapon) {
    this.cName = name;
    this.cWeapon = weapon;
  }

  attack() {
    return `${this.cName} is attacked with ${this.cWeapon}`;
  }
}

class Elf extends Chracter {
  //When you use # before the property name, that will be private property. In this case, "#go" is a private property.
  #go = "Go Now";
  //Private property that can only be accessed within the Elf class; it cannot be accessed outside of the Elf class.

  constructor(name, weapon, type) {
    super(name, weapon);
    this.elfType = type;
  }
  goMeth() {
    return this.#go;
  }
}

const fiona = new Elf("Anik", "Strom", "Water");
console.log(fiona.attack());
console.log(fiona.goMeth()); //Go Now

console.log(fiona instanceof Elf); //true
console.log(fiona instanceof Chracter); //true

/*
  
     When a new Elf object is created, the constructor function of the Character class is called first, which sets the cName and cWeapon properties of the object instance being created. Then, the constructor function of the Elf class is called, which sets the elfType property of the fiona object.
  
     So, fiona has a `cName` and `cWeapon` property inherited from the Character class, and an `elfType` property defined in the Elf class. However, `this` in the line `this.cWeapon = weapon` still refers to the Character object instance being created, not specifically to fiona.
  
   */
