/**
 *
 *@Encapsulation
 *@Public_and_Private_fields_in_JavaScript_class
 *
 */

//1) public field
//2) private field
//3) public method
//4) private method

class Account {
  //1) public fields( instance ) =>[not a property]
  helloPublic = "I am public instance";

  //2) private fields with # [really works]
  #movements = []; //Now, movements is not accessible from outside of the class.
  #pin; //It's silly different, because when we call new keyword for creating an object like acc1, at this moment we have passed pin value, and for this reason here we simply write only #pin.

  constructor(owner, currency, pin) {
    this.owner = owner;
    this.currency = currency;
    this.#pin = pin;

    //(funny convention [that doesn't really work]) protected property with _
    //this._pin=pin;
  }

  //3) public method =>In general, all methods are public, like deposit(), withdrawal(), requestLoan(), etc.
  deposit(val) {
    this.#movements.push(val);
  }

  withdraw(val) {
    this.#movements.push(-val);
  }

  //movements access with the public API getMovements()
  getMovements() {
    return this.#movements;
  }

  //4) private method with simple #, now it can be accessed only inside the class.
  //#approveLoan(val){  } But unfortunately, it only works in some browsers.

  //amount check
  _approveLoan(val) {
    if (val <= 10000) {
      return true;
    } else {
      return false;
    }
  }

  requestLoan(val) {
    if (this._approveLoan(val)) {
      this.deposit(val);
    }
  }
}

let acc1 = new Account("Anik", "BDT", 111);

acc1.requestLoan(3456); //approved
acc1.requestLoan(47561); //not approved
acc1.requestLoan(1236); //approved

//access movements
console.log(acc1.getMovements()); //[ 3456, 1236 ]

acc1.deposit(8743);
acc1.withdraw(671);

console.log(acc1.getMovements()); //[ 3456, 1236, 8743, -671 ]

console.log(acc1);
/*

Account {
helloPublic: 'I am public instance',
owner: 'Anik',
currency: 'BDT'
}

*/
