//Simple Example of the Currying Function
//Currying function using the Clouser concept
function curriedMultiply(a) {
  return function (b) {
    return function (c) {
      return a * b * c; //It's using clouser to remember the a and b values.
    };
  };
}

console.log(curriedMultiply(10)(20)(30)); //6000

let step1 = curriedMultiply(5); //a
let step2 = step1(20); //b
let step3 = step2(10); //c
console.log(step3); //1000

/**
 * @Another_Example
 */
let discount = (dis) => {
  let disc = dis / 100;
  return (price) => {
    return price - price * disc;
  };
};

//Currying is combination of multiple partial function
let tenPercent = discount(10); //partial function
let customer1 = tenPercent(700); //another partial function and its complete currying
console.log(customer1); //630
let customer2 = tenPercent(1200);
console.log(customer2); //1080

let thirtyPercent = discount(30);
let customer3 = thirtyPercent(5000);
console.log(customer3); //3500
