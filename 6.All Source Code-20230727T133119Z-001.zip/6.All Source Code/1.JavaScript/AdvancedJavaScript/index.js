let flattenArr = (arr) => {
  let finalArr = [];
  for (let i = 0; i < arr.length; i++) {
    if (Array.isArray(arr[i])) {
      finalArr = finalArr.concat(flattenArr(arr[i]));
    } else {
      finalArr.push(arr[i]);
    }
  }
  return finalArr.sort((a, b) => a - b);
};

let unFlatArr = [
  1,
  2,
  [3, 4, 5, [13, 14, 15, [9, 10], 11, 12], 6, 7, 8],
  16,
  17,
];
//console.log(flattenArr(unFlatArr));

let wizard = {
  name: "Oz",
  health: 50,
  heal(n1, n2) {
    return (this.health += n1 + n2);
  },
};

let roboin = {
  name: "Robin Hood",
  health: 30,
};

// console.log(roboin);
// wizard.heal.call(roboin, 100, 200);
// console.log(roboin);
//console.log(wizard.heal(300, 400));

// console.log(roboin); //{ name: 'Robin Hood', health: 30 }
// let archerHeal = wizard.heal.bind(roboin); //Using bind()
// archerHeal(30, 40);
// console.log(roboin); //{ name: 'Robin Hood', health: 100 }

/**
 *
 * @Closour
 *
 */
function grandfather() {
  let grandPa = "GrandFather";
  return function () {
    let father = "Father";
    return function () {
      let son = "Son";
      return `${grandPa} > ${father} > ${son}`;
    };
  };
}

let f1 = grandfather();
let f2 = f1();

// console.log(f1());
// console.log(f2());

let userObj = {
  level: "user",
  greeting: "Thank you user",
  met: function () {
    console.log(this);
    return function () {
      return this;
    };
  },
};

// let thisTa = userObj.met().bind(userObj);
// console.log(thisTa());

/**
 * @Real_Class_Inheritance_Example_in_JavaScript
 */

//Grandfather Class
class GrandFather {
  constructor(gName, gAge) {
    this.myGName = gName;
    this.myGAge = gAge;
  }

  showGrandFather() {
    return `Hello I'm ${this.myGName} and I'm ${this.myGAge} years old`;
  }

  //Setter
  set ageS(x) {
    this.myGAge = x;
  }
}

//Father Class
class Father extends GrandFather {
  constructor(gName, gAge, fName, year) {
    super(gName, gAge);
    this.fatherName = fName;
    this.thisYear = year;
  }

  showFather() {
    return `${this.showGrandFather()} in ${this.thisYear} and my son name is ${
      this.fatherName
    },`;
  }
}

//Grandson Class
class GrandSon extends Father {
  constructor(gName, gAge, fName, year, gSonName, gSonAge) {
    super(gName, gAge, fName, year);
    this.grandSonName = gSonName;
    this.grandSonAge = gSonAge;
  }

  helloGrandSon() {
    return `${this.showFather()} and you know that ${
      this.grandSonName
    } is my grandson and he is ${this.grandSonAge} years old in ${
      this.thisYear
    }.`;
  }
}

let nextGeneration1 = new GrandSon(
  "Abdul Samad Bapari",
  100,
  "Shiful",
  2023,
  "Anik",
  20
);

//console.log(nextGeneration1.helloGrandSon());
//Hello I'm Abdul Samad Bapari and I'm 100 years old in 2023 and my son name is Shiful, and you know that Anik is my grandson and he is 20 years old in 2023.

//Setter => Grandfather age is set to 115
nextGeneration1.ageS = 115;

//console.log(nextGeneration1.helloGrandSon());
//Hello I'm Abdul Samad Bapari and I'm 115 years old in 2023 and my son name is Shiful, and you know that Anik is my grandson and he is 20 years old in 2023.

/*


--------------------------|||||||-----------------------------


*/
