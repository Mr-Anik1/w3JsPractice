let fatherMemorize = () => {
  let caches = {};
  //inner function
  return (p) => {
    if (p in caches) {
      return caches[p]; //caches from clouser
    } else {
      console.log("Run");
      caches[p] = p + 100;
      return caches[p];
    }
  };
};

let memorize = fatherMemorize();
console.log("1.", memorize(7));
console.log("2.", memorize(5));
console.log("3.", memorize(5));
console.log("3.", memorize(8));
