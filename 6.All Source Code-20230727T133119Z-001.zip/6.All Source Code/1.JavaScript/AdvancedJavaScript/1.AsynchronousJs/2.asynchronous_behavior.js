/**
 * @Asynchronous_JavaScript_Basic
 */

//console.log("Hello I'm line 1");

setTimeout(() => {
  //console.log("Hello I'm line 2");
}, 2000);

// setInterval(() => {
//   console.log("Hello I'm line 2");
// }, 2000);

//console.log("Hello I'm line 3");

/*
 
    Hello I'm line 1
    Hello I'm line 3
    Hello I'm line 2

*/

/*


--------------------------|||||||||---------------------------


*/

let payment = true;
let marks = 90;

let enroll = (callBack) => {
  console.log("Course enrolment is in progress");
  setTimeout(function () {
    if (payment) {
      callBack();
    } else {
      console.log("Payment failed");
    }
  }, 2000);
};

let progress = (callBack) => {
  console.log("Course on progress...");
  setTimeout(function () {
    if (marks >= 80) {
      callBack();
    } else {
      console.log("You could not get enough marks to get the certificate");
    }
  }, 3000);
};

let getCertificate = () => {
  console.log("Preparing your certificate!");
  setTimeout(function () {
    console.log("Congrats! You got the certificate");
  }, 1000);
};

// enroll(function () {
//   progress(getCertificate);
// });

/*


--------------------------|||||||||---------------------------


*/

/**
 *
 * @Run_the_code_below_on_js_visualizar_9000
 *
 I've given anonymous functions names like set1, set2, set3, and f1. 

 */

/*


let payment = true;
let marks = 90;

let enroll = (callBack) => {
  console.log("Course enrolment is in progress");
  setTimeout(function set1() {
    if (payment) {
      callBack();
    } else {
      console.log("Payment failed");
    }
  }, 2000);
};

let progress = (callBack) => {
  console.log("Course on progress...");
  setTimeout(function set2() {
    if (marks >= 80) {
      callBack();
    } else {
      console.log("You could not get enough marks to get the certificate");
    }
  }, 3000);
};

let getCertificate = () => {
  console.log("Preparing your certificate!");
  setTimeout(function set3() {
    console.log("Congrats! You got the certificate");
  }, 1000);
};

enroll(function f1() {
  progress(getCertificate);
});



*/

/*


--------------------------|||||||||---------------------------


*/

/**
 * @asynchronous_behavior_and_callback_hell_example
 */

let callbackHell = (payment, marks) => {
  //Enrollment Scope
  let enrollCourse = (callback) => {
    console.log("Course enrolment is in progress");
    setTimeout(function () {
      if (payment) {
        callback();
      } else {
        console.log("Payment Failed!");
      }
    }, 2000);
  };

  //Course Progress Scope
  let courseProgress = (callback) => {
    console.log("Course on progress...");
    setTimeout(function () {
      if (marks >= 80) {
        callback();
      } else {
        console.log(
          "You couldn't get enough mark for get the certificate, stay focus!"
        );
      }
    }, 4000);
  };

  //Course Certificate Scope
  let courseCertificate = (callback) => {
    console.log("Your certificate is being processed.");
    setTimeout(function () {
      console.log("Congrats! You got the certificate.");
      callback();
    }, 3000);
  };

  //Wish Scope
  let success = (callback) => {
    setTimeout(function () {
      console.log("You will success in life");
      callback();
    }, 2000);
  };

  //Creator Scope
  let creator = () => {
    console.log("Guess who is your creator?");
    setTimeout(function () {
      console.log(
        "You ara a very lucky person that because of Mr.Anik is your creator!"
      );
    }, 4000);
  };

  //CallBack Hell
  enrollCourse(function () {
    courseProgress(function () {
      courseCertificate(function () {
        success(creator);
      });
    });
  });
};

callbackHell(true, 98);
/*

  Course enrolment is in progress
  Course on progress...
  Your certificate is being processed.
  Congrats! You got the certificate.
  You will success in life
  Guess who is your creator?
  You ara a very lucky person that because of Mr.Anik is your creator!

*/

//callbackHell(false, 87);
/*
   Course enrolment is in progress
   Payment Failed!
*/

//callbackHell(true, 65);
/*

   Course enrolment is in progress
   Course on progress...
   You couldn't get enough mark for get the certificate, stay focus!

*/
