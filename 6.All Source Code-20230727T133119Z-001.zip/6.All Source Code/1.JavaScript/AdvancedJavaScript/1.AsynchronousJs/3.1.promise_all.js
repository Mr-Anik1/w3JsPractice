let promiseOne = new Promise((resolve, reject) => {
  setTimeout(resolve("PromiseOne is resolved"), 2000);
});

let promiseTwo = new Promise((resolve, reject) => {
  setTimeout(reject("promiseTwo is rejected"), 1000);
});

let promiseThree = new Promise((resolve, reject) => {
  setTimeout(resolve("promiseThree is resolved"), 3000);
});

/**
 *
 * @promise_all_with_then_catch_block
 *
 * //If one of promise is rejected then Promise.all() show only rejected message
 *
 */
Promise.all([promiseOne, promiseTwo])
  .then((data) => console.log(data))
  .catch((err) => console.log("Error!", err));
//Error! promiseTwo is rejected

//this two promise is resolved
Promise.all([promiseOne, promiseThree])
  .then((data) => console.log(data))
  .catch((err) => console.log("Error!", err));
//[ 'PromiseOne is resolved', 'promiseThree is resolved' ]

/**
 *
 * @promise_all_with_async_await
 *
 */
async function myPromiseAll(arrOfPromises) {
  try {
    let data = await Promise.all(arrOfPromises);
    console.log(data);
  } catch (err) {
    console.log("Error!", err);
  }
}

myPromiseAll([promiseOne, promiseTwo]);
//Error! promiseTwo is rejected

/**
 * @Another_One
 */
//this two promise is resolved
let myResolvedPromise = async function (arrOfPromises) {
  try {
    let data = await Promise.all(arrOfPromises);
    console.log(data);
  } catch (err) {
    console.log("Error!", err);
  }
};

myResolvedPromise([promiseOne, promiseThree]);
//[ 'PromiseOne is resolved', 'promiseThree is resolved' ]
