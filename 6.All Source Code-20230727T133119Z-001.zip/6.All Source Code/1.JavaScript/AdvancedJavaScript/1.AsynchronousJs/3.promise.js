//console.log("Task-1");

let pay = true;
//Promise Definition
let promis = new Promise(function (resolve, reject) {
  setTimeout(function () {
    if (pay) {
      resolve("Task-2");
    } else {
      reject("Failed!");
    }
  }, 2000);
});

//Promise Call
// promis
//   .then(function (val) {
//     console.log(val);
//   })
//   .catch(function (err) {
//     console.log(err);
//   });

//console.log("Task-3");

/*


--------------------------|||||||||---------------------------


*/

let payment = true;
let marks = 89;

let courseEnroll = () => {
  console.log("Course enrollment is on progress");

  let promise = new Promise(function (resolve, reject) {
    setTimeout(function () {
      if (payment) {
        resolve();
      } else {
        reject("Payment Failed!");
      }
    }, 2000);
  });

  return promise;
};

let courseProgress = () => {
  console.log("Course is on progress...");

  let promise = new Promise(function (resolve, reject) {
    setTimeout(function () {
      if (marks >= 80) {
        resolve();
      } else {
        reject(
          "You could not get enough mark for get the certificate, keep learning and stay focus!"
        );
      }
    }, 4000);
  });

  return promise;
};

let courseCertificate = () => {
  console.log("Your certificate is being processed");

  let promise = new Promise(function (resolve, reject) {
    setTimeout(function () {
      console.log("Congrats! You got the certificate.");
      resolve();
    }, 2000);
  });

  return promise;
};

let success = () => {
  let promise = new Promise(function (resolve, reject) {
    setTimeout(function () {
      console.log("You will success in life");
      resolve();
    }, 2000);
  });

  return promise;
};

let creator = () => {
  console.log("Guess who is your creator?");

  let promise = new Promise(function (resolve, reject) {
    setTimeout(function () {
      resolve(
        "You ara a very lucky person that because of Mr.Anik is your creator!"
      );
    }, 4000);
  });

  return promise;
};

courseEnroll()
  .then(courseProgress)
  .then(courseCertificate)
  .then(success)
  .then(creator)
  .then(function (value) {
    console.log(value);
  })
  .catch(function (err) {
    console.log(err);
  });
