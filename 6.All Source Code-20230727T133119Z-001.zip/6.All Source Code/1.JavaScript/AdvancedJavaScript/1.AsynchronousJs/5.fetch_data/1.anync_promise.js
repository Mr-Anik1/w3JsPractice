//promise with then catch block
fetch("https://jsonplaceholder.typicode.com/users")
  .then((response) => response.json())
  .then((body) => {
    body.map((v) => console.log(v.email));
  })
  .catch((err) => console.log(err));

//promise with async await
async function fetchFunc() {
  try {
    let response = await fetch("https://jsonplaceholder.typicode.com/users");
    let fetchData = await response.json();
    fetchData.map((v) => console.log(v.name));
  } catch (err) {
    console.log(`Error!`);
  }
}
fetchFunc();
