/**
 * @Must_be_run_on_a_browser
 */

let urls = [
  "https://jsonplaceholder.typicode.com/users",
  "https://jsonplaceholder.typicode.com/posts",
  "https://jsonplaceholder.typicode.com/albums",
];

/**
 * @Fetch_Data_with_simple_promise_all_and_then_block
 */
Promise.all(
  urls.map((url) => {
    return fetch(url).then((response) => response.json());
  })
)
  .then((resultArr) => {
    console.log("Users", resultArr[0]);
    console.log("Posts", resultArr[1]);
    console.log("Albums", resultArr[2]);
  })
  .catch(() => {
    console.log("Error!");
  });

/**
 * @Fetch_Data_with_async_await
 */
let getData = async function () {
  try {
    //Array Destructuring
    let [users, posts, albums] = await Promise.all(
      urls.map((url) => {
        return fetch(url).then((response) => response.json());
      })
    );
    console.log("Users", users);
    console.log("Posts", posts);
    console.log("Albums", albums);
  } catch (err) {
    console.log("Oops! Error...");
  }
};
getData();

/**
 * @Pure
 * @Fetch_Data_with_async_await
 */
let getData2 = async function () {
  try {
    //Array Destructuring
    let [users, posts, albums] = await Promise.all(
      urls.map(async function (url) {
        let response = await fetch(url);
        return response.json();
      })
    );
    console.log("Users", users);
    console.log("Posts", posts);
    console.log("Albums", albums);
  } catch (err) {
    console.log("Oops! Error...");
  }
};
getData2();

/**
 *
 * @for_await_of_loop
 * @Same_result_without_promise_all
 *
 */
let newAsync = async function () {
  let arrayOfPromises = urls.map((url) => fetch(url));
  for await (let response of arrayOfPromises) {
    let data = await response.json();
    console.log(data);
  }
};
newAsync();
