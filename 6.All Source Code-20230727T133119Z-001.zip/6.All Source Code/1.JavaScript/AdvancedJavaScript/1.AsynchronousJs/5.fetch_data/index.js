/**
 * @Fetch_Data_and_Promise
 */

// Fetch data from API endpoint, parse response as JSON, and display it in an unordered list
fetch("https://jsonplaceholder.typicode.com/users")
  .then((response) => response.json())
  .then((body) => {
    // Create a list item for each user object in the response
    let myList = body.map((data) => {
      let li = document.createElement("li");
      let text = `${data.id}. Name:${data.name}, E-mail:${data.email}`;
      let textNode = document.createTextNode(text);
      li.appendChild(textNode);
      return li;
    });

    // Append each list item to the unordered list in the HTML document
    myList.forEach((li) => {
      document.getElementById("mylist").appendChild(li);
    });
  })
  .catch((err) => console.log(err));
