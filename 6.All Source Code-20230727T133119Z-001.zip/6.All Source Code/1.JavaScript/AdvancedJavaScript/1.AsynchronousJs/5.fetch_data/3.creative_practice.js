/**
 * @Creative_Practice
 */
let myUrls = [
  "https://jsonplaceholder.typicode.com/users",
  "https://jsonplaceholder.typicode.com/posts",
  "https://jsonplaceholder.typicode.com/albums",
];

async function good(urls) {
  try {
    let [users, posts, albums] = await Promise.all(
      urls.map(async function (url) {
        let response = await fetch(url);
        return response.json();
      })
    );

    //first 10 element
    let names = users.map((usr) => usr.name).slice(0, 10);
    let titles = posts.map((post) => post.title).slice(0, 10);
    let albumsId = albums.map((album) => album.id).slice(0, 10);

    //create a new array of Object using individual array element
    let personArray = [];
    for (let i = 0; i < names.length; i++) {
      personArray.push({
        albumId: albumsId[i],
        name: names[i],
        postTitle: titles[i],
      });
    }
    console.log(personArray);
  } catch (err) {
    console.log("Error!", err);
  }
}
good(myUrls);

/**
   * @Run_on_browser
   * @Result
   * 
   
   [
    {
      albumId: 1,
      name: "Leanne Graham",
      postTitle: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
    },
  
    { albumId: 2, name: "Ervin Howell", postTitle: "qui est esse" },
  
    {
      albumId: 3,
      name: "Clementine Bauch",
      postTitle: "ea molestias quasi exercitationem repellat qui ipsa sit aut",
    },
  
    { albumId: 4, name: "Patricia Lebsack", postTitle: "eum et est occaecati" },
  
    { albumId: 5, name: "Chelsey Dietrich", postTitle: "nesciunt quas odio" },
    {
      albumId: 6,
      name: "Mrs. Dennis Schulist",
      postTitle: "dolorem eum magni eos aperiam quia",
    },
    { albumId: 7, name: "Kurtis Weissnat", postTitle: "magnam facilis autem" },
    {
      albumId: 8,
      name: "Nicholas Runolfsdottir V",
      postTitle: "dolorem dolore est ipsam",
    },
    {
      albumId: 9,
      name: "Glenna Reichert",
      postTitle: "nesciunt iure omnis dolorem tempora et accusantium",
    },
    {
      albumId: 10,
      name: "Clementina DuBuque",
      postTitle: "optio molestias id quia eum",
    },
  ];
    
   * 
   */
