let life = (brush, rice, sleep) => {
  let wakeUp = () => {
    console.log("Good morning sir.");

    let promise = new Promise(function (resolve, reject) {
      setTimeout(function () {
        if (brush) {
          resolve();
        } else {
          reject(
            "Oops! You do not brush your teeth, first brush your teeth then start your day."
          );
        }
      }, 2000);
    });

    return promise;
  };

  let eat = () => {
    console.log("Ready for eat");

    let promise = new Promise(function (resolve, reject) {
      setTimeout(function () {
        if (rice) {
          resolve();
        } else {
          reject("First take your lunch then work, ok ?");
        }
      }, 3000);
    });

    return promise;
  };

  let sleepA = () => {
    console.log("Your bed time is comming soon...");

    let promise = new Promise(function (resolve, reject) {
      setTimeout(function () {
        if (sleep) {
          resolve("Good night!");
        } else {
          reject("Sudo I say now your bed time, go to bed and sleep");
        }
      }, 4000);
    });

    //If you have only resolve then shortcart
    //let promise = Promise.resolve("Good night!");

    return promise;
  };

  //Async Await
  async function good() {
    try {
      await wakeUp();
      await eat();
      let msg = await sleepA();
      console.log(msg);
    } catch (err) {
      console.log(err);
    }
  }

  good();

  //Promise Call
  // wakeUp()
  //   .then(eat)
  //   .then(sleepA)
  //   .then(function (value) {
  //     console.log(value);
  //   })
  //   .catch(function (err) {
  //     console.log(err);
  //   });
};

life(true, true, true);

/*


--------------------------|||||||||---------------------------


*/

//Callback
let hell = (brush, rice, sleep) => {
  let wakeUp = (callback) => {
    console.log("Good morning sir.");

    setTimeout(function () {
      if (brush) {
        callback();
      } else {
        console.log(
          "Oops! You do not brush your teeth, first brush your teeth then start your day."
        );
      }
    }, 2000);
  };

  let eat = (callback) => {
    console.log("Ready for eat");

    setTimeout(function () {
      if (rice) {
        callback();
      } else {
        console.log("First take your lunch then work, ok ?");
      }
    }, 3000);
  };

  let sleepA = () => {
    console.log("Your bed time is comming soon...");

    setTimeout(function () {
      if (sleep) {
        console.log("Good night!");
      } else {
        console.log("Sudo I say now your bed time, go to bed and sleep");
      }
    }, 4000);
  };

  wakeUp(function () {
    eat(sleepA);
  });
};

//hell(true, true, true);
