let promiseOne = new Promise((resolve, reject) => {
  setTimeout(resolve("PromiseOne is resolved"), 2000);
});

let promiseTwo = new Promise((resolve, reject) => {
  setTimeout(reject("promiseTwo is rejected"), 1000);
});

Promise.allSettled([promiseOne, promiseTwo])
  .then((data) => console.log(data))
  .catch((err) => console.log(err));

/*

[
  { status: 'fulfilled', value: undefined },
  { status: 'rejected', reason: undefined }
]

Promise.allSettled() show all of promises output 

*/

Promise.all([promiseOne, promiseTwo])
  .then((data) => console.log(data))
  .catch((err) => console.log("Error!", err));
//Error! promiseTwo is rejected

//If one of promise is rejected then Promise.all() show only rejected message
