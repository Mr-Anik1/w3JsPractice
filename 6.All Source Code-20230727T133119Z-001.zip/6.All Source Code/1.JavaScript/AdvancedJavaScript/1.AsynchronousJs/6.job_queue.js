/**
 * @How_JavaScript_works_behind_the_scenes
 */

//Line-1
setTimeout(() => console.log("TimeOut"));

//line-2
Promise.resolve().then(() => console.log("promise"));

//line-3
console.log("code");

/*

এখানে setTimeout() আর Promise() হলো Asynchronous, আর শুধু console.log("code") হলো Synchronous. 

তাই চোখ বুঝে বলা যেতে পারে আগে Synchronous কোডটা রান হবে, পরে Asynchronous রান হবে। তাই প্রথমে console.log(); এক্সিকিউট হবে। 

কোন Promise যখন, resolved বা rejected হয় তখন then বা catch কলব্যাক microtask queue তে যায়, অপরদিকে setTimeout() যায় event queue তে। 

microtask queue কিন্তু event queue থেকে বেশি প্রাধান্য পায়, সহজে বললে আগে microtask queue এর সবকিছু এক্সিকিউট হবে এবং তারপর event queue এর কাজ শুরু হবে। সেক্ষেত্রে Promise এর then() microtask queue তে থাকায় এটার কাজ আগে শেষ হবে এবং পরে event queue তে থাকা setTimeout() এর কাজ হবে। 

তাই বলা যায়, 
প্রথমঃ
console.log("code"); 

দ্বিতীয়ঃ 
Promise.resolve()
   .then(()=>console.log("promise")) 
    
সবার শেষেঃ 
setTimeout(()=>console.log("TimeOut"))

*/
