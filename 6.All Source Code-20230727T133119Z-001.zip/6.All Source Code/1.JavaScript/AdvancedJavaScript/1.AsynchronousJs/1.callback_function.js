/**
 * @Callback_Function
 *
 */

let display = (val) => {
  console.log(val);
};

let calculate = (n1, n2, callBack) => {
  let sum = n1 + n2;
  if (callBack) {
    callBack(sum);
  }
};

//calculate(20,30,CallBack Function)
calculate(20, 30, display); //50

//calculate(20,30,Annonimus CallBack Function)
calculate(20, 30, function (v) {
  console.log(v * 2);
}); //100
