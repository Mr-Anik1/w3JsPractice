let sum = (v) => v + 2;
let sub = (v) => v - 1;
let mul = (v) => v * 5;

//It's not function composition
//console.log(mul(sub(sum(5))))//30

let compos =
  (...fns) =>
  (val) =>
    fns.reduce((acc, fn) => fn(acc), val);
let res = compos(sum, sub, mul);
//console.log(res(5));//30

//above code work this way...
function nCompos(...fns) {
  return function (val) {
    return fns.reduce(function (acc, curFn) {
      return curFn(acc);
    }, val);
  };
}

let result = nCompos(sum, sub, mul);
//console.log(result(5));//30

/*
   এখানে acc-->val বিদ্যমান তাই প্রথম accmulator হবে val 
    
   acc    --------------   curFn   ------------   newAcc
 val বা 5                   sum()                 sum(5)
 sum(5)                    sub()               sub(sum(5))
 sub(sum(5))               mul()              mul(sub(sum(5)))
    
আর যেহেতু curFn নেই তাই রেজাল্ট হবে acc বা  mul(sub(sum(5)))
*/

//word count
let pipe =
  (...fns) =>
  (str) =>
    fns.reduce((acc, curFn) => curFn(acc), str);

let strArr = (str) => str.split(" ");
let count = (arr) => arr.length;

let wordCount = pipe(strArr, count);

let myString = "Hello my name is anik from Bangladesh";
console.log(wordCount(myString)); //7
