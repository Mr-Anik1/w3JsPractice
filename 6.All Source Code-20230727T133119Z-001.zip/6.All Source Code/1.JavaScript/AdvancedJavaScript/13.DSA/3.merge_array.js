let helperMerge = (leftArr, rightArr) => {
  let finalArr = [];

  let leftArrIndex = 0;
  let rightArrIndex = 0;
  let finalArrIndex = 0;

  while (leftArrIndex < leftArr.length && rightArrIndex < rightArr.length) {
    if (leftArr[leftArrIndex] < rightArr[rightArrIndex]) {
      finalArr[finalArrIndex] = leftArr[leftArrIndex];
      leftArrIndex++;
      finalArrIndex++;
    } else {
      finalArr[finalArrIndex] = rightArr[rightArrIndex];
      rightArrIndex++;
      finalArrIndex++;
    }
  }

  while (leftArrIndex < leftArr.length) {
    finalArr[finalArrIndex] = leftArr[leftArrIndex];
    leftArrIndex++;
    finalArrIndex++;
  }

  while (rightArrIndex < rightArr.length) {
    finalArr[finalArrIndex] = rightArr[rightArrIndex];
    rightArrIndex++;
    finalArrIndex++;
  }

  return finalArr;
};

let myMergeArray = (arr1, arr2) => {
  let testArr = arr1.concat(arr2);

  //Recursive Function
  let mergeArray = (testArr) => {
    if (testArr.length <= 1) {
      return testArr;
    }

    let mid = Math.floor(testArr.length / 2);
    let leftArr = testArr.slice(0, mid);
    let rightArr = testArr.slice(mid);

    return helperMerge(mergeArray(leftArr), mergeArray(rightArr));
  };

  //final answer
  return mergeArray(testArr);
};

console.log(myMergeArray([1, 5, 9, 0, 3, 7], [2, 6, -1, 4, 8]));
//[ -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
