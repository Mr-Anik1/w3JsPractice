/**
 * @Problem - 1
 * #1 Turn this array into a new array: [1,2,3,[4],[5]]. Bonus if you can do it on one line
 */

const array = [[1], [2], [3], [[[4]]], [[[5]]]];
//console.log(array.flat(2));
//[ 1, 2, 3, [ 4 ], [ 5 ] ]

/**
 * @Problem - 2
 * #2 Turn this array into a new array: [ 'Hello young grasshopper!', 'you are', 'learning fast!' ]
 */

const greeting = [
  ["Hello", "young", "grasshopper!"],
  ["you", "are"],
  ["learning", "fast!"],
];
//console.log(greeting.flatMap((v) => v.join(" ")));
//[ 'Hello young grasshopper!', 'you are', 'learning fast!' ]

/**
 * @Problem - 3
 * #3 Turn the greeting array above into a string: 'Hello young grasshopper you are learning fast!'
 */

//console.log(greeting.flat().join(" "));
//Hello young grasshopper! you are learning fast!

/**
 * @Problem - 4
 *  #4 Turn the below users (value is their ID number) into an array: [ [ 'user1', 18273 ], [ 'user2', 92833 ], [ 'user3', 90315 ] ]
 */
const users = { user1: 18273, user2: 92833, user3: 90315 };
//console.log(Object.entries(users));
//[ [ 'user1', 18273 ], [ 'user2', 92833 ], [ 'user3', 90315 ] ]

/**
 * @Problem - 5
 *  #5 change the output array of the above to have the user's IDs multiplied by 2 -- Should output:[ [ 'user1', 36546 ], [ 'user2', 185666 ], [ 'user3', 180630 ] ]
 */
let doubleArr = [];
for (let [k, v] of Object.entries(users)) {
  doubleArr.push([k, v * 2]);
}
//console.log(doubleArr);
//[ [ 'user1', 36546 ], [ 'user2', 185666 ], [ 'user3', 180630 ] ]

/**
 * @Problem - 6
 *  #6 change the output array of question #5 back into an object with all the users IDs updated to their new version. Should output: { user1: 36546, user2: 185666, user3: 180630 }
 */

//console.log(Object.fromEntries(doubleArr));
//{ user1: 36546, user2: 185666, user3: 180630 }

/**
 * @Problem - 7
 *  #7 Clean up this email to have no whitespaces. Make the answer be in a single line (return a new string):
const userEmail3 = '     cannotfillemailformcorrectly@gmail.com   '
 */

const userEmail3 = "     cannotfillemailformcorrectly@gmail.com   ";
//console.log(userEmail3.trim());
//cannotfillemailformcorrectly@gmail.com
