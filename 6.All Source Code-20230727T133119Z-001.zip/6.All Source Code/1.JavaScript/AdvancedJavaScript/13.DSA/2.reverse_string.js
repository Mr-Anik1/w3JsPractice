/**
 * @Reverse_String_With_Builtin_Method
 * 4.41ms
 */
console.time("First");
let reverseString = (str) => str.split("").reverse().join("");
console.log(reverseString("Hi My name is Andrei"));
console.timeEnd("First"); //4.41ms

/**
 *
 * @Reverse_String_Without_Builtin_Method
 * 0.127ms
 * ~30 times faster than previous function
 *
 */
console.time("ano");
let goodReverse = (str) => {
  let nStr = "";
  for (let i = str.length - 1; i >= 0; i--) {
    nStr += str[i];
  }
  return nStr;
};
console.log(goodReverse("Hi My name is Andrei"));
console.timeEnd("ano"); //0.127ms
