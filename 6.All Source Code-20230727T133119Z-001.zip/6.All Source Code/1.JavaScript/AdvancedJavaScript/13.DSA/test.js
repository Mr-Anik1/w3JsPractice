/**
 *
 *
 * @It_is_not_right_way_to_merge_sort
 * @Do_not_use_this
 * @Udemy_Instructor_Andrei_Give_this_Solution
 *
 *
 */

let mergeArr = (arr1, arr2) => {
  let finalMerge = [];
  let i = 1;
  let j = 1;
  let arr1Item = arr1[0];
  let arr2Item = arr2[0];

  if (arr1.length === 0) {
    return arr2;
  }

  if (arr2.length === 0) {
    return arr1;
  }

  while (arr1Item || arr2Item) {
    if (!arr2Item || arr1Item < arr2Item) {
      //great logic
      finalMerge.push(arr1Item);
      arr1Item = arr1[i];
      i++;
    } else {
      finalMerge.push(arr2Item);
      arr2Item = arr2[j];
      j++;
    }
  }

  return finalMerge;
};

//console.log(mergeArr([0, 3, 4, 31], [4, 6, 30]));
//[ 0,  3,  4, 4, 6, 30, 31 ]

/*
let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
let nArr = [];
for (let i = 0; i < arr.length; i++) {
  nArr.push([i, arr[i]]);
}
console.log(nArr);
let objt = Object.fromEntries(nArr);
*/

class GoodHash {
  constructor(size) {
    this.mainArr = new Array(size);
    this.mainArrLength = size;
  }

  #hash(key) {
    let total = 0;
    for (let i = 0; i < key.length; i++) {
      total += key.charCodeAt(i);
    }
    return total % this.mainArrLength;
  }

  set(key, value) {
    let index = this.#hash(key);
    let bucket = this.mainArr[index];

    if (!bucket) {
      this.mainArr[index] = [[key, value]];
    } else {
      let sameKeyItem = bucket.find((item) => item[0] === key);
      if (sameKeyItem) {
        sameKeyItem[1] = value;
      } else {
        bucket.push([key, value]);
      }
    }
  }

  get(key) {
    let index = this.#hash(key);
    let bucket = this.mainArr[index];

    if (bucket) {
      let sameKeyItem = bucket.find((item) => item[0] === key);
      if (sameKeyItem) {
        return sameKeyItem[1];
      }
    }
    return undefined;
  }

  remove(key) {
    let index = this.#hash(key);
    let bucket = this.mainArr[index];

    if (bucket.length <= 1) {
      this.mainArr[index] = undefined;
    } else if (bucket) {
      let sameKeyItem = bucket.find((item) => item[0] === key);
      if (sameKeyItem) {
        let deleteIndex = bucket.indexOf(sameKeyItem);
        bucket.splice(deleteIndex, 1);
      }
    }
  }

  display() {
    let arr = [];
    for (let i = 0; i < this.mainArr.length; i++) {
      arr.push(i, this.mainArr[i]);

      //Only Keys
      // if (this.mainArr[i]) {
      //   this.mainArr[i].map((v) => arr.push(v[0]));
      // }
    }
    return arr;
  }
}

// let go = new GoodHash(50);

// go.set("Name", "Anik");
// go.set("BirthYear", 2002);
// go.set("Age", 20);
// go.set("Aeg", 2003);
// go.set("eAg", 2006);
// go.set("egA", 2004);
// go.set("ameN", "Goo");

// console.log(go.display());

// go.remove("egA");
// go.remove("eAg");
// go.remove("Age");
//go.remove("Aeg");

//  go.remove("BirthYear");
//go.remove("ameN");
// go.remove("Name");

//console.log(go.display());
// console.log(go.get("Name"));
//const myTable=new HashTable()

//[2,1,3,4,2,3,4,5]=>2 bestFirstRecurring

/**
 *
 * @Best_Solution
 * @First_Recurring
 *
 */

let bestFirstRecurring = (arr) => {
  let map = {};
  for (let i = 0; i < arr.length; i++) {
    if (map[arr[i]] !== undefined) {
      return arr[i];
    } else {
      map[arr[i]] = i;
    }
  }
  return undefined;
};

// console.log(bestFirstRecurring([2, 3, 4, 69, 5, 69, 4, 2, 1, 3, 4, 5])); //69
// console.log(bestFirstRecurring([2, 5, 1, 2, 3, 5, 1, 2, 4])); //2
// console.log(bestFirstRecurring([2, 1, 1, 2, 3, 5, 1, 2, 4])); //1
// console.log(bestFirstRecurring([1, 2, 3, 4])); //undefined

let mySet = new Set([1, 2, 3, 1, 2, 3, 2, 2, 2, 1, 1, 1, 2, 3, 3, 3, 2]);
// mySet.add(4);
// console.log(mySet);

// console.log(Array.from(mySet));

//switch case
let switchCase = (direction) => {
  let go;
  switch (direction) {
    case "forward":
      go = "Go to school";
      break;
    case "back":
      go = "Back to home";
      break;
    case "sleep":
      go = "Go to sleep";
      break;
    default:
      go = "Please enter valid direction";
  }
  return go;
};

// console.log(switchCase("sleesp"));

//Object Destructuring
const obj1 = {
  player: "Bobby",
  userLevel: 100,
  experiance: false,
};

let { player, userLevel, experiance } = obj1;
//console.log(experiance);

//Array Destructuring
let arr = [47, 2, 3];
let [ak, be, cl] = arr;
//console.log(cl);

//New Way Declearing object property
const nam = "Anik";
const obj2 = {
  [nam]: "Hello",
  ["age"]: 60,
};

//nam is dynamic
obj2[nam] = "Casper";
obj2["age"] = 20;
obj2["boo"] = "Oh Boy";

//console.log(obj2);
//{ Anik: 'Casper', age: 20, boo: 'Oh Boy' }

//In Object if key and value is same then don't write double
const a1 = "Bob";
const b1 = "Morter";
const c1 = "Silika";

let newObj = {
  a1,
  b1,
  c1,
  //Don't write this way => a1:a1
};

//console.log(newObj);
//{ a1: 'Bob', b1: 'Morter', c1: 'Silika' }

//a1 is not dynamic because of I use "a1" if a1 is dynamic then I use newObj[a1]
newObj["a1"] = "Anik";

//console.log(newObj);
//{ a1: 'Anik', b1: 'Morter', c1: 'Silika' }

/**
 * @Advanced_Function_Concept
 */
// *clouser
// *curring
// *compose
// *pure function

//Advanced Object
let obj = {
  a: 20,
  b: {
    bb: "Hello",
    thisB() {
      return this; //refer b Object
    },
    cc: "Good C",
  },
  d: "DD..",
  c() {
    return this; //refer obj Object
  },
};
//console.log(obj.b.thisB());

//Class

class Player {
  constructor(name, type) {
    console.log("1.Player this", this); //In here What's this refer ?
    this.name = name;
    this.type = type;
  }

  play() {
    return `Hello I'm ${this.name} and I'm ${this.type}`;
  }
}

//Must call super constructor in derived class before accessing 'this' or returning from derived constructor
class Wizerd extends Player {
  constructor(name, type, go) {
    super(name, type);
    console.log("2.Wizerd this", this); //In here What's this refer ?
    this.go = go;
  }

  helloWizerd() {
    return `${this.play()}, I go to ${this.go} `;
  }
}

//let wizerd1 = new Wizerd("Anik", "Black Magician", "School");

// console.log(wizerd1.helloWizerd());
// console.log(wizerd1.play());

/**
 * @String
 */
// console.log("A Hello".codePointAt(0)); //65
// console.log(String.fromCodePoint(65)); //A

// console.log("Anik".charCodeAt(0)); //65
// console.log(String.fromCharCode(65)); //A

//ES7 => includes() and **
//console.log("Hello Anik".includes("A")); //true

//Like Math.pow() method **
//console.log(5 ** 2); //25

let powFunk = (base, power) => base ** power;
//console.log(powFunk(7, 3)); //343 means 7 to the power 3 => 7*7*7

/**
 *
 * @ES 8
 *
 * Object.keys()
 * Object.values()
 * object.entries()
 *
 * padStart()
 * padEnd()
 *
 *
 */

//ES8
let str = "Anik";

//padStart()
//console.log(str.padStart(10)); //     Anik
//10 space before Anik

//padEnd()
//console.log(str.padEnd(10)); //Anik
//Anik with 10 space after it

let myObj = {
  name: "Anik",
  age: 20,
  type: "Programmer",
};

//keys()
//console.log(Object.keys(myObj)); //[ 'name', 'age', 'type' ]

//vlaues()
//console.log(Object.values(myObj)); //[ 'Anik', 20, 'Programmer' ]

// Object to Array => entries()
//console.log(Object.entries(myObj));
//[ [ 'name', 'Anik' ], [ 'age', 20 ], [ 'type', 'Programmer' ] ]

/**
 *
 *
 * @ES 10 (2019)
 *
 * flat()
 * flatMap()
 * trim()
 * fromEntries()
 *
 */

let goArr = [1, 2, 3, , , , 4, 5, 6, , 7, 8];
//console.log(goArr.flat());
//[ 1, 2, 3, 4, 5, 6, 7, 8 ] => remove empty item

let myArr = [1, 2, [3, 4, [5, 6, 7], 8, 9], 10, 11];
//console.log(myArr.flat(2));
//[ 1, 2, 3, 4,  5, 6, 7, 8, 9, 10, 11 ]

/**
 * @My_Hand_Made_Flat_Like_Function
 */
let myFlat = (arr) => {
  let nArr = [];
  for (let i = 0; i < arr.length; i++) {
    if (Array.isArray(arr[i])) {
      nArr = nArr.concat(myFlat(arr[i]));
    } else {
      nArr.push(arr[i]);
    }
  }
  return nArr;
};

//console.log(myFlat(myArr));
//[ 1, 2, 3, 4,  5, 6, 7, 8, 9, 10, 11 ]

let boom = [
  1,
  2,
  [3, 4, [5, 6, [7, 8, [9, 10], 11, 12], 13, 14], 15, 16],
  17,
  18,
  19,
  20,
];

let deepFlat = (arr) => {
  return [].concat(...arr.map((v) => (Array.isArray(v) ? deepFlat(v) : v)));
};

//console.log(deepFlat(boom));
//[ 1,  2,  3,  4,  5,  6,  7, 8,  9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 ]

/**
 * @Another_Way_with_reduce_method
 */
let flaten = (arr) =>
  arr.reduce(
    (acc, cur) => acc.concat(Array.isArray(cur) ? flaten(cur) : cur),
    []
  );

//console.log(flaten(boom));
//[ 1,  2,  3,  4,  5,  6,  7, 8,  9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 ]

//console.log("     anik.com   ".trim()); //anik.com

//Array to Object
let twoDimentional = [
  [0, "One"],
  [1, "Two"],
  [3, "Three"],
];

//console.log(Object.fromEntries(twoDimentional));
//{ '0': 'One', '1': 'Two', '3': 'Three' }

/**
 *
 * @ES 2020
 *
 * BigInt
 * Nullish Coalescing => ??
 * Optional Chaining => ?.
 *
 */

/**
 *
 * @Not_from_ES 2020
 * @Ternary_Operator => ?
 * like if else statement
 *
 */

// ?

/**
 *
 * @Nullish_Coalescing => ??
 * It doesn't check falsy it checks only null or undefined
 * If first value is null or undefined then result is second value otherwise result is first value
 *
 */

let a = null;
let b = undefined;
let c = "Hello Nullish Coalescing";

let test2 = a ?? b;
//console.log(test2); //undefined
//First value a is null so the result is second value that is undefined

let test = a ?? b ?? c;
//console.log(test); //Hello Nullish Coalescing
//In here the first value is null so it go the next vlaue and check the second one here that is b and it is undefined so result is the next one that is c

/**
 *
 * @Optional_Chaining => ?.
 * If statement is false then it returns undefined
 *
 */
let cat = {
  detail: {
    name: "Cat",
    play: true,
    walk: "Yes it walks",
  },
  type: "animal",
};

//console.log(cat?.detail?.walk); //Yes it walks
//(cat && cat.detail && cat.detail.walk) => Boring Approch

let fish = {
  fishDetail: {
    name: "Fish",
    play: true,
    walk: "No",
  },
  type: "fisheris",
};

//console.log(fish?.detail?.walk); //undefined
//(fish && fish.detail && fish.detail.walk) => Boring Approch

/**
 * @globalThis
 * It is working outside of browser
 */

/**
 *
 * @ES 2021
 * replaceAll("targetedItem","newItem")
 *
 */
let newStr = "Udemy is best of the best";
//console.log(newStr.replaceAll("best", "worst"));
//Udemy is worst of the worst
