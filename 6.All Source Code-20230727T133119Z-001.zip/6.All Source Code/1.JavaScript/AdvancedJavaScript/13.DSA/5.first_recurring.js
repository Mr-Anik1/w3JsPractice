/**
 *
 * @Best_Solution
 * @First_Recurring_Using_HashMap_or_Object
 * Its time complexity is O(n)
 *
 */

let bestFirstRecurring = (arr) => {
  let map = {};
  for (let i = 0; i < arr.length; i++) {
    if (map[arr[i]] !== undefined) {
      return arr[i];
    } else {
      map[arr[i]] = i;
    }
  }
  return undefined;
};

console.log(bestFirstRecurring([2, 3, 4, 69, 5, 69, 4, 2, 1, 3, 4, 5])); //69
console.log(bestFirstRecurring([2, 5, 1, 2, 3, 5, 1, 2, 4])); //2
console.log(bestFirstRecurring([2, 1, 1, 2, 3, 5, 1, 2, 4])); //1
console.log(bestFirstRecurring([1, 2, 3, 4])); //undefined

/*






-------------/////---------/////----------//////---------------






*/

/**
 *
 * @First_Recurring_Character_Using_Array
 * @It_is_not_good_approce
 * Its time complexity is O(n^2)
 *
 */

let recurringFunk = (arr) => {
  let nArr = [];
  let allIndex = [];
  for (let i = 0; i < arr.length; i++) {
    for (let j = i + 1; j < arr.length; j++) {
      if (arr[i] === arr[j]) {
        nArr.push([j, arr[i]]);
        allIndex.push(j);
        break;
      }
    }
  }

  if (nArr.length >= 1) {
    let minIndex = Math.min(...allIndex);
    let targetItem = nArr.find((item) => item[0] === minIndex);
    return targetItem[1];
  } else {
    return undefined;
  }
};

console.log(recurringFunk([2, 3, 4, 69, 5, 69, 4, 2, 1, 3, 4, 5])); //69
console.log(recurringFunk([2, 5, 1, 2, 3, 5, 1, 2, 4])); //2
console.log(recurringFunk([2, 1, 1, 2, 3, 5, 1, 2, 4])); //1
console.log(recurringFunk([1, 2, 3, 4])); //undefined

/*





-------------/////---------/////----------//////---------------





*/

/**
 *
 * @Another_Way
 * @recurringFunk_updated_version
 * Its time complexity is O(n^2)
 *
 */

let recurringFunk2 = (arr) => {
  let allIndex = [];
  for (let i = 0; i < arr.length; i++) {
    for (let j = i + 1; j < arr.length; j++) {
      if (arr[i] === arr[j]) {
        allIndex.push(j);
        break;
      }
    }
  }

  if (allIndex.length >= 1) {
    return arr[Math.min(...allIndex)];
  } else {
    return undefined;
  }
};

console.log(recurringFunk2([2, 3, 4, 69, 5, 69, 4, 2, 1, 3, 4, 5])); //69
console.log(recurringFunk2([2, 5, 1, 2, 3, 5, 1, 2, 4])); //2
console.log(recurringFunk2([2, 1, 1, 2, 3, 5, 1, 2, 4])); //1
console.log(recurringFunk2([1, 2, 3, 4])); //undefined

/*





-------------/////---------/////----------//////---------------





*/

/**
 * @Another_Way_Using_Set
 */

const findFirstRecurring = (arr) => {
  const set = new Set();
  for (let i = 0; i < arr.length; i++) {
    if (set.has(arr[i])) {
      return arr[i];
    }
    set.add(arr[i]);
  }
  return undefined;
};

console.log(findFirstRecurring([2, 3, 4, 69, 5, 69, 4, 2, 1, 3, 4, 5])); //69
console.log(findFirstRecurring([2, 5, 1, 2, 3, 5, 1, 2, 4])); //2
console.log(findFirstRecurring([2, 1, 1, 2, 3, 5, 1, 2, 4])); //1
console.log(findFirstRecurring([1, 2, 3, 4])); //undefined
