/**
 * @Hash_Table_Exclusive
 */

class HashTable {
  constructor(size) {
    this.table = new Array(size);
    this.tableLength = size;
  }

  //Hash is a private function and it retuns index
  #hash(key) {
    let total = 0;
    for (let i = 0; i < key.length; i++) {
      total += key.charCodeAt(i);
    }
    return total % this.tableLength;
  }

  set(key, value) {
    let index = this.#hash(key);
    let bucket = this.table[index];
    if (!bucket) {
      this.table[index] = [[key, value]];
    } else {
      let sameKeyItem = bucket.find((item) => item[0] === key);
      if (sameKeyItem) {
        sameKeyItem[1] = value;
      } else {
        bucket.push([key, value]);
      }
    }
  }

  get(key) {
    let index = this.#hash(key);
    let bucket = this.table[index];
    if (bucket) {
      let sameKeyItem = bucket.find((item) => item[0] === key);
      if (sameKeyItem) {
        return sameKeyItem[1];
      }
    }
    return undefined;
  }

  remove(key) {
    let index = this.#hash(key);
    let bucket = this.table[index];
    if (bucket) {
      if (bucket.length <= 1) {
        this.table[index] = undefined;
      } else {
        //if bucket is exist then we check the target key and find target array with key-value pair
        let sameKeyItem = bucket.find((item) => item[0] === key);
        if (sameKeyItem) {
          let deleteIndex = bucket.indexOf(sameKeyItem);
          bucket.splice(deleteIndex, 1);
          //remove
        }
      }
    }
  }

  display() {
    let arr = [];
    for (let i = 0; i < this.table.length; i++) {
      // arr.push([i, this.table[i]]);
      arr.push(i, this.table[i]);
    }
    // return Object.fromEntries(arr);
    return arr;
  }
}

let myHashTable = new HashTable(50);
myHashTable.set("Name", "Anik");
myHashTable.set("Age", 20); //same Index
myHashTable.set("BirthYear", 2002);

myHashTable.set("Naem", "Manik");
myHashTable.set("Aeg", 2003); //same Index
myHashTable.set("eAg", 2006); //same Index
myHashTable.set("egA", 2004); //same Index

myHashTable.remove("egA");
myHashTable.remove("eAg");
myHashTable.remove("Aeg");
//myHashTable.remove("Age");
myHashTable.remove("Naem");
// myHashTable.remove("Ntrefhgfyaem");

console.log(myHashTable.display());
//console.log(myHashTable.get("Age")
// myHashTable.set("Hello", "Anik");
// console.log(myHashTable.get("Hello"));
