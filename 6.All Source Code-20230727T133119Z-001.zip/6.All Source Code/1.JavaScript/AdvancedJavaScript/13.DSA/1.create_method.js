class MyArray {
  constructor() {
    this.length = 0;
    this.data = {};
  }

  get(index) {
    return this.data[index];
  }

  push(item) {
    this.data[this.length] = item;
    this.length++;
  }

  pop() {
    delete this.data[this.length - 1];
    this.length--;
  }

  myDelete(index) {
    delete this.data[index];
    this.#shiftItem(index);
  }

  //shiftItem is a private method which is access only inside the MyArray class
  #shiftItem(index) {
    for (let i = index; i < this.length - 1; i++) {
      this.data[i] = this.data[i + 1];
    }
    delete this.data[this.length - 1];
    this.length--;
  }

  shift() {
    this.myDelete(0);
  }

  unshift(item) {
    this.#unshiftItem(0);
    this.data[0] = item;
  }

  #unshiftItem(index) {
    let copyData = { ...this.data };
    for (let i = index; i < this.length; i++) {
      this.data[i + 1] = copyData[i];
    }
    this.length++;
  }

  middlePush(index, item) {
    this.#unshiftItem(index);
    this.data[index] = item;
  }
}

let go = new MyArray();
go.push("One");
go.push("Two");
go.push("Three");
go.push("Four");
go.push("Five");
console.log(go);
/*
  MyArray {
  length: 5,
  data: { '0': 'One', '1': 'Two', '2': 'Three', '3': 'Four', '4': 'Five' }
}

*/

go.shift(); //Delete first item
console.log(go);
/*
  MyArray {
  length: 4,
  data: { '0': 'Two', '1': 'Three', '2': 'Four', '3': 'Five' }
}
*/

go.unshift("one");
go.unshift("Zero");
console.log(go);
/*
  MyArray {
  length: 6,
  data: {
    '0': 'Zero',
    '1': 'one',
    '2': 'Two',
    '3': 'Three',
    '4': 'Four',
    '5': 'Five'
  }
}
*/

go.pop();
go.pop();
console.log(go);
/*
  MyArray {
  length: 4,
  data: { '0': 'Zero', '1': 'one', '2': 'Two', '3': 'Three' }
 }
*/

go.myDelete(2);
go.myDelete(1);
console.log(go);
/*
  MyArray { length: 2, data: { '0': 'Zero', '1': 'Three' } }
*/

//This way I can push item in the middle of the array like obj
go.middlePush(1, "One");
go.middlePush(2, "Two");
console.log(go);
/*
  MyArray {
  length: 4,
   data: { '0': 'Zero', '1': 'One', '2': 'Two', '3': 'Three' }
  }
*/

//Object to array [only store Object value]
let arr = [];
for (let [i, v] of Object.entries(go.data)) {
  arr.push(v);
}
console.log(arr); //[ 'Zero', 'One', 'Two', 'Three' ]

//Array to Object
let obj = arr.reduce((acc, cur, i = 0) => {
  acc[i] = cur;
  i++;
  return acc;
}, {});
console.log(obj); //{ '0': 'Zero', '1': 'One', '2': 'Two', '3': 'Three' }
