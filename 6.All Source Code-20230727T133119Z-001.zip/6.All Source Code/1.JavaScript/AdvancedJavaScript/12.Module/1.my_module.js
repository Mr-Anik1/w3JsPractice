export function person(nam, age) {
  return `My name is ${nam} and I'm ${age} years old.`;
}
