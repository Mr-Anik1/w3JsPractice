/**
 * 
 When I use `npn init`, a package.json file is created.
 * 
 This line `"type": "module"` must be in the package.json file
 * 
 */

import { person } from "./1.my_module.js";
import { got, test } from "./2.go.js";

console.log(person("Anik", 20)); //My name is Anik and I'm 20 years old.

/**
 * @got_and_test_from_Same_file
 */
console.log(got("MySchool")); //My school name is MySchool
console.log(test("Chemical Reaction")); //My test is Chemical Reaction
