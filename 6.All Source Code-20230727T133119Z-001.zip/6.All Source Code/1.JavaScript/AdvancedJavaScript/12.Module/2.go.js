function got(sch) {
  return `My school name is ${sch}`;
}

let test = (tstName) => `My test is ${tstName}`;

//Export what I need
export { got, test };
