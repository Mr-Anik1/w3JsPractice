let dragon = {
  name: "ToTo Dragon",
  age: 20,
  sing() {
    return `I am ${this.name} and I am singing at the age of ${this.age}...`;
  },
};

let lizard = {
  name: "KiDo Lizard",
  //age: 3,
};
// let lez = dragon.sing.bind(lizard);
// console.log(lez());

//You should never use this __proto__
//Prototype Inheritance
lizard.__proto__ = dragon;

//Lizard does not have a sing() method; he obtained it from dragon.
console.log(lizard.sing()); //I am KiDo Lizard and I am singing at the age of 20...

console.log(lizard.age); //20 is from his ancestors' dragons, and lizards access it.

console.log(dragon.isPrototypeOf(lizard)); //20
//dragon is the prototype of lizard
//or
//lizard inherit from dragon

for (let prop in lizard) {
  console.log(prop); //Dragon and Lizard all property
  //name
  //age
  //sing
}

for (let prop in lizard) {
  if (lizard.hasOwnProperty(prop)) {
    //Only Lizard property
    console.log(prop); //name
  }
}

//For the Line Gap
console.log(`
`);
/*


--------------------------|||||||-----------------------------


*/
/**
 * @we_should_never_use
 */

let dat = new Date("1900-10-10");

//Date() does not have getLastYear() method I add this manually for learning purposes, but it should never be used in a real-life project.
dat.getLastYear = function () {
  return dat.getFullYear() - 1;
};

//one-line solution using the Arrow function
//dat.getLastYear = () => dat.getFullYear() - 1;

console.log(dat.getLastYear()); //1899

/**
 * @Another_Way
 */
//Or we can solve this problem in this way...

// Date.prototype.lastYear = function () {
//   return this.getFullYear() - 1;
// };

// let nDate = new Date("2000-10-10");
// console.log(nDate.lastYear());//1999

/**
 * @Another_Funny_Array_mapA_method
 */
Array.prototype.mapA = function () {
  let arr = [];
  for (let i = 0; i < this.length; i++) {
    arr.push(`${this[i]}:)`);
  }
  return arr;
};

console.log([1, 2, 3, 4, 5].mapA()); //[ '1:)', '2:)', '3:)', '4:)', '5:)' ]

let arra = [7, 8, 9];
console.log(arra.mapA()); //[ '7:)', '8:)', '9:)' ]

//Real one
console.log(arra.map((v) => v)); //[ 7, 8, 9 ]
