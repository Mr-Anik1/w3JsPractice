let deciVal = 10;

//Decimal to Binary => deciVal.toString(2)
console.log(deciVal.toString(2)); //1010

//Decimal to Octal => deciVal.toString(8)
console.log(deciVal.toString(8)); //012

//Decimal to Hexadecimal => deciVal.toString(16)
console.log(deciVal.toString(16)); //a

//Binary to Decimal => parseInt(binVal,2)
console.log(parseInt("1010", 2)); //10

//Octal to Decimal => parseInt(octVal,8)
console.log(parseInt("12", 8)); //10
console.log(parseInt("012", 8)); //10

//Hexadecimal to Decimal => parseInt(hexaVal,16)
console.log(parseInt("a", 16)); //10

/**
 * @Simple_Number_Converter_Function
 */
let converter = (bin) => {
  let dec = parseInt(`${bin}`, 2);
  let oct = dec.toString(8);
  let hexa = dec.toString(16);

  return `Binary:${bin} equivalent to Decimal: ${dec}, Octal: ${oct} and HexaDecimal: ${hexa}`;
};

// console.log(converter(1010));
// console.log(converter(1100100));
