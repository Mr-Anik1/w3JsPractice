/**
 *
 *@Sopping_Cart_Using_Function_Composition
 *
 *@Little_bit_hard
 *
 */

let compos =
  (f, g) =>
  (...args) =>
    f(g(...args));

function purchaseItem(...fns) {
  return fns.reduce(compos);
}

//sopping cart is going to be empty
function emptyCart(user) {
  return Object.assign({}, user, { cart: [] });
}

//Decided to buy item
function buyItem(user) {
  let updatePurchase = user.cart;
  return Object.assign({}, user, { purchase: updatePurchase });
}

//Tax
function applyTaxToItem(user) {
  let { cart } = user;
  let updateCartPrice = cart.map((itm) => {
    return Object.assign({}, itm, { price: itm.price * 1.3 });
  });

  return Object.assign({}, user, { cart: updateCartPrice });
}

//Item is adding to cart
function addItemToCart(user, ...item) {
  let updateCart = user.cart.concat(item);
  return Object.assign({}, user, { cart: updateCart });
}

//Purchase is being processed.
let processPurchase = purchaseItem(
  emptyCart,
  buyItem,
  applyTaxToItem,
  addItemToCart
);

let user = { name: "Anik", active: true, cart: [], purchase: [] };
let item = [
  { name: "Laptop", price: 1000 },
  { name: "Phone", price: 120 },
  { name: "Mango", price: 45 },
];

let finalResult = processPurchase(user, ...item);
console.log(finalResult);
/*

{
   name: 'Anik',
   active: true,
   cart: [],
   purchase: [
         { name: 'Laptop', price: 1300 },
         { name: 'Phone', price: 156 },
         { name: 'Mango', price: 58.5 }
    ]
}

*/

/**
 * @How_to_works_this_code
 */

/*

The reduce method takes two arguments: 
a callback function and an initial value. In this case, the initial value for the reduce method is the first function in the fns array, and the callback function is the "compos" function defined earlier.


During each iteration of reduce, two functions from the array are passed as arguments to compos. The first function (f) is the result of the previous iteration (or the initial value on the first iteration), and the second function (g) is the current function being processed.


1.
On the first iteration, f is "emptyCart" and g is "buyItem". compos returns a new function that takes any number of arguments, passes them to g, and then passes the result to f. This new function is then passed to the next iteration of reduce as the accumulated value.

f = emptyCart
g = buyItem

compos(f, g) = (...args) => f(g(...args))

accumulatedValue = compos(f, g) = (...args) => emptyCart(buyItem(...args))




2.
On the second iteration, f is the function returned by the previous iteration ("buyItem" wrapped with "emptyCart"), and g is "applyTaxToItem". compos returns a new function that takes any number of arguments, passes them to g, and then passes the result to the function returned by the previous iteration (buyItem wrapped with emptyCart). This new function is then passed to the next iteration of reduce as the accumulated value.


f = accumulatedValue = compos(emptyCart, buyItem)
g = applyTaxToItem

compos(f, g) = (...args) => f(g(...args))

accumulatedValue = compos(f, g) = (...args) => emptyCart(buyItem(applyTaxToItem(...args)))





3.
On the third and final iteration, f is the function returned by the previous iteration ("applyTaxToItem" wrapped with  "buyItem" wrapped with "emptyCart"), and g is "addItemToCart". compos returns a new function that takes any number of arguments, passes them to g, and then passes the result to the function returned by the previous iteration (applyTaxToItem wrapped with buyItem wrapped with emptyCart). This final function is returned as the result of reduce.


So the final function that is returned by reduce is equivalent to the following function:
(...args) => emptyCart(buyItem(applyTaxToItem(addItemToCart(...args))))


here,
f = accumulatedValue = compos(emptyCart, buyItem, applyTaxToItem)
g = addItemToCart

compos(f, g) = (...args) => f(g(...args))

accumulatedValue = compos(f, g) = (...args) => emptyCart(buyItem(applyTaxToItem(addItemToCart(...args))))



This function takes any number of arguments (representing the user and the items to purchase), applies the functions in the correct order, and returns the resulting object.


*/
