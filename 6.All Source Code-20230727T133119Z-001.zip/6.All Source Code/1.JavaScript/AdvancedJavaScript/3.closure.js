let callMeAgain = () => {
  let call = "Hello User how are you?";
  setTimeout(function () {
    console.log(call); //call from closure
  }, 3000);
};

//callMeAgain();

let heavyWork = () => {
  let bigArr = new Array(40).fill("A"); //It's still alive in the closure box because we have used it within the return function.
  console.log("Created!");
  return function (index) {
    return bigArr[index]; //bigArr from closure
  };
};

let closu = heavyWork();
console.log(closu(21));
console.log(closu(13));
console.log(closu(35));

/**
 * @Explain_Closure_Easy_Way
 */

function parents() {
  let assets = "gold";
  return function () {
    // The child function can access the parent's variable, even though the parent function has been returned. This is possible because of closures.
    console.log(`Now I am the owner of my parent's ${assets}.`);
  };
}

let childFunk = parents(); // The parents function is called, but the childFunk function still has access to all of the parent function's variables.
childFunk();

/*

The parents function defines a variable called assets and then returns an inner function. This inner function, referred to as childFunk, has access to the assets variable even after the parents function has completed execution. This is possible because of the concept of closures in JavaScript.

A closure is created when a function returns another function that references one or more variables from the parent function's scope. In this case, the childFunk function has access to the assets variable from its parent function parents. Therefore, when childFunk is called, it can still access and use the value of assets even though parents has already completed execution.
*/

//For the Line Gap
console.log(`
`);
/*


--------------------------|||||||-----------------------------


*/

/**
 * @Very_Important_Problem
 */

for (var i = 0; i < 5; i++) {
  setTimeout(function () {
    console.log(`The value of i:~: ${i}`);
  }, 2000);
}
/*
It is a problem if i=5 five times.

    The value of i:~: 5
    The value of i:~: 5
    The value of i:~: 5
    The value of i:~: 5
    The value of i:~: 5

*/
//For the asynchronous Line Gap
setTimeout(() => {
  console.log(`
`);
}, 2000);

/**
 * @How_can_I_solve_this_problem
 *
 * We solve this problem in two ways:
 * step 1: Replace the var keyword with let.
 * Step 2: By using closure, we can solve this problem. It is a great idea.
 *
 * @Following_the_code_we_are_going_to_use_Step_2
 *
 */

for (var i = 0; i < 5; i++) {
  (function (closure_I) {
    setTimeout(function () {
      console.log(`The value of i:~: ${closure_I}`);
    }, 3000);
  })(i); //Every time 'i' is used within the function, it is saved in the closure box.
}

/*
 It's working smoothly

  The value of i:~: 0
  The value of i:~: 1
  The value of i:~: 2
  The value of i:~: 3
  The value of i:~: 4

*/
