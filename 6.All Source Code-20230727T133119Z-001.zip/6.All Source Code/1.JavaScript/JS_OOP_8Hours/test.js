class Person {
  constructor(id, name, email, password) {
    this.personId = id;
    this.personName = name;
    this.personEmail = email;
    this.personPassword = password;
  }

  createUser() {
    return {
      id: this.personId,
      name: this.personName,
      email: this.personEmail,
      password: this.personPassword,
    };
  }

  set #resetUserPassword(newPass) {
    this.personPassword = newPass;
  }

  forgotPassword(newPass) {
    this.#resetUserPassword = newPass;

    return `Hello ${this.personName}, your password is being reseted.`;
  }
}

// let p1 = new Person(1, "Anik", "anik@gmail.com", "23453");
// console.log(p1);
// console.log(p1.createUser());

class Student extends Person {
  constructor(id, name, email, password, subjects, fee) {
    super(id, name, email, password);
    this.studentSubjects = subjects;
    this.studentTutionFee = fee;
  }

  result() {
    return {
      ...this.createUser(),
      subjects: this.studentSubjects,
      fee: this.studentTutionFee,
      result: `Fail`,
    };
  }
}

let student1 = new Student(
  "S-02",
  "Manik",
  "manik@gmail.com",
  "23562",
  ["Bangla", "English", "Math", "ICT", "Physics"],
  "5800"
);

// console.log(student1);
// console.log(student1.result());
// console.log(student1.createUser());
// student1.forgotPassword("%y_$47k");
// console.log(student1.result());

class Teacher extends Person {
  constructor(id, name, email, password, subject, salary) {
    super(id, name, email, password);
    this.teacherSubject = subject;
    this.teacherSalary = salary;
  }

  takeClass() {
    return {
      ...this.createUser(),
      subject: this.teacherSubject,
      salary: this.teacherSalary,
      classTime: "11:30 AM",
    };
  }
}

// let teacher1 = new Teacher(
//   "T-004",
//   "Tesla",
//   "tesla@gmail.com",
//   "$#7584Gjf",
//   "Physics",
//   "60900"
// );

// console.log(teacher1);
// console.log(teacher1.createUser());
// console.log(teacher1.takeClass());
// console.log(teacher1.forgotPassword("999"));
// console.log(teacher1.createUser());
