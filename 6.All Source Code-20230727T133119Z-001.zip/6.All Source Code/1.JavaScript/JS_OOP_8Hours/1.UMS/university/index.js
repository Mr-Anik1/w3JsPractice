const { Department } = require("./Department");
const { Subject } = require("./Subject");
const { Exam } = require("./Exam");
const { Account } = require("./Account");

module.exports = { Department, Subject, Exam, Account };
