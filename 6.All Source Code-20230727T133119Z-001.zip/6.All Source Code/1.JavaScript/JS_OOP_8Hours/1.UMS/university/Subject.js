class Subject {
  // #id;
  // #name;
  // #credit;
  constructor({ id, name, credit }) {
    this.id = id;
    this.name = name;
    this.credit = credit || 0;
  }

  get subId() {
    return this.id;
  }

  get subName() {
    return this.name;
  }
  set subName(vlaue) {
    this.name = vlaue;
  }

  get subCredit() {
    return this.credit;
  }
  set subCredit(value) {
    this.credit = value;
  }

  toString() {
    return `
    ID:${this.id},
    Name:${this.name},
    Credit:${this.credit}
    `;
  }
}

module.exports = {
  Subject,
};
