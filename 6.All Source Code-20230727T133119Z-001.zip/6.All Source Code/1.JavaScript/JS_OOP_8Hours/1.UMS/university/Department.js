class Department {
  // #id;
  // #name;
  // #subjects;
  // #dean;
  // #teachers;
  constructor({ id, name, dean }) {
    this.id = id;
    this.name = name;
    this.subjects = [];
    this.dean = dean || null;
    this.teachers = [];
  }

  get dId() {
    return this.id;
  }

  get dName() {
    return this.name;
  }
  set dName(value) {
    this.name = value;
  }

  get dSubjects() {
    return this.subjects;
  }
  set dSubjects(value) {
    this.subjects = value;
  }
  addSubject(subject) {
    this.subjects.push(subject);
  }

  get dDean() {
    return this.dean;
  }
  set dDean(value) {
    this.dean = value;
  }

  get dTeachers() {
    return this.teachers;
  }
  set dTeachers(value) {
    this.teachers = value;
  }
  addTeacher(teacher) {
    this.teachers.push(teacher);
  }

  toString() {
    return `
    ID:${this.id},
    Name:${this.name},
    Subjects:${this.subjects},
    Dean:${this.dean},
    Teachers:${this.teachers}
    `;
  }
}

module.exports = { Department };
