class Exam {
  // #id;
  // #name;
  // #subject;
  // #passMark;
  constructor({ id, name, subject, passMark }) {
    this.id = id;
    this.name = name;
    this.subject = subject;
    this.passMark = passMark || 33;
  }

  get examId() {
    return this.id;
  }

  get examName() {
    return this.name;
  }
  set examName(value) {
    this.name = value;
  }

  get examSubject() {
    return this.subject;
  }
  set examSubject(value) {
    this.subject = value;
  }

  get examPassMark() {
    return this.passMark;
  }
  set examPassMark(value) {
    this.passMark = value;
  }

  toString() {
    return `
    Exam ID:${this.id},
    Exam Name:${this.name},
    Exam Subject:${this.subject},
    Exam PassMark:${this.passMark}
    `;
  }
}

module.exports = { Exam };
