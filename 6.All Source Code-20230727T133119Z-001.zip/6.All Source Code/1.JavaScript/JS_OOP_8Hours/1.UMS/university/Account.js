class Account {
  constructor({ id, type, amount }) {
    this.id = id;
    this.type = type || null;
    this.amount = +amount || 0;
    this.time = new Date().toISOString();
  }

  get accountType() {
    return this.type;
  }
  set accountType(value) {
    this.type = value;
  }

  get accountAmount() {
    return this.amount;
  }
  set accountAmount(value) {
    this.amount = value;
  }
  addAmount(value) {
    this.amount += +value;
  }
}

module.exports = { Account };
