const { Address } = require("./Address");
const { Contact } = require("./Contact");

module.exports = {
  Address,
  Contact,
};
