class Contact {
  // #id;
  // #email;
  // #phone;
  // #alternativePhone;
  // #address;
  constructor({ id, email, phone, alternativePhone, address }) {
    this.id = id;
    this.email = email || "";
    this.phone = phone || "";
    this.alternativePhone = alternativePhone || "";
    this.address = address || null;
  }

  get cId() {
    return this.id;
  }

  get cEmail() {
    return this.email;
  }
  set cEmail(value) {
    this.email = value;
  }

  get cPhone() {
    return this.phone;
  }
  set cPhone(value) {
    this.phone = value;
  }

  get cAlternativePhone() {
    return this.alternativePhone;
  }
  set cAlternativePhone(value) {
    this.alternativePhone = value;
  }

  get cAddress() {
    return this.address;
  }
  set cAddress(value) {
    this.address = value;
  }

  toString() {
    return `
    ID:${this.id},
    Email:${this.email},
    Phone:${this.phone},
    Alternative Phone:${this.alternativePhone},
    Address:${this.address}
    `;
  }
}

module.exports = { Contact };
