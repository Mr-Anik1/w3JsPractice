class Address {
  // #id;
  // #roadNo;
  // #city;
  // #region;
  // #country;
  // #postalCode;
  constructor({ id, roadNo, city, region, country, postalCode }) {
    this.id = id;
    this.roadNo = roadNo || "";
    this.city = city || "";
    this.region = region || "";
    this.country = country || "";
    this.postalCode = postalCode || "";
  }

  get aId() {
    return this.id;
  }

  get aRoadNo() {
    return this.roadNo;
  }
  set aRoadNo(value) {
    this.roadNo = value;
  }

  get aCity() {
    return this.city;
  }
  set aCity(value) {
    this.city = value;
  }

  get aRegion() {
    return this.region;
  }
  set aRegion(value) {
    this.region = value;
  }

  get aCountry() {
    return this.country;
  }
  set aCountry(value) {
    this.country = value;
  }

  get aPostalCode() {
    return this.postalCode;
  }
  set aPostalCode(value) {
    this.postalCode = value;
  }

  toString() {
    return `
    ID:${this.id},
    Road No:${this.roadNo},
    City:${this.city},
    Region:${this.region},
    Country:${this.country},
    Postal Code:${this.postalCode}`;
  }
}

// const c1 = new Address({
//   id: "001",
//   roadNo: "32 byPuss",
//   city: "Gaxipur",
//   region: "Uttor",
//   country: "Banglasesh",
//   postalCode: "00989",
// });

// console.log(c1.aId, c1.aCity);

module.exports = { Address };
