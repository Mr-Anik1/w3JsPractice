const { Uniperson } = require("./Uniperson");

class Employee extends Uniperson {
  // #employeeID;
  // #salary;
  constructor({ id, name, employeeID }) {
    super({ id, name });
    this.employeeID = employeeID || null;
    this.salary = null;
  }

  get eEmployeeId() {
    return this.employeeID;
  }

  get eSalary() {
    return this.salary;
  }
  set eSalary(value) {
    this.salary = value;
  }

  toString() {
    return `${super.toString()}, EmployeeID=${this.employeeID} & Salary=${
      this.salary
    }`;
  }
}

module.exports = { Employee };
