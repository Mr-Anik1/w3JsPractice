const { Employee } = require("./Employee");

class Teacher extends Employee {
  // #subject;
  constructor({ id, name, subject, employeeID }) {
    super({ id, name, employeeID });
    this.subject = subject;
  }

  get tSubject() {
    return this.subject;
  }
  set tSubject(value) {
    this.subject = value;
  }

  toString() {
    return `${super.toString()}, Teacher Subject=${this.subject}`;
  }
}

module.exports = { Teacher };
