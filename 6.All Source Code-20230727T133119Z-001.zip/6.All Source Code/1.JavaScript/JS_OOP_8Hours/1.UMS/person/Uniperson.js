const { Person } = require("./Person");

class Uniperson extends Person {
  // #department;
  // #account;
  constructor({ id, name }) {
    super({ id, name });
    this.department = null;
    this.account = null;
  }

  get uniDepartment() {
    return this.department;
  }
  set uniDepartment(value) {
    this.department = value;
  }

  get uniAccount() {
    return this.account;
  }
  set uniAccount(value) {
    this.account = value;
  }

  toString() {
    return `${super.toString()},
    Department:${this.department},
    Account:${this.account}`;
  }
}

// const u1 = new Uniperson({ id: 9, name: "Manik" });

// console.log(u1.pId, u1.pName, u1.uniAccount, u1.uniDepartment);

// u1.uniAccount = "HelloAccount";
// u1.uniDepartment = "CSE";
// u1.pBlood = "b+";
// console.log(u1.pId, u1.pName, u1.uniAccount, u1.uniDepartment, u1.pBlood);

module.exports = { Uniperson };
