const { Employee } = require("./Employee");

class Stuff extends Employee {
  // #title;
  constructor({ id, name, title }) {
    super({ id, name });
    this.title = title;
  }

  get stuffTitle() {
    return this.title;
  }

  set stuffTitle(value) {
    this.title = value;
  }

  toString() {
    return `${super.toString()}, Stuff Title=${this.title}`;
  }
}

module.exports = { Stuff };
