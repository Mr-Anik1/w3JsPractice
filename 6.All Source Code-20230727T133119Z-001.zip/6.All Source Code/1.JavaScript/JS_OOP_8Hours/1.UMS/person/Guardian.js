const { Person } = require("./Person");

class Guardian extends Person {
  // #profession;
  // #income;
  constructor({ id, name, profession, income }) {
    super({ id, name });
    this.profession = profession;
    this.income = income;
  }

  get guardianProfession() {
    return this.profession;
  }
  set guardianProfession(value) {
    this.profession = value;
  }

  get guardianIncome() {
    return this.income;
  }
  set guardianIncome(value) {
    this.income = value;
  }

  toString() {
    return `
    ${super.toString()},
    Profession:${this.profession},
    Income:${this.income}`;
  }
}

// const guardian = new Guardian({
//   id: "gu-x01",
//   name: "Mr. Anik",
//   profession: "Programmer",
//   income: "150000",
// });

// console.log(guardian.pId, guardian.pName, guardian.pBlood);

// guardian.pBlood = "A+";

// console.log(guardian.pId, guardian.pName, guardian.pBlood);

module.exports = { Guardian };
