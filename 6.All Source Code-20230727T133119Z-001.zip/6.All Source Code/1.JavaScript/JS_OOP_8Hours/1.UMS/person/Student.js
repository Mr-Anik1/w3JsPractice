const { Uniperson } = require("./Uniperson");

class Student extends Uniperson {
  // #studentID;
  // #guardian;
  // #exams;
  // #fee;
  constructor({ id, name, studentId, guardian }) {
    super({ id, name });
    this.studentID = studentId;
    this.guardian = guardian;
    this.exams = [];
    this.fee = null;
  }

  get sStudentId() {
    return this.studentID;
  }

  get sGuardian() {
    return this.guardian;
  }

  get sExams() {
    return this.exams;
  }
  set sExams(value) {
    this.exams = value;
  }
  addExam(exam) {
    this.exams.push(exam);
  }

  get sFee() {
    return this.fee;
  }
  set sFee(value) {
    this.fee = value;
  }

  toString() {
    return `${super.toString()}, Student ID=${this.studentID}`;
  }
}

module.exports = { Student };
