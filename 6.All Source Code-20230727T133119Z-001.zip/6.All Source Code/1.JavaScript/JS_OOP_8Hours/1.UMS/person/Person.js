class Person {
  // #id;
  // #name;
  // #blood;
  // #contact;
  constructor({ id, name }) {
    this.id = id;
    this.name = name;
    this.blood = null;
    this.contact = null;
  }

  get pId() {
    return this.id;
  }

  get pName() {
    return this.name;
  }

  set pName(updateName) {
    this.name = updateName;
  }

  get pBlood() {
    return this.blood;
  }

  set pBlood(updateBlood) {
    this.blood = updateBlood;
  }

  get pContact() {
    return this.contact;
  }

  set pContact(updateContact) {
    this.contact = updateContact;
  }

  toString() {
    return `
    ID:${this.id},
    Name:${this.name}`;
  }
}

// const p1 = new Person("9u9", "Alexa");
// console.log(p1.pName, p1.pId);

// p1.pBlood = "B+";
// p1.pContact = "+88017";

// console.log(p1.pName, p1.pId, p1.pBlood, p1.pContact);

module.exports = { Person };
