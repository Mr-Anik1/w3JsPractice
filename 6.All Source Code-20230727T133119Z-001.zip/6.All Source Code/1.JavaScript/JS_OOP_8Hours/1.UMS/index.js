const { Guardian, Student, Teacher } = require("./person/index");
const { Contact, Address } = require("./contact/index");
const { Department, Subject, Exam, Account } = require("./university/index");

//Guardian Object
const guardian1 = new Guardian({
  id: "gu-x01",
  name: "Mr. Anik",
  profession: "Programmer",
  income: "150000",
});

guardian1.pBlood = "A+";
guardian1.pContact = new Contact({
  id: guardian1.id,
  phone: "+8801786435",
});

// console.log(guardian1.pContact + "");

guardian1.pContact.cAddress = new Address({
  id: guardian1.id,
  roadNo: "3lb konabari",
  city: "Gaixpir",
  region: "Bokshi Pur",
  country: "Bangladesh",
  postalCode: "1701",
});
// console.log(guardian1.pContact + "");

// console.log(guardian1.pContact.cAddress.aCountry);
// console.log(guardian1.pContact.cPhone);
// console.log(guardian1.pBlood);

//console.log(guardian1);
/*

Guardian {
  id: 'gu-x01',
  name: 'Mr. Anik',
  blood: 'A+',
  contact: Contact {
    id: 'gu-x01',
    email: '',
    phone: '+8801786435',
    alternativePhone: '',
    address: Address {
      id: 'gu-x01',
      roadNo: '3lb konabari',
      city: 'Gaixpir',
      region: 'Bokshi Pur',
      country: 'Bangladesh',
      postalCode: '1701'
    }
  },
  profession: 'Programmer',
  income: '150000'
}


*/

//Student-1
const student1 = new Student({
  id: "p-084",
  name: "Alexa",
  studentId: "ST-x09",
  guardian: guardian1,
});

student1.uniDepartment = new Department({
  id: "DP-09xCS",
  name: "Computer Science",
});

student1.sExams = ["Compilar Design"];
student1.addExam("Data Structure & Algorithm");

student1.pBlood = "O-";
student1.sFee = "783000";

student1.pContact = new Contact({
  id: student1.id,
  email: "alexa@gmail.com",
  phone: "+8801845678",
  alternativePhone: guardian1.contact.phone,
  address: guardian1.contact.address,
});

student1.uniDepartment.dDean = "Mr.Anik Vai";
student1.uniDepartment.dTeachers = ["Lal Mia", "Kalu Vai"];
student1.uniDepartment.addTeacher("Tesla Killa");

//console.log(student1);
/*

Student {
  id: 'p-084',
  name: 'Alexa',
  blood: 'O-',
  contact: Contact {
    id: 'p-084',
    email: 'alexa@gmail.com',
    phone: '+8801845678',
    alternativePhone: '+8801786435',
    address: Address {
      id: 'gu-x01',
      roadNo: '3lb konabari',
      city: 'Gaixpir',
      region: 'Bokshi Pur',
      country: 'Bangladesh',
      postalCode: '1701'
    }
  },
  department: Department {
    id: 'DP-09xCS',
    name: 'Computer Science',
    subjects: [ 'CS101', 'Calculas-01', 'CS Fundamental' ],
    dean: 'Mr.Anik Vai',
    teachers: [ 'Lal Mia', 'Kalu Vai', 'Tesla Killa' ]
  },
  account: null,
  studentID: 'ST-x09',
  guardian: Guardian {
    id: 'gu-x01',
    name: 'Mr. Anik',
    blood: 'A+',
    contact: Contact {
      id: 'gu-x01',
      email: '',
      phone: '+8801786435',
      alternativePhone: '',
      address: [Address]
    },
    profession: 'Programmer',
    income: '150000'
  },
  exams: [ 'Compilar Design', 'Data Structure & Algorithm' ],
  fee: '783000'
}


*/

/**
 * @Student_2
 */
const student2 = new Student({
  id: "p-072",
  name: "Veronica",
  studentId: "ST-x054",
  guardian: guardian1,
});

student2.pBlood = "B+";

student2.pContact = new Contact({
  id: student2.id,
  email: "veronica@gmail.com",
  phone: "+331942206",
  alternativePhone: student2.guardian.contact.phone,
  address: student2.guardian.contact.address,
});

/**
 * @Department_1
 */
const department1 = new Department({
  id: "DP-x7CS",
  name: "SWE",
});

student2.uniDepartment = department1;

/**
 * @Subjects
 */
const subject1 = new Subject({ id: 101, name: "CS Fundamental", credit: 3 });
const subject2 = new Subject({ id: 103, name: "Calculus101", credit: 4 });
const subject3 = new Subject({ id: 102, name: "Software Testing", credit: 2 });
const subject4 = new Subject({ id: 202, name: "Compilar Design", credit: 4 });
const subject5 = new Subject({
  id: 404,
  name: "Data Structure & Algorithmn",
  credit: 5,
});

//Add One Subject
department1.addSubject(subject1);
//[Danger Zone] set all subject -> new subjects overlape previous one
department1.dSubjects = [subject1, subject2, subject3, subject4, subject5];

/**
 * @Dean
 */
const dean = new Teacher({
  id: "t-128",
  name: "Thomson",
  subject: department1.subjects[0],
  employeeID: "EM-01",
});

department1.dDean = dean;

dean.pBlood = "O+";
dean.eSalary = 123000;
dean.pContact = new Contact({
  id: dean.id,
  email: "thomson@gamil.com",
  phone: "+8892148649",
  alternativePhone: "+3295865819",
});

dean.pContact.cAddress = new Address({
  id: dean.id,
  roadNo: "Bijoy Soroni",
  city: "Dhaka",
  region: "Uttor",
  country: "Bangladesh",
  postalCode: "1201",
});

dean.uniDepartment = department1.name;

/**
 * @Teachers
 */
const teacher1 = new Teacher({
  id: "t-390",
  name: "Abdul Malek",
  subject: department1.subjects[1],
  employeeID: "EM-02",
});

const teacher2 = new Teacher({
  id: "t-116",
  name: "Mrs.Malike Hamaira",
  subject: department1.subjects[2],
  employeeID: "EM-03",
});

const teacher3 = new Teacher({
  id: "t-992",
  name: "Mrs.Bursha Alam",
  subject: department1.subjects[3],
  employeeID: "EM-04",
});

const teacher4 = new Teacher({
  id: "t-537",
  name: "Akkas Ali",
  subject: department1.subjects[4],
  employeeID: "EM-05",
});

//[Danger Zone]
department1.dTeachers = [teacher1, teacher2, teacher3];
//Another Way
department1.addTeacher(teacher4);

/**
 * @Student_Exam_and_Fee
 */

//Exams
const exam1 = new Exam({
  id: `ex-${department1.subjects[0].id}`,
  name: department1.subjects[0].name,
  subject: department1.subjects[0],
});

const exam2 = new Exam({
  id: `ex-${department1.subjects[1].id}`,
  name: department1.subjects[1].name,
  subject: department1.subjects[1],
});

const exam3 = new Exam({
  id: `ex-${department1.subjects[2].id}`,
  name: department1.subjects[2].name,
  subject: department1.subjects[2],
});

const exam4 = new Exam({
  id: `ex-${department1.subjects[3].id}`,
  name: department1.subjects[3].name,
  subject: department1.subjects[3],
});

student2.sExams = [exam1, exam2, exam3];
student2.addExam(exam4);

//Fee
student2.sFee = 850000;

/**
 * @Add_Dean_Account
 */

const deanAccount = new Account({
  id: dean.id,
  type: "Teacher Account",
});

dean.uniAccount = deanAccount;

//Add Amount on Dean Account
deanAccount.addAmount(54000);

/**
 * @Add_Student_Account
 */
const studentAccount = new Account({
  id: student2.studentID,
  type: "Student Account",
  amount: 3000,
});

student2.uniAccount = studentAccount;

studentAccount.addAmount(2000);

/**
 * @Final_Result
 */

console.log(student2);

/*

Student {
  id: 'p-072',
  name: 'Veronica',
  blood: 'B+',
  contact: Contact {
    id: 'p-072',
    email: 'veronica@gmail.com',
    phone: '+331942206',
    alternativePhone: '+8801786435',
    address: Address {
      id: 'gu-x01',
      roadNo: '3lb konabari',
      city: 'Gaixpir',
      region: 'Bokshi Pur',
      country: 'Bangladesh',
      postalCode: '1701'
    }
  },
  department: Department {
    id: 'DP-x7CS',
    name: 'SWE',
    subjects: [ [Subject], [Subject], [Subject], [Subject], [Subject] ],
    dean: Teacher {
      id: 't-128',
      name: 'Thomson',
      blood: 'O+',
      contact: [Contact],
      department: 'SWE',
      account: [Account],
      employeeID: 'EM-01',
      salary: 123000,
      subject: [Subject]
    },
    teachers: [ [Teacher], [Teacher], [Teacher], [Teacher] ]
  },
  account: Account {
    id: 'ST-x054',
    type: 'Student Account',
    amount: 5000,
    time: '2023-06-17T03:20:40.517Z'
  },
  studentID: 'ST-x054',
  guardian: Guardian {
    id: 'gu-x01',
    name: 'Mr. Anik',
    blood: 'A+',
    contact: Contact {
      id: 'gu-x01',
      email: '',
      phone: '+8801786435',
      alternativePhone: '',
      address: [Address]
    },
    profession: 'Programmer',
    income: '150000'
  },
  exams: [
    Exam {
      id: 'ex-101',
      name: 'CS Fundamental',
      subject: [Subject],
      passMark: 33
    },
    Exam {
      id: 'ex-103',
      name: 'Calculus101',
      subject: [Subject],
      passMark: 33
    },
    Exam {
      id: 'ex-102',
      name: 'Software Testing',
      subject: [Subject],
      passMark: 33
    },
    Exam {
      id: 'ex-202',
      name: 'Compilar Design',
      subject: [Subject],
      passMark: 33
    }
  ],
  fee: 850000
}

*/
console.log(`

















`);
// console.log(
//   student2.department.teachers.map(
//     (v, i) => `${i + 1}.Name:${v.name} - Subject:${v.subject.name}`
//   )
// );
/*
  [
   '1.Name:Abdul Malek - Subject:Calculus101',
   '2.Name:Mrs.Malike Hamaira - Subject:Software Testing',
   '3.Name:Mrs.Bursha Alam - Subject:Compilar Design',
   '4.Name:Akkas Ali - Subject:Data Structure & Algorithmn'
  ]
*/

/*
    // console.log(
    //student2.department.subjects.reduce((a, b) => {
    // let credit = a.credit + b.credit;
    //    return { credit: credit };
    //   })
    // );

   7:20:07

   
  First iteration a is: Subject { id: 101, name: 'CS Fundamental', credit: 3 }
  First iteration b is: Subject { id: 103, name: 'Calculus101', credit: 4 }

  In here, a.credit=3 & b.credit=4

  In this case, when we run a.credit+b.credit, it simply adds 3+4 and stores it in the accmulator a. Now the value of accmulator a is 7, which is not an object.
 
  For this reason, in the second iteration, when we access a.credit, it throws undefined because 7.credit is not possible.

  Second Iteration a is -> 7
  Second Iteration b is: Subject { id: 102, name: 'Linear Algebra', credit: 2 }

  In here, a.credit=7.credit=undefined, and b.credit=2.

  In this case, when we run a.credit+b.credit, it simply adds
  undefined+2 that throw NaN

   7:20:07 এ যে সমস্যাটি হয়েছিলঃ
    
   প্রথম iteration এ a এর মান: Subject { id: 101, name: 'CS Fundamentals', credit: 3 }
   প্রথম iteration এ b এর মান: Subject { id: 103, name: 'Calculus 1', credit: 4 }

   এখানে a.credit=3 এবং b.credit=4

   যখন a.credit+b.credit run হবে তখন এটি 3+4 যোগ করে মানটি accumulator এ স্টোর করবে। এখন accumulator a এর মান 7, উল্লেখ্য যে এটি একটি Integer ভেলু, object না। এই কারণে দ্বিতীয় iteration এ যখন a.credit run হবে তখন এটি undefined রিটার্ন করবে, কারণ 7.credit[a.credit] সম্ভব না। 


   দ্বিতীয় iteration এ a এর মান: 7
   দ্বিতীয় iteration এ b এর মান: Subject { id: 102, name: 'Linear Algebra', credit: 2 }

   এখানে a.credit=7.credit=undefined এবং b.credit=2

   ফলে যখন a.credit+b.credit run হবে তখন এটি undefined+2 যোগ করবে যা NaN রিটার্ন করবে। 

   console.log(
  student2.department.subjects.reduce((a, b) => {
    console.log(
      `a:${a} ~ credit:${a.credit}  ------   b:${b} ~ credit:${b.credit}`
    );

    // let credit = a.credit + b.credit;
    // return { credit: credit };
    return a.credit + b.credit;
  })
);
*/
