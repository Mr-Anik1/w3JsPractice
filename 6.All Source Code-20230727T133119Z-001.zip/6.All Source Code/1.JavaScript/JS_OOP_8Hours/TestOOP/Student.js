const { Person } = require("./Person"); //Common JS
// import { Person } from "./Person.js"; //ES6

class Student extends Person {
  #studentTutionFee;
  constructor(id, name, email, password, subjects, fee) {
    super(id, name, email, password);
    this.studentSubjects = subjects;
    this.#studentTutionFee = fee;
  }

  result() {
    return {
      ...this.createUser(),
      subjects: this.studentSubjects,
      fee: this.#studentTutionFee,
      result: `Fail`,
    };
  }
}

// let student1 = new Student(
//   "S-02",
//   "Manik",
//   "manik@gmail.com",
//   "23562",
//   ["Bangla", "English", "Math", "ICT", "Physics"],
//   "5800"
// );

// console.log(student1.createUser());
/*

{
  id: 'S-02',
  name: 'Manik',
  email: 'manik@gmail.com',
  password: '23562'
}

*/
// console.log(student1.forgotPassword("23562", "$kj!^8"));
//Hello Manik, your password is being reseted.

// console.log(student1.result());
/*

{
  id: 'S-02',
  name: 'Manik',
  email: 'manik@gmail.com',
  password: '$kj!^8',
  subjects: [ 'Bangla', 'English', 'Math', 'ICT', 'Physics' ],
  fee: '5800',
  result: 'Fail'
}

*/

module.exports = { Student };
