class Person {
  #personEmail;
  #personPassword;
  constructor(id, name, email, password) {
    this.personId = id;
    this.personName = name;
    this.#personEmail = email;
    this.#personPassword = password;
  }

  createUser() {
    return {
      id: this.personId,
      name: this.personName,
      email: this.#personEmail,
      password: this.#personPassword,
    };
  }

  set #resetUserPassword(newPass) {
    this.#personPassword = newPass;
  }

  forgotPassword(oldPass, newPass) {
    if (oldPass === this.#personPassword) {
      this.#resetUserPassword = newPass;
      return `Hello ${this.personName}, your password is being reseted.`;
    }
    return `Incorrect Password! Enter Correct Old Password.`;
  }
}

let p1 = new Person(1, "Anik", "anik@gmail.com", "23453");

// console.log(p1.createUser());
// //{ id: 1, name: 'Anik', email: 'anik@gmail.com', password: '23453' }
// p1.forgotPassword("$te%s@#");
// console.log(p1.createUser());
// //{ id: 1, name: 'Anik', email: 'anik@gmail.com', password: '$te%s@#' }

module.exports = { Person }; //Common JS

// export { Person }; //ES6 Module System
