const { Person } = require("./Person");
const { Student } = require("./Student");
const { Teacher } = require("./Teacher");

/**
 *
 * @For_Person_Class
 *
 */
const p1 = new Person("p-a1:007", "Newton", "newton@gmail.com", "567");

console.log(p1);
/*
//Only id and name is being showed beacuse we hide email & password

Person { personId: 'p-a1:007', personName: 'Newton' }

*/

console.log(p1.createUser());
/*
 {
  id: 'p-a1:007',
  name: 'Newton',
  email: 'newton@gmail.com',
  password: '567'
}
*/
console.log(p1.forgotPassword("sdl", "a1:3_$hd^9@tst"));
//Incorrect Password! Enter Correct Old Password.
console.log(p1.forgotPassword("567", "a1:3_$hd^9@tst"));
//Hello Newton, your password is being reseted.
console.log(p1.createUser());
/*
//Password has been changed

{
  id: 'p-a1:007',
  name: 'Newton',
  email: 'newton@gmail.com',
  password: 'a1:3_$hd^9@tst'
}


*/

console.log(`








`);
/**
 *
 * @For_Students
 *
 */
const s1 = new Student(
  "05",
  "Anik",
  "anik@gmail.com",
  "#565",
  ["Calculas", "Liear Algebra", "CS Fundamentals", "SRS"],
  "760500"
);

console.log(s1.createUser());
// { id: '05', name: 'Anik', email: 'anik@gmail.com', password: '#565' }

console.log(s1.forgotPassword("eotj65", "h@$&sjk3"));
//Incorrect Password! Enter Correct Old Password.
console.log(s1.forgotPassword("#565", "h@$&sjk3"));
//Hello Anik, your password is being reseted.
console.log(s1.createUser());
/*

{
  id: '05',
  name: 'Anik',
  email: 'anik@gmail.com',
  password: 'h@$&sjk3'
}


*/

console.log(s1.result());
/*

{
  id: '05',
  name: 'Anik',
  email: 'anik@gmail.com',
  password: 'h@$&sjk3',
  subjects: [ 'Calculas', 'Liear Algebra', 'CS Fundamentals', 'SRS' ],
  fee: '760500',
  result: 'Fail'
}


*/

console.log(`








`);

/**
 *
 * @For_Teacher
 *
 */
const t1 = new Teacher(
  "T-769",
  "Alexa",
  "alexa@gmail.com",
  "goALex@",
  "Data Structure & Algoritham",
  "50000"
);

console.log(t1);
/*

Teacher {
  personId: 'T-769',
  personName: 'Alexa',
  teacherSubject: 'Data Structure & Algoritham'
}


*/

console.log(t1.takeClass());
/*
 {
  id: 'T-769',
  name: 'Alexa',
  email: 'alexa@gmail.com',
  password: 'goALex@',
  subject: 'Data Structure & Algoritham',
  salary: '50000',
  classTime: '11:30 AM'
}
*/

console.log(t1.personId, t1.personName);
//T-769 Alexa
