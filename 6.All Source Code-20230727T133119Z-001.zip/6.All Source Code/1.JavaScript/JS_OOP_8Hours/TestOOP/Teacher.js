const { Person } = require("./Person");

class Teacher extends Person {
  #teacherSalary;
  constructor(id, name, email, password, subject, salary) {
    super(id, name, email, password);
    this.teacherSubject = subject;
    this.#teacherSalary = salary;
  }

  takeClass() {
    return {
      ...this.createUser(),
      subject: this.teacherSubject,
      salary: this.#teacherSalary,
      classTime: "11:30 AM",
    };
  }
}

// let teacher1 = new Teacher(
//   "T-004",
//   "Tesla Ali",
//   "tesla@gmail.com",
//   "$#7584Gjf",
//   "Physics",
//   "60900"
// );

// console.log(teacher1.createUser());
/*
    {
      id: 'T-004',
      name: 'Tesla Ali',
      email: 'tesla@gmail.com',
      password: '$#7584Gjf'
    }
*/

// console.log(teacher1.forgotPassword("woetf", "t1$9"));
//Incorrect Password! Enter Correct Old Password.
// console.log(teacher1.forgotPassword("$#7584Gjf", "Hello@1$9"));
//Hello Tesla Ali, your password is being reseted.
// console.log(teacher1.createUser());
/*
     {
       id: 'T-004',
       name: 'Tesla Ali',
       email: 'tesla@gmail.com',
       password: 'Hello@1$9'
     }
*/

// console.log(teacher1.takeClass());
/*

{
  id: 'T-004',
  name: 'Tesla Ali',
  email: 'tesla@gmail.com',
  password: 'Hello@1$9',
  subject: 'Physics',
  salary: '60900',
  classTime: '11:30 AM'
}

*/

module.exports = { Teacher };
